import CakeCutting.Registry

/-! Stateful one-query service for all pieces and all observers. -/
namespace CakeCutting.AdaptiveTrim
open MeasureTheory Finset DecisionTree Registry Components
open scoped NNReal
noncomputable section
variable {n : ℕ}
abbrev Pieces (n : ℕ) := Fin n → Bundle
abbrev State (s : Pieces n) := Board (Fin n) (Fin n) (fun j => Mark (s j)) (fun _ => ℝ)
abbrev Records (n : ℕ) := Fin n → Interval → ℝ
def correct (v : Fin n → Valuation) (s : Pieces n) (rec : Records n) :=
  ∀ i j a, a ∈ s j → rec i a = mass (v i) a
def link (v : Fin n → Valuation) (s : Pieces n) (j i : Fin n) (p : Mark (s j)) (b : ℝ) :=
  retained (v i) p = b

def topKey (s : Pieces n) (rec : Records n) (j i : Fin n) : N :=
  (total (rec i) (s j)).toNNReal + 1
theorem top_pos (s : Pieces n) (rec : Records n) (j i) : 0 < topKey s rec j i := by
  unfold topKey; positivity

def initial (s : Pieces n) (rec : Records n) : State s :=
  ⟨fun j x => if 1 ≤ x then wholeMark (s j) else emptyMark (s j),
   fun _ t => max 0 ((t:ℝ)-1),fun j i => {(0,0),(1,topKey s rec j i)}⟩

def Within (s : Pieces n) (rec : Records n) (B : State s) :=
  ∀ j i p, p ∈ B.graph j i → p.1 ≤ 1 ∧ p.2 ≤ topKey s rec j i

structure Sound (s : Pieces n) (rec : Records n) (v : Fin n → Valuation) (B : State s) : Prop where
  extends_initial : Extends (initial s rec) B
  valid : Registry.Valid B (link v s)
  bounded : Within s rec B

private theorem total_nonneg (v : Valuation) (s : Bundle) : 0 ≤ total (mass v) s :=
  List.sum_nonneg (fun x h => by obtain ⟨a,_,rfl⟩ := List.mem_map.mp h; exact measureReal_nonneg)

theorem initial_sound (v : Fin n → Valuation) (s : Pieces n) (rec : Records n) (ok : correct v s rec) :
    Sound s rec v (initial s rec) := by
  refine ⟨extends_refl _,⟨?_,?_,?_,?_⟩,?_⟩
  · intro j x y xy
    change (if 1 ≤ x then _ else _) ≤ (if 1 ≤ y then _ else _)
    split <;> split <;> first | exact le_rfl | exact (mark_range _ _).1 | exact False.elim (by order)
  · intro i x y xy; exact max_le_max_left _ (sub_le_sub_right (show (x:ℝ) ≤ y from xy) _)
  · intro j i p hp q hq
    simp only [initial,mem_insert,mem_singleton] at hp hq
    rcases hp with rfl | rfl <;> rcases hq with rfl | rfl <;> simp [top_pos,(top_pos s rec j i).ne',(top_pos s rec j i).ne]
  · intro j i p hp
    have h := recorded_total (v i) (rec i) (s j) (ok i j)
    have hn := h ▸ total_nonneg (v i) (s j)
    simp only [initial,mem_insert,mem_singleton] at hp
    rcases hp with rfl | rfl
    · simp [link,initial,(endpoint_values ..).1]
    · simp [link,initial,(endpoint_values ..).2,topKey,← h,hn]
  · intro j i p hp
    simp only [initial,mem_insert,mem_singleton] at hp
    rcases hp with rfl | rfl <;> simp

theorem anchors {s : Pieces n} {rec : Records n} {v B} (h : Sound s rec v B) (j i) :
    (0,0) ∈ B.graph j i ∧ (1,topKey s rec j i) ∈ B.graph j i :=
  ⟨h.extends_initial.keep _ _ (by simp [initial]),h.extends_initial.keep _ _ (by simp [initial])⟩

structure StepOK (s : Pieces n) (rec : Records n) (v : Fin n → Valuation)
    (B : State s) (j i : Fin n) (x y : N) (T : State s) : Prop where
  extends_old : Extends B T
  sound : Sound s rec v T
  entry : (x,y) ∈ T.graph j i

/-- A requested first coordinate, either already known or inside the domain
of the observed endpoint pairs. The remaining input is a physical answer. -/
def accept {R C : Type} {P : R → Type} {Q : C → Type}
    [Fintype R] [DecidableEq C] [DecidableEq R] [∀ c, LinearOrder (Q c)]
    (B : Board R C P Q) (r : R) (c : C) (x : N) (u : Q c) : N × Board R C P Q := by
  classical
  exact if h : ∃ y G, Choice B r c x u y G then
    let y := Classical.choose h
    (y,add B r c x y (Classical.choose (Classical.choose_spec h)))
  else (0,B)

theorem accept_correct {R C : Type} {P : R → Type} {Q : C → Type}
    [Fintype R] [Fintype C] [DecidableEq C] [DecidableEq R] [∀ c, LinearOrder (Q c)] [∀ r, LinearOrder (P r)]
    (B : Board R C P Q) (L : ∀ r c, P r → Q c → Prop) (v : Registry.Valid B L) (r : R) (c : C)
    (x : N) (u : Q c) (fresh : ∀ p ∈ B.graph r c, p.1 ≠ x)
    (lo : ∃ p ∈ B.graph r c, p.1 < x) (hi : ∃ p ∈ B.graph r c, x < p.1)
    (lb : ∀ p ∈ B.graph r c, p.1 < x → B.col c p.2 ≤ u)
    (ub : ∀ p ∈ B.graph r c, x < p.1 → u ≤ B.col c p.2) (eq : L r c (B.row r x) u) :
    let (y,T) := accept B r c x u
    Extends B T ∧ Registry.Valid T L ∧ (x,y) ∈ T.graph r c ∧
      ∀ a b p, p ∈ T.graph a b → p ∈ B.graph a b ∨ (a = r ∧ b = c ∧ p = (x,y)) := by
  obtain he := choice_exists B r c x u (v.ordered r c) (v.colMono c) fresh lo hi lb ub
  simp only [accept,dif_pos he]
  obtain ⟨ext,val,entry⟩ := add_spec v (Classical.choose_spec (Classical.choose_spec he)) fresh eq
  refine ⟨ext,val,entry,?_⟩
  intro a b p hp
  by_cases same : a = r ∧ b = c
  · rcases same with ⟨rfl,rfl⟩; simp [add] at hp; tauto
  · exact Or.inl (by simpa [add,same] using hp)

def queryF (s : Pieces n) (rec : Records n) (B : State s) (j i : Fin n) (x : N) :
    Tree n (N × State s) := by
  classical
  exact if h : ∃ y, (x,y) ∈ B.graph j i then .ret (Classical.choose h,B) else
    bind (Components.eval i (rec i) (B.row j x)) (fun u => .ret (accept B j i x u))

theorem forward_good (s : Pieces n) (rec : Records n) (v : Fin n → Valuation)
    (ok : correct v s rec) (B : State s) (h : Sound s rec v B) (j i : Fin n) (x : N) (bound : x ≤ 1) :
    Good v (fun z => StepOK s rec v B j i x z.1 z.2) 1 (queryF s rec B j i x) := by
  classical
  unfold queryF
  split
  next ex => exact (good_ret ..).2 ⟨extends_refl _,h,Classical.choose_spec ex⟩
  next fresh =>
    apply bind_good v _ _ _ _ 1 0 (Components.eval_good v i _ _ (ok i j))
    rintro u rfl
    let u := retained (v i) (B.row j x)
    obtain ⟨bot,top⟩ := anchors h j i
    have fr (p) (hp : p ∈ B.graph j i) : p.1 ≠ x := fun eq => fresh ⟨p.2,eq ▸ hp⟩
    have pos : 0 < x := lt_of_le_of_ne (zero_le _) (fr _ bot)
    have small : x < 1 := lt_of_le_of_ne bound (fr _ top).symm
    have result := accept_correct B _ h.valid j i x u fr ⟨_,bot,pos⟩ ⟨_,top,small⟩
      (fun p hp px => (h.valid.linked j i p hp) ▸ monotone_retained _ _ (h.valid.rowMono j px.le))
      (fun p hp xp => (h.valid.linked j i p hp) ▸ monotone_retained _ _ (h.valid.rowMono j xp.le)) rfl
    rcases e : accept B j i x u with ⟨y,T⟩
    rw [e] at result
    obtain ⟨ext,val,entry,onlyNew⟩ := result
    apply (good_ret ..).2
    change StepOK s rec v B j i x y T
    refine ⟨ext,⟨extends_trans h.extends_initial ext,val,?_⟩,entry⟩
    intro a b p hp
    rcases onlyNew a b p hp with old | ⟨rfl,rfl,rfl⟩
    · exact h.bounded _ _ _ old
    · refine ⟨bound,?_⟩
      by_contra! bad
      exact bound.not_gt ((val.ordered a b _ (ext.keep _ _ top) _ entry).1.mpr bad)


def lows (B : Graph) (y : N) := B.filter (fun p => p.2 < y)
def highs (B : Graph) (y : N) := B.filter (fun p => y < p.2)

def bracket (s : Pieces n) (B : State s) (j i : Fin n) (y : N) (p : Mark (s j)) : Mark (s j) :=
  let L := insert (emptyMark _) ((lows (B.graph j i) y).image (fun z => B.row j z.1))
  let U := insert (wholeMark _) ((highs (B.graph j i) y).image (fun z => B.row j z.1))
  max (L.max' (insert_nonempty ..)) (min p (U.min' (insert_nonempty ..)))

private theorem bracket_spec (s : Pieces n) (rec : Records n) (v : Fin n → Valuation)
    (B : State s) (h : Sound s rec v B) (j i : Fin n) (y : N)
    (positive : 0 < y) (below : y < topKey s rec j i) (p : Mark (s j))
    (cut : retained (v i) p = B.col i y) :
    let z := bracket s B j i y p
    (∀ q ∈ B.graph j i, q.2 < y → B.row j q.1 ≤ z) ∧
    (∀ q ∈ B.graph j i, y < q.2 → z ≤ B.row j q.1) ∧ retained (v i) z = B.col i y := by
  let φ := fun q : N × N => B.row j q.1
  let L := insert (emptyMark _) ((lows (B.graph j i) y).image φ)
  let U := insert (wholeMark _) ((highs (B.graph j i) y).image φ)
  let l := L.max' (insert_nonempty ..)
  let u := U.min' (insert_nonempty ..)
  obtain ⟨bot,top⟩ := anchors h j i
  have b0 : B.row j 0 = emptyMark (s j) := by
    simpa [initial] using h.extends_initial.rows j i (0,0) (by simp [initial])
  have b1 : B.row j 1 = wholeMark (s j) := by
    simpa [initial] using h.extends_initial.rows j i (1,topKey s rec j i) (by simp [initial])
  have lower : ∃ a ∈ B.graph j i, a.2 < y ∧ l = φ a := by
    rcases mem_insert.mp (show l ∈ L from max'_mem ..) with e | hit
    · exact ⟨_,bot,positive,e.trans b0.symm⟩
    · obtain ⟨a,ha,eq⟩ := mem_image.mp hit
      exact ⟨a,(mem_filter.mp ha).1,(mem_filter.mp ha).2,eq.symm⟩
  have upper : ∃ b ∈ B.graph j i, y < b.2 ∧ u = φ b := by
    rcases mem_insert.mp (show u ∈ U from min'_mem ..) with e | hit
    · exact ⟨_,top,below,e.trans b1.symm⟩
    · obtain ⟨a,ha,eq⟩ := mem_image.mp hit
      exact ⟨a,(mem_filter.mp ha).1,(mem_filter.mp ha).2,eq.symm⟩
  obtain ⟨a,ha,ay,la⟩ := lower
  obtain ⟨b,hb,yb,ub⟩ := upper
  have lu : l ≤ u := by rw [la,ub]; exact h.valid.rowMono j ((h.valid.ordered j i _ ha _ hb).1.mpr (ay.trans yb)).le
  change (∀ q ∈ B.graph j i, q.2 < y → B.row j q.1 ≤ max l (min p u)) ∧
    (∀ q ∈ B.graph j i, y < q.2 → max l (min p u) ≤ B.row j q.1) ∧ _
  refine ⟨?_,?_,?_⟩
  · intro q hq qy
    exact (le_max' L _ (mem_insert_of_mem (mem_image_of_mem φ (mem_filter.mpr ⟨hq,qy⟩)))).trans (le_max_left ..)
  · intro q hq yq
    exact (max_le lu (min_le_right ..)).trans (min'_le U _ (mem_insert_of_mem (mem_image_of_mem φ (mem_filter.mpr ⟨hq,yq⟩))))
  · apply Transcript.clamp _ (monotone_retained _ _) _ _ cut
    · change retained (v i) l ≤ _; rw [la]; exact (h.valid.linked j i a ha).symm ▸ h.valid.colMono i ay.le
    · change _ ≤ retained (v i) u; rw [ub]; exact (h.valid.linked j i b hb).symm ▸ h.valid.colMono i yb.le

def queryI (s : Pieces n) (rec : Records n) (B : State s) (j i : Fin n) (y : N) :
    Tree n (N × State s) := by
  classical
  exact if h : ∃ x, (x,y) ∈ B.graph j i then .ret (Classical.choose h,B) else
    bind (Components.cut i (rec i) (B.col i y) (s j)) fun p =>
      let (x,T) := accept (flip B) i j y (bracket s B j i y p)
      .ret (x,flip T)

theorem inverse_good (s : Pieces n) (rec : Records n) (v : Fin n → Valuation)
    (ok : correct v s rec) (B : State s) (h : Sound s rec v B) (j i : Fin n) (y : N)
    (bound : y ≤ topKey s rec j i) :
    Good v (fun z => StepOK s rec v B j i z.1 y z.2) 1 (queryI s rec B j i y) := by
  classical
  unfold queryI
  split
  next ex => exact (good_ret ..).2 ⟨extends_refl _,h,Classical.choose_spec ex⟩
  next fresh =>
    obtain ⟨bot,top⟩ := anchors h j i
    have fr (p) (hp : p ∈ (flip B).graph i j) : p.1 ≠ y :=
      fun eq => fresh ⟨p.2,eq ▸ swap_mem.mp hp⟩
    have pos : 0 < y := lt_of_le_of_ne (zero_le _) (fun eq => fresh ⟨0,eq ▸ bot⟩)
    have small : y < topKey s rec j i := lt_of_le_of_ne bound (fun eq => fresh ⟨1,eq.symm ▸ top⟩)
    have v0 : B.col i 0 = 0 := by simpa [initial] using h.extends_initial.cols j i (0,0) (by simp [initial])
    have v1 : B.col i (topKey s rec j i) = total (rec i) (s j) := by
      have hn := (recorded_total (v i) _ _ (ok i j)) ▸ total_nonneg (v i) (s j)
      simpa [initial,topKey,hn] using h.extends_initial.cols j i (1,topKey s rec j i) (by simp [initial])
    apply bind_good v _ _ _ _ 1 0 (Components.cut_good v i _ _ (v0 ▸ h.valid.colMono i pos.le) _
      (v1 ▸ h.valid.colMono i bound) (ok i j))
    intro p hp
    obtain ⟨lower,upper,eq⟩ := bracket_spec s rec v B h j i y pos small p hp
    have result := accept_correct (flip B) _ (valid_flip h.valid) i j y _ fr
      ⟨(0,0),swap_mem.mpr bot,pos⟩ ⟨(topKey s rec j i,1),swap_mem.mpr top,small⟩
      (fun a ha aY => lower a.swap (swap_mem.mp ha) aY)
      (fun a ha Ya => upper a.swap (swap_mem.mp ha) Ya) eq
    rcases e : accept (flip B) i j y (bracket s B j i y p) with ⟨x,T⟩
    rw [e] at result
    obtain ⟨ext,val,entry,onlyNew⟩ := result
    have ext' : Extends B (flip T) := by simpa using extends_flip ext
    have val' : Registry.Valid (flip T) (link v s) := valid_flip val
    have hit : (x,y) ∈ (flip T).graph j i := swap_mem.mpr entry
    apply (good_ret ..).2
    refine ⟨ext',⟨extends_trans h.extends_initial ext',val',?_⟩,hit⟩
    intro a b q hq
    rcases onlyNew b a q.swap (swap_mem.mp hq) with old | ⟨rfl,rfl,pairEq⟩
    · exact h.bounded _ _ _ (swap_mem.mp old)
    · have same : q = (x,y) := by simpa using congrArg Prod.swap pairEq
      subst q
      refine ⟨?_,bound⟩
      by_contra! big
      exact bound.not_gt ((val'.ordered a b _ (ext'.keep _ _ top) _ hit).1.mp big)

end
end CakeCutting.AdaptiveTrim
