import CakeCutting.Divide
import CakeCutting.Simulation
import CakeCutting.OrderedPieces
import CakeCutting.Reassign
import CakeCutting.TwoAgents
import CakeCutting.SharedTables
import CakeCutting.Model
import CakeCutting.Matching
import CakeCutting.Equilibrium
import CakeCutting.Median
import CakeCutting.Progress
import CakeCutting.Bounds

/-! The first checks identify the original proposition and its proof. Run independently with
`lake env lean CakeCutting/Audit.lean` to inspect the transitive axioms. -/

#check CakeCutting.MainClaim
#check (CakeCutting.mainClaim_proof : CakeCutting.MainClaim)
#print axioms CakeCutting.mainClaim_proof
#print axioms CakeCutting.Matching.fullyExposable_iff_strictHall
#print axioms CakeCutting.Matching.obstruction_disjoint
#print axioms CakeCutting.Matching.matchingTest
#print axioms CakeCutting.Equilibrium.greatest
#print axioms CakeCutting.Equilibrium.unique
#print axioms CakeCutting.Median.rounded_step
#print axioms CakeCutting.Median.supporting_update
#print axioms CakeCutting.Median.phase_five_eighths
#print axioms CakeCutting.Bounds.filter_short_column
#print axioms CakeCutting.Bounds.failed_phases_le_log2
#print axioms CakeCutting.Progress.follows_label
#print axioms CakeCutting.Progress.new_domination
#print axioms CakeCutting.Progress.count_increases
#print axioms CakeCutting.Bounds.sum_round_budgets
#print axioms CakeCutting.Quantiles.quantile_rank
#print axioms CakeCutting.Quantiles.lowerMedian
#print axioms CakeCutting.Quantiles.crossing_bound
#print axioms CakeCutting.Relaxation.update_progress
#print axioms CakeCutting.Phase.median_phase
#print axioms CakeCutting.Phase.test_and_filter
#print axioms CakeCutting.SharedTables.requested_address
#print axioms CakeCutting.SharedTables.phase_budget

#print axioms CakeCutting.Solver.correct
#print axioms CakeCutting.Solver.all_assignments
#print axioms CakeCutting.Solver.total_table_budget
#print axioms CakeCutting.Exposure.exists_fullyExposable
#print axioms CakeCutting.CappedSquare.solve
#print axioms CakeCutting.PositiveTrim.certifying_order
#print axioms CakeCutting.PositiveTrim.certified
#print axioms CakeCutting.Transcript.insert_key
#print axioms CakeCutting.Transcript.clamp
#print axioms CakeCutting.Transcript.complete_map
#print axioms CakeCutting.Transcript.forward_entry
#print axioms CakeCutting.Transcript.inverse_entry
#print axioms CakeCutting.Transcript.realize_curve
#print axioms CakeCutting.Transcript.project
#print axioms CakeCutting.DecisionTree.bind_good
#print axioms CakeCutting.DecisionTree.start
#print axioms CakeCutting.TableProtocol.collect_good
#print axioms CakeCutting.TableProtocol.runTree_good
#print axioms CakeCutting.PhysicalCuts.cut_exists
#print axioms CakeCutting.Components.eval_good
#print axioms CakeCutting.Components.cut_good
#print axioms CakeCutting.Components.partition
#print axioms CakeCutting.Components.suffix_value
#print axioms CakeCutting.Components.monotone_retained
#print axioms CakeCutting.Core.cutter_advantage
#print axioms CakeCutting.Reassign.selection
#print axioms CakeCutting.Reassign.value_bounds
#print axioms CakeCutting.Repair.escape
#print axioms CakeCutting.Repair.comparison
#print axioms CakeCutting.Repair.protected_survives
#print axioms CakeCutting.CommonShares.sparse_cells
#print axioms CakeCutting.CommonShares.weighted_median
#print axioms CakeCutting.Components.balanced_good
#print axioms CakeCutting.TwoAgents.protocol

#print axioms CakeCutting.Registry.add_spec
#print axioms CakeCutting.AdaptiveTrim.forward_good
#print axioms CakeCutting.AdaptiveTrim.inverse_good
#print axioms CakeCutting.TranscriptRun.realizable
#print axioms CakeCutting.TranscriptRun.interpret_good
#print axioms CakeCutting.VirtualSolver.certified
#print axioms CakeCutting.CertifiedTrim.protocol_good
#print axioms CakeCutting.CertifiedTrim.query_bound
#print axioms CakeCutting.BoundaryRecords.boundary_good
#print axioms CakeCutting.EqualPieces.divide_good
#print axioms CakeCutting.CoreProtocol.protocol_good
#print axioms CakeCutting.RepairRounds.split_good
#print axioms CakeCutting.RepairRounds.precision
#print axioms CakeCutting.Refinement.round_good
#print axioms CakeCutting.SharesProtocol.iterate_good
#print axioms CakeCutting.PhysicalShares.program_good
#print axioms CakeCutting.PhysicalShares.repair_shares
#print axioms CakeCutting.Buffered.protect
#print axioms CakeCutting.RepairProtocol.program_good
#print axioms CakeCutting.Division.core_move
#print axioms CakeCutting.Division.preserve_dom
#print axioms CakeCutting.Division.round_good
#print axioms CakeCutting.Division.loop_good
#print axioms CakeCutting.Division.rename_good
#print axioms CakeCutting.Division.group_finish
#print axioms CakeCutting.Division.round_bound
#print axioms CakeCutting.Division.level_bound
#print axioms CakeCutting.Division.divide_good
#print axioms CakeCutting.Division.start_good
