import CakeCutting.CertifiedTrim

/-! Refresh the records for the subintervals at a retained boundary. Correct
previous records remain correct even if different pieces contain the same
degenerate interval. -/
namespace CakeCutting.BoundaryRecords
open Finset DecisionTree Components AdaptiveTrim MeasureTheory
noncomputable section
variable {n : ℕ}
local instance : DecidableEq Interval := Classical.decEq _

def boundary : {s : Bundle} → Mark s → List Interval
  | _,.empty => []
  | a::_,.here p hl hr => [⟨a.left,p,hl⟩,⟨p,a.right,hr⟩]
  | _::_,.later p => boundary p

theorem length_le {s : Bundle} (p : Mark s) : (boundary p).length ≤ 2 := by
  induction p with
  | empty => decide
  | here => rfl
  | later p ih => exact ih

theorem component_mem {s : Bundle} (p : Mark s) (a : Interval) :
    (a ∈ suffix p ∨ a ∈ trimmings p) → a ∈ s ∨ a ∈ boundary p := by
  induction p with
  | empty => simp [suffix,trimmings]
  | @here b s p hl hr =>
    simp only [suffix,trimmings,boundary,List.mem_cons]
    split <;> split <;> simp_all
    all_goals tauto
  | @later b s p ih =>
    change (a ∈ suffix p ∨ a ∈ b :: trimmings p) → a ∈ b::s ∨ a ∈ boundary p
    simp only [List.mem_cons]; tauto

def Preserves (v : Fin n → Valuation) (a b : Records n) :=
  ∀ i e, a i e = mass (v i) e → b i e = mass (v i) e
theorem preserves_refl (v : Fin n → Valuation) (a : Records n) : Preserves v a a := fun _ _ h => h
theorem preserves_trans {v : Fin n → Valuation} {a b c} (h : Preserves v a b) (g : Preserves v b c) :
    Preserves v a c := fun i e he => g i e (h i e he)
def Known (v : Fin n → Valuation) (a : Records n) (s : Bundle) :=
  ∀ i e, e ∈ s → a i e = mass (v i) e

def refresh (rec : Records n) : List Interval → Tree n (Records n)
  | [] => .ret rec
  | e::s => bind (TableProtocol.read (fun i => .ask (.eval i e.left e.right) (fun (w : ℝ) => .ret w))
        0 univ.toList) fun vals =>
      refresh (fun i => Function.update (rec i) e (vals i)) s

theorem refresh_good (v : Fin n → Valuation) (rec : Records n) (l : List Interval) :
    Good v (fun t => Preserves v rec t ∧ Known v t l) (n*l.length) (refresh rec l) := by
  induction l generalizing rec with
  | nil => exact (good_ret ..).2 ⟨preserves_refl v rec,by simp [Known]⟩
  | cons e s ih =>
    rw [List.length_cons,Nat.mul_succ,Nat.add_comm]
    let trueVal := fun i => mass (v i) e
    apply bind_good v (fun t : Fin n → ℝ => ∀ i, t i = trueVal i) _ _ _ n (n*s.length)
    · have ask (i) : Good v (· = trueVal i) 1 (.ask (.eval i e.left e.right) (fun (w : ℝ) => .ret w)) :=
        ⟨⟨_,e.ordered,rfl⟩,fun _ h => (good_ret ..).2 h.2⟩
      simpa using TableProtocol.read_good v _ trueVal 0 univ.toList (fun i _ => ask i)
    · intro vals good
      let t := fun i => Function.update (rec i) e (vals i)
      have atE (i) : t i e = trueVal i := by simp [t,good]
      have keep : Preserves v rec t := by
        intro i a ha; by_cases eq : a = e
        · subst a; exact atE i
        · simpa [t,Function.update_of_ne eq] using ha
      apply OracleTree.strengthen _ _ _ _ _ (ih t)
      rintro T ⟨more,known⟩
      refine ⟨preserves_trans keep more,?_⟩
      intro i a ha
      rcases List.mem_cons.mp ha with rfl | old
      · exact more i a (atE i)
      · exact known i a old

theorem boundary_good (v : Fin n → Valuation) (rec : Records n) {s : Bundle} (p : Mark s)
    (known : Known v rec s) :
    Good v (fun t => Preserves v rec t ∧ Known v t (suffix p) ∧ Known v t (trimmings p))
      (2*n) (refresh rec (boundary p)) := by
  apply mono v _ (by simpa [Nat.mul_comm 2 n] using Nat.mul_le_mul_left n (length_le p))
  apply OracleTree.strengthen _ _ _ _ _ (refresh_good v rec (boundary p))
  rintro t ⟨keep,new⟩
  have both (i a) (h : a ∈ suffix p ∨ a ∈ trimmings p) : t i a = mass (v i) a := by
    rcases component_mem p a h with old | h
    · exact keep i a (known i a old)
    · exact new i a h
  exact ⟨keep,fun i a ha => both i a (Or.inl ha),fun i a ha => both i a (Or.inr ha)⟩

/-- Each component newly appearing on the left is contained in its original
component. Thus the complement of a suffix still has separate components. -/
theorem trimmings_separate {s : Bundle} (p : Mark s) (h : Separate s) : Separate (trimmings p) := by
  induction p with
  | empty => exact h
  | here p hl hr => unfold trimmings; split <;> simp [Separate]
  | @later a s p ih =>
    obtain ⟨old,tail⟩ := List.pairwise_cons.mp h
    refine List.pairwise_cons.mpr ⟨?_,ih tail⟩
    intro b hb
    have sub : b.points ⊆ (trimmings p).points := fun _ hh => ⟨b,hb,hh⟩
    have all : (trimmings p).points ⊆ s.points := (partition p tail).1 ▸ Set.subset_union_left
    apply Set.disjoint_left.mpr
    intro x hx hit
    obtain ⟨c,hc,xc⟩ := all (sub hit)
    exact Set.disjoint_left.mp (old c hc) hx xc

theorem split_mass (v : Valuation) {s : Bundle} (p : Mark s) (sep : Separate s) :
    total (mass v) (trimmings p) + retained v p = total (mass v) s := by
  letI := v.finite
  obtain ⟨cover,disj⟩ := partition p sep
  rw [total_eq_measure _ _ (trimmings_separate p sep),suffix_value _ _ sep,total_eq_measure _ _ sep,
    ← measureReal_union disj (measurable_points (suffix p)),cover]

end
end CakeCutting.BoundaryRecords
