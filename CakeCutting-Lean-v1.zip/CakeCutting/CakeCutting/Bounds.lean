import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! Query accounting for the median phases and the recursion in v3. -/

namespace CakeCutting.Bounds

open Finset

/-- On a short coordinate the surviving candidates include every supporter.
The lower-median rank condition counts candidates, including ties. -/
theorem filter_short_column {A V : Type*} [DecidableEq A] [LinearOrder V]
    (pool : Finset A) (u : A → V) (median truth : V) (support : A → Prop)
    (hs : ∀ a ∈ pool, support a → truth ≤ u a) (hshort : median < truth)
    (hrank : pool.card ≤ 2 * (pool.filter (fun a => u a ≤ median)).card) :
    (∀ a ∈ pool, support a → a ∈ pool.filter (fun a => median < u a)) ∧
      2 * (pool.filter (fun a => median < u a)).card ≤ pool.card := by
  classical
  constructor
  · intro a ha h
    exact mem_filter.mpr ⟨ha, hshort.trans_le (hs a ha h)⟩
  · let low := pool.filter (fun a => u a ≤ median)
    have heq : pool.filter (fun a => median < u a) = pool \ low := by
      ext a
      by_cases h : a ∈ pool <;> simp [low, h, not_le]
    have hcard := card_sdiff_add_card_eq_card (s := low) (t := pool) (filter_subset ..)
    rw [heq]
    change pool.card ≤ 2 * low.card at hrank
    omega

/-- If a nonempty pool survives `phases` failed tests, then those failures
number at most the binary logarithm of the original pool size. -/
theorem failed_phases_le_log2 (size : ℕ → ℕ) (phases : ℕ)
    (hn : 0 < size phases)
    (half : ∀ t < phases, 2 * size (t + 1) ≤ size t) :
    phases ≤ (size 0).log2 := by
  have product : ∀ k ≤ phases, 2 ^ k * size k ≤ size 0 := by
    intro k
    induction k with
    | zero => simp
    | succ k ih =>
      intro hk
      calc
        2 ^ (k + 1) * size (k + 1) = 2 ^ k * (2 * size (k + 1)) := by
          rw [pow_succ, Nat.mul_assoc]
        _ ≤ 2 ^ k * size k := Nat.mul_le_mul_left _ (half k (by omega))
        _ ≤ size 0 := ih (by omega)
  have hpow : 2 ^ phases ≤ size 0 := by
    calc
      2 ^ phases = 2 ^ phases * 1 := by simp
      _ ≤ 2 ^ phases * size phases := Nat.mul_le_mul_left _ hn
      _ ≤ size 0 := product phases le_rfl
  exact (Nat.le_log2 (by have := Nat.two_pow_pos phases; omega)).2 hpow

/-- The five-eighths count after the per-round progress and rounding bounds
have been summed. `errors` counts all crossings over the phase. -/
theorem five_eighths (q pool unfinished errors : ℕ) (hq : 0 < q)
    (hprogress : (4 * q) * unfinished ≤ q * pool + errors)
    (herrors : 8 * errors ≤ (4 * q) * pool) :
    8 * unfinished ≤ 3 * pool := by
  have hscaled : q * (8 * unfinished) ≤ q * (3 * pool) := by
    nlinarith [hprogress, herrors]
  exact Nat.le_of_mul_le_mul_left hscaled hq

/-- Summing the per-level call count times the per-call query cost. An actual
strictly decreasing recursion visits each population size at most once. -/
theorem sum_round_budgets (n A B : ℕ) (calls cost : ℕ → ℕ) (L : ℕ → ℕ)
    (hL : Monotone L) (hcalls : ∀ m ∈ Icc 1 n, calls m ≤ A * m ^ 2)
    (hcost : ∀ m ∈ Icc 1 n, cost m ≤ B * m ^ 5 * L m) :
    (∑ m ∈ Icc 1 n, calls m * cost m) ≤ A * B * n ^ 8 * L n := by
  have pointwise (m : ℕ) (hm : m ∈ Icc 1 n) :
      calls m * cost m ≤ A * B * n ^ 7 * L n := by
    have hmn := (mem_Icc.mp hm).2
    calc
      _ ≤ (A * m ^ 2) * (B * m ^ 5 * L m) := Nat.mul_le_mul (hcalls m hm) (hcost m hm)
      _ = A * B * m ^ 7 * L m := by ring
      _ ≤ A * B * n ^ 7 * L n :=
        Nat.mul_le_mul (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hmn 7)) (hL hmn)
  calc
    _ ≤ ∑ _m ∈ Icc 1 n, A * B * n ^ 7 * L n := sum_le_sum pointwise
    _ = n * (A * B * n ^ 7 * L n) := by simp
    _ = A * B * n ^ 8 * L n := by ring

end CakeCutting.Bounds
