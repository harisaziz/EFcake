import CakeCutting.PhysicalShares
import CakeCutting.Repair

/-! Protection for physical suffixes of concatenated buffers, including empty
buffers and singleton endpoint components. The level counts the protected tails
contained as literal sets in the actual output. -/
namespace CakeCutting.Buffered
open Set Finset MeasureTheory Components

theorem append_points (a b : Bundle) : (a++b).points = a.points ∪ b.points := by
  ext x
  change (∃ e ∈ a++b, x ∈ e.points) ↔ (∃ e ∈ a, x ∈ e.points) ∨ (∃ e ∈ b, x ∈ e.points)
  simp only [List.mem_append]
  constructor
  · rintro ⟨e,ha|hb,h⟩
    · exact Or.inl ⟨e,ha,h⟩
    · exact Or.inr ⟨e,hb,h⟩
  · rintro (⟨e,ha,h⟩|⟨e,hb,h⟩)
    · exact ⟨e,Or.inl ha,h⟩
    · exact ⟨e,Or.inr hb,h⟩

theorem suffix_comparable (a b : Bundle) (p : Mark (a++b)) (sep : Separate (a++b)) :
    b.points ⊆ (suffix p).points ∨ (suffix p).points ⊆ b.points := by
  induction a with
  | nil => exact Or.inr ((partition p sep).1 ▸ Set.subset_union_right)
  | cons head rest ih =>
    cases p with
    | here x hl hr =>
      left
      have sub : b.points ⊆ Bundle.points (rest++b) := append_points rest b ▸ Set.subset_union_right
      simp only [suffix]
      split
      · exact sub
      · rw [cons_points]; exact sub.trans Set.subset_union_right
    | later q => exact ih q (List.pairwise_cons.mp sep).2

/-- A tail with k full buffers, closest to the protected part first in the indexing. -/
def tail (base : Bundle) (buf : ℕ → Bundle) : ℕ → Bundle
  | 0 => base
  | k+1 => buf k ++ tail base buf k

theorem prefix_exists (base : Bundle) (buf : ℕ → Bundle) {k m : ℕ} (le : k ≤ m) :
    ∃ a : Bundle, tail base buf m = a ++ tail base buf k := by
  induction m,le using Nat.le_induction with
  | base => exact ⟨[],rfl⟩
  | succ m hm ih =>
    obtain ⟨a,h⟩ := ih
    exact ⟨buf m ++ a,by rw [tail,h,List.append_assoc]⟩

theorem nested (base : Bundle) (buf : ℕ → Bundle) {k m : ℕ} (le : k ≤ m) :
    (tail base buf k).points ⊆ (tail base buf m).points := by
  obtain ⟨a,h⟩ := prefix_exists base buf le
  rw [h,append_points]; exact Set.subset_union_right

theorem comparable (base : Bundle) (buf : ℕ → Bundle) {k m : ℕ} (le : k ≤ m)
    (p : Mark (tail base buf m)) (sep : Separate (tail base buf m)) :
    (tail base buf k).points ⊆ (suffix p).points ∨ (suffix p).points ⊆ (tail base buf k).points := by
  obtain ⟨a,h⟩ := prefix_exists base buf le
  generalize eq : tail base buf m = full at p sep
  have same : full = a ++ tail base buf k := eq.symm.trans h
  clear eq h
  subst full
  exact suffix_comparable _ _ p sep

theorem whole_suffix (s : Bundle) : suffix (wholeMark s) = s := by
  cases s with
  | nil => rfl
  | cons a s => simp [wholeMark,suffix]

/-- A certificate on the packed physical labels forces every protected part to
survive. The numerical hypotheses concern only complete tails before trimming. -/
theorem protect {n : ℕ} [NeZero n] (m : ℕ) (size : m+1=n)
    (base : Fin n → Bundle) (buf : Fin n → ℕ → Bundle)
    (p : ∀ j, Mark (tail (base j) (buf j) m)) (sep : ∀ j, Separate (tail (base j) (buf j) m))
    (holder rank : Equiv.Perm (Fin n)) (v : Fin n → Valuation)
    (ef : ∀ j k, (v (holder j)).measure.real (suffix (p k)).points ≤ (v (holder j)).measure.real (suffix (p j)).points)
    (cert : ∀ j, p j = wholeMark _ ∨ ∃ a, rank a < rank j ∧
      (v (holder a)).measure.real (suffix (p j)).points = (v (holder a)).measure.real (suffix (p a)).points)
    (gap : ∀ i j k, k < m →
      (v i).measure.real (tail (base j) (buf j) k).points <
      (v i).measure.real (tail (base i) (buf i) (k+1)).points) :
    ∀ j, (base j).points ⊆ (suffix (p j)).points := by
  classical
  let S := fun j => (Finset.range (m+1)).filter (fun k => (tail (base j) (buf j) k).points ⊆ (suffix (p j)).points)
  have down {j k l} (mem : k ∈ S j) (le : l ≤ k) : l ∈ S j := by
    obtain ⟨inR,sub⟩ := mem_filter.mp mem
    exact mem_filter.mpr ⟨mem_range.mpr (le.trans_lt (mem_range.mp inR)),(nested _ _ le).trans sub⟩
  have hit (j k) : k ∈ S j ↔ k < (S j).card := by
    constructor
    · intro h
      have sub : Finset.range (k+1) ⊆ S j := fun l hl => down h (by have := mem_range.mp hl; omega)
      have := card_le_card sub
      simpa using this
    · intro h
      by_contra no
      have sub : S j ⊆ Finset.range k := fun l hl => mem_range.mpr (lt_of_not_ge (fun le => no (down hl le)))
      have := card_le_card sub
      simp at this; omega
  have maxCard (j) : (S j).card ≤ m+1 := by simpa [S] using card_le_card (filter_subset (fun k => (tail (base j) (buf j) k).points ⊆ (suffix (p j)).points) (range (m+1)))
  let L (j) : Fin (Fintype.card (Fin n)+1) := ⟨(S j).card,by simpa [← size] using Nat.lt_succ_of_le (maxCard j)⟩
  let value := fun i j => (v i).measure.real (suffix (p j)).points
  have full (j) (whole : p j = wholeMark _) : (L j).val = Fintype.card (Fin n) := by
    have has : m ∈ S j := mem_filter.mpr ⟨by simp,by rw [whole,whole_suffix]⟩
    have := (hit j m).mp has
    change (S j).card = _
    rw [Fintype.card_fin,← size]; have := maxCard j; omega
  have pos := Repair.protected_survives value L holder (rank.trans (finCongr (Fintype.card_fin n).symm)) ef
    (fun j => (cert j).imp (full j) (fun ⟨a,h,e⟩ => ⟨a,h,e⟩)) (by
      intro i j apart
      let k := (S j).card
      change k+2 ≤ (S i).card at apart
      have lim := maxCard i
      have km : k < m := by omega
      have upper := (mem_filter.mp ((hit i (k+1)).mpr (by omega))).2
      have lower : (suffix (p j)).points ⊆ (tail (base j) (buf j) k).points :=
        (comparable _ _ km.le (p j) (sep j)).resolve_left (fun sub =>
          (Nat.lt_irrefl k) ((hit j k).mp (mem_filter.mpr ⟨mem_range.mpr (by omega),sub⟩)))
      letI := (v i).finite
      exact (measureReal_mono lower).trans_lt ((gap i j k km).trans_le (measureReal_mono upper)))
  intro j
  exact (mem_filter.mp ((hit j 0).mpr (pos j))).2

end CakeCutting.Buffered
