import CakeCutting.Exposure
import CakeCutting.Equilibrium
import Mathlib.Order.Hom.WithTopBot
import Mathlib.Algebra.Order.GroupWithZero.Unbundled.OrderIso

/-! The median solver instantiated on the nonnegative capped square. The
artificial infinity is used for estimates only; output levels are finite. -/
namespace CakeCutting.CappedSquare
open CakeCutting.Matching CakeCutting.Exposure
open scoped NNReal
variable {R : Type*} [Fintype R] [Nonempty R] [DecidableEq R]

noncomputable def curves (f : R → R → ℝ≥0 ≃o ℝ≥0) (cap : R → ℝ≥0)
    (hcap : ∀ i, 0 < cap i) (i : R) : Option R → WithTop ℝ≥0 ≃o WithTop ℝ≥0
  | none => (OrderIso.mulLeft₀ (cap i) (hcap i)).withTopCongr
  | some j => (f i j).withTopCongr

def levels (u : R → ℝ≥0) : Option R → WithTop ℝ≥0
  | none => ↑(1 : ℝ≥0)
  | some j => ↑(u j)

omit [Fintype R] [Nonempty R] [DecidableEq R] in
private theorem value_at (f : R → R → ℝ≥0 ≃o ℝ≥0) (cap : R → ℝ≥0)
    (hcap : ∀ i, 0 < cap i) (u : R → ℝ≥0) (i : R) (j : Option R) :
    curves f cap hcap i j (levels u j) = ↑(price f cap u i j) := by
  cases j with
  | none =>
    change ((cap i * 1 : ℝ≥0) : WithTop ℝ≥0) = ↑(cap i)
    rw [mul_one]
  | some j => rfl

omit [Nonempty R] [DecidableEq R] in
private theorem tight_levels (f : R → R → ℝ≥0 ≃o ℝ≥0) (cap : R → ℝ≥0)
    (hcap : ∀ i, 0 < cap i) (u : R → ℝ≥0) :
    tight (table (fun i j v => curves f cap hcap i j v) (levels u)) =
      tight (price f cap u) := by
  funext i
  ext j
  simp only [mem_tight,table,value_at,WithTop.coe_le_coe]

/-- Finite output and a supporting ordinary matching, with no prior
existence or supporter hypothesis. Every capped equilibrium lies below the
returned ordinary levels. -/
theorem solve (f : R → R → ℝ≥0 ≃o ℝ≥0) (cap : R → ℝ≥0) (hcap : ∀ i, 0 < cap i) :
    ∃ (u : R → ℝ≥0) (m : R → Option R),
      Solver.run (curves f cap hcap) none (↑(1 : ℝ≥0))
        (Solver.candidate (R := R) none) ((Fintype.card R).factorial.log2+1) Finset.univ
        = some (levels u,m) ∧
      FullyExposable (tight (price f cap u)) ∧ Function.Injective m ∧
      (∀ i, m i ∈ (tight (price f cap u) i).erase none) ∧
      ∀ v : R → ℝ≥0, Equilibrium.Capped none (fun i j z => curves f cap hcap i j z) (levels v) →
        ∀ j, v j ≤ u j := by
  obtain ⟨u,hu⟩ := exists_fullyExposable f cap
  have h := tight_levels f cap hcap u
  have hx : FullyExposable (tight (table (fun i j z => curves f cap hcap i j z) (levels u))) := h.symm ▸ hu
  obtain ⟨m,hm,hinj,hedge⟩ := Solver.all_assignments (curves f cap hcap) none _
    (levels u) rfl (by simp) hx
  refine ⟨u,m,hm,hu,hinj,h ▸ hedge,fun v hv j => ?_⟩
  have dominated := Equilibrium.greatest none (fun i j z => curves f cap hcap i j z)
    (fun i j => (curves f cap hcap i j).strictMono) (levels u) (levels v) rfl hx hv (some j)
  exact WithTop.coe_le_coe.mp dominated

end CakeCutting.CappedSquare
