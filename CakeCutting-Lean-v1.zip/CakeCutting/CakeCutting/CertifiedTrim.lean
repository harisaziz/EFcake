import CakeCutting.VirtualSolver

/-! The physical certified trimming protocol, including adaptive simulation,
the terminal registration pass, and reconstruction of the witness order. -/
namespace CakeCutting.CertifiedTrim
open Registry AdaptiveTrim TranscriptRun VirtualSolver DecisionTree Components Finset
noncomputable section
variable {n : ℕ} [NeZero n]

def register (s : Pieces n) (rec : Records n) (x : Fin n → N) :
    List (Fin n × Fin n) → State s → Tree n (State s)
  | [],B => .ret B
  | (j,i)::xs,B => bind (queryF s rec B j i (x j)) fun z => register s rec x xs z.2

omit [NeZero n] in
theorem register_good (s : Pieces n) (rec : Records n) (v : Fin n → Valuation)
    (ok : correct v s rec) (x : Fin n → N) (bound : ∀ j, x j ≤ 1)
    (l : List (Fin n × Fin n)) (B : State s) (ss : Sound s rec v B) :
    Good v (fun T => Extends B T ∧ Sound s rec v T ∧
      ∀ d ∈ l, ∃ y, (x d.1,y) ∈ T.graph d.1 d.2) l.length (register s rec x l B) := by
  induction l generalizing B with
  | nil => exact (good_ret ..).2 ⟨extends_refl _,ss,by simp⟩
  | cons d l ih =>
    rcases d with ⟨j,i⟩
    rw [List.length_cons,Nat.add_comm]
    apply bind_good v _ _ _ _ 1 l.length (forward_good s rec v ok B ss j i (x j) (bound j))
    rintro ⟨y,B'⟩ h
    apply OracleTree.strengthen _ _ _ _ _ (ih B' h.sound)
    rintro T ⟨ext,sound,all⟩
    refine ⟨extends_trans h.extends_old ext,sound,?_⟩
    intro d hd
    rcases List.mem_cons.mp hd with rfl | old
    · exact ⟨y,ext.keep _ _ h.entry⟩
    · exact all d old

structure Output (s : Pieces n) where
  mark : ∀ j, Mark (s j)
  holder : Equiv.Perm (Fin n)
  rank : Equiv.Perm (Fin n)
  value : Fin n → Fin n → ℝ

def Witness (x : Fin n → N) (h r : Equiv.Perm (Fin n)) (y : Fin n → Fin n → N) :=
  ∀ j, x j = 1 ∨ ∃ a, r a < r j ∧ y j (h a) = y a (h a)

def decode (s : Pieces n) (B : State s) (x : Fin n → N) (h : Equiv.Perm (Fin n)) : Output s := by
  classical
  let y := fun j i => if ex : ∃ y, (x j,y) ∈ B.graph j i then Classical.choose ex else 0
  let r := if ex : ∃ r, Witness x h r y then Classical.choose ex else Equiv.refl _
  exact ⟨fun j => B.row j (x j),h,r,fun j i => B.col i (y j i)⟩

def budget (n : ℕ) := VirtualSolver.budget n + n*n

def protocol (s : Pieces n) (rec : Records n) : Tree n (Output s) :=
  bind (interpret s rec VirtualSolver.program (initial s rec)) fun z =>
    bind (register s rec z.1.1 univ.toList z.2) fun B => .ret (decode s B z.1.1 z.1.2)

def Spec (s : Pieces n) (v : Fin n → Valuation) (o : Output s) :=
  (∀ j i, o.value j i = retained (v i) (o.mark j)) ∧
  (∀ j k, o.value k (o.holder j) ≤ o.value j (o.holder j)) ∧
  ∀ j, o.mark j = wholeMark (s j) ∨ ∃ a, o.rank a < o.rank j ∧
    o.value j (o.holder a) = o.value a (o.holder a)

/-- Counts the complete physical protocol, with all terminal reads included.
Valuations can vanish on arbitrary intervals and every input list can be empty. -/
theorem protocol_good (s : Pieces n) (rec : Records n) (v : Fin n → Valuation) (ok : correct v s rec) :
    Good v (Spec s v) (budget n) (protocol s rec) := by
  classical
  have run := interpret_good s rec v ok VirtualSolver.program (initial s rec) (initial_sound v s rec ok)
    VirtualSolver.Certified (VirtualSolver.budget n) (fun F _ => VirtualSolver.certified F)
  apply bind_good v _ _ _ _ _ (n*n) run
  rintro ⟨⟨x,h⟩,B⟩ ⟨_,ss,cert⟩
  obtain ⟨F₀,f₀⟩ := realizable s rec v B ss
  obtain ⟨bound,_,_⟩ := cert F₀ f₀
  have reg := register_good s rec v ok x bound univ.toList B ss
  apply bind_good v _ _ _ _ (n*n) 0 (by simpa using reg)
  rintro T ⟨ext,sound,all⟩
  obtain ⟨F,fit⟩ := realizable s rec v T sound
  obtain ⟨_,ef,r,hr⟩ := cert F (fits_old ext fit)
  let y := fun j i => if ex : ∃ y, (x j,y) ∈ T.graph j i then Classical.choose ex else 0
  have entry (j i) : (x j,y j i) ∈ T.graph j i := by
    have ex := all j i
    simpa [y,ex] using Classical.choose_spec ex
  have yf (j i) : F j i (x j) = y j i := fit.table _ _ _ (entry j i)
  have ex : ∃ r, Witness x h r y := ⟨r,fun j => by
    rcases hr j with full | ⟨a,lt,tie⟩
    · exact Or.inl full
    · exact Or.inr ⟨a,lt,by simpa only [← yf] using tie⟩⟩
  have hw := Classical.choose_spec ex
  apply (good_ret ..).2
  unfold Spec decode
  dsimp only
  change (∀ j i, T.col i (y j i) = _) ∧ (∀ j k, T.col (h j) (y k (h j)) ≤ T.col (h j) (y j (h j))) ∧
    ∀ j, T.row j (x j) = wholeMark (s j) ∨ ∃ a,
      (if h : ∃ r, Witness x _ r y then Classical.choose h else Equiv.refl _) a <
      (if h : ∃ r, Witness x _ r y then Classical.choose h else Equiv.refl _) j ∧ _
  simp only [dif_pos ex]
  refine ⟨fun j i => (sound.valid.linked j i _ (entry j i)).symm,?_,?_⟩
  · intro j k
    apply sound.valid.colMono (h j)
    simpa only [← yf] using ef j k
  · intro j
    rcases hw j with full | ⟨a,lt,tie⟩
    · left; rw [full]
      simpa [initial] using sound.extends_initial.rows j j (1,topKey s rec j j) (by simp [initial])
    · exact Or.inr ⟨a,lt,congrArg (T.col (h a)) tie⟩

theorem query_bound (n : ℕ) (hn : 0 < n) :
    budget n ≤ 774*n^5*((2*n).log2+1) := by
  have h := Solver.total_table_budget n hn
  have a : n ≤ n^5 := by simpa using (Nat.pow_le_pow_right hn (by decide : 1 ≤ 5))
  have b : n*n ≤ n^5 := by simpa [pow_two] using (Nat.pow_le_pow_right hn (by decide : 2 ≤ 5))
  have scaled : n^5 ≤ n^5*((2*n).log2+1) := Nat.le_mul_of_pos_right _ (Nat.succ_pos _)
  unfold budget VirtualSolver.budget VirtualSolver.fuel
  calc
    _ ≤ 772*n^5*((2*n).log2+1) + n^5*((2*n).log2+1) + n^5*((2*n).log2+1) :=
      Nat.add_le_add (Nat.add_le_add h (a.trans scaled)) (b.trans scaled)
    _ = _ := by ring

end
end CakeCutting.CertifiedTrim
