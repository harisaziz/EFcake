import CakeCutting.PhysicalBundles
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Dimension.Finite

/-! Two ingredients of nearly common shares: a sparse nonnegative feasible
solution for prescribed linear constraints and the weighted median cut. -/
namespace CakeCutting.CommonShares
open Finset

/-- Any nonnegative finite linear combination can be represented with at
most as many positive coefficients as scalar equations. Only entries
already positive in the supplied solution may survive. -/
theorem sparse {I D : Type*} [Fintype I] [Fintype D] (col : I → D → ℝ)
    (initial : I → ℝ) (pos : ∀ i, 0 ≤ initial i) :
    ∃ x : I → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, 0 < x i → 0 < initial i) ∧
      (∑ i, x i • col i) = ∑ i, initial i • col i ∧
      (univ.filter (fun i => 0 < x i)).card ≤ Fintype.card D := by
  classical
  let S (x : I → ℝ) := univ.filter (fun i => 0 < x i)
  let rec improve (x : I → ℝ) (hx : ∀ i, 0 ≤ x i) :
      ∃ z : I → ℝ, (∀ i, 0 ≤ z i) ∧ S z ⊆ S x ∧
        (∑ i, z i • col i) = ∑ i, x i • col i ∧ (S z).card ≤ Fintype.card D := by
    by_cases small : (S x).card ≤ Fintype.card D
    · exact ⟨x,hx,Subset.rfl,rfl,small⟩
    have dep : ¬ LinearIndependent ℝ (fun i : S x => col i) := by
      intro h
      have count := h.fintype_card_le_finrank
      simp at count
      exact small count
    obtain ⟨g,rel,i,ne⟩ := Fintype.not_linearIndependent_iff.mp dep
    obtain ⟨d,zero,j,up⟩ : ∃ d : S x → ℝ, (∑ i, d i • col i) = 0 ∧ ∃ j, 0 < d j := by
      rcases lt_or_gt_of_ne ne with neg | pp
      · exact ⟨fun k => -g k,by simp only [neg_smul,Finset.sum_neg_distrib,rel,neg_zero],i,neg_pos.mpr neg⟩
      · exact ⟨g,rel,i,pp⟩
    let plus := univ.filter (fun i => 0 < d i)
    obtain ⟨m,hm,minm⟩ := plus.exists_min_image (fun k => x k / d k) ⟨j,mem_filter.mpr ⟨mem_univ _,up⟩⟩
    let t := x m / d m
    have dm := (mem_filter.mp hm).2
    have tpos : 0 < t := div_pos (mem_filter.mp m.property).2 dm
    let z (k : I) := if h : k ∈ S x then x k - t * d ⟨k,h⟩ else x k
    have atKey (i : S x) : z i = x i - t*d i := dif_pos i.property
    have hz (k : I) : 0 ≤ z k := by
      by_cases inS : k ∈ S x
      · let k' : S x := ⟨k,inS⟩
        rw [show z k = x k - t*d k' from atKey k']
        by_cases pd : 0 < d k'
        · exact sub_nonneg.mpr ((le_div_iff₀ pd).mp (minm k' (mem_filter.mpr ⟨mem_univ _,pd⟩)))
        · exact sub_nonneg.mpr ((mul_nonpos_of_nonneg_of_nonpos tpos.le (le_of_not_gt pd)).trans (hx k))
      · simpa [z,inS] using hx k
    have sub : S z ⊆ S x := by
      intro k hk
      by_contra hn
      have p := (mem_filter.mp hk).2
      exact hn (mem_filter.mpr ⟨mem_univ _,by simpa [z,hn] using p⟩)
    have mz : z m = 0 := by rw [atKey]; dsimp [t]; rw [div_mul_cancel₀ _ dm.ne',sub_self]
    have strict : (S z).card < (S x).card := card_lt_card (Finset.ssubset_of_subset_of_ssubset
      (show S z ⊆ (S x).erase m from fun k hk => mem_erase.mpr
        ⟨fun eq => by subst k; exact (mem_filter.mp hk).2.ne' mz,sub hk⟩)
      (erase_ssubset m.property))
    have sum_on (v : I → ℝ) (h : ∀ k ∉ S x, v k = 0) :
        (∑ k, v k • col k) = ∑ k : S x, v k • col k := by
      calc
        _ = ∑ k ∈ S x, v k • col k := (Finset.sum_subset (subset_univ _)
          (fun k _ hk => by simp [h k hk])).symm
        _ = _ := (Finset.sum_attach (S x) (fun k => v k • col k)).symm
    have x0 (k) (hk : k ∉ S x) : x k = 0 := by
      have : ¬ 0 < x k := fun p => hk (mem_filter.mpr ⟨mem_univ _,p⟩)
      exact le_antisymm (le_of_not_gt this) (hx k)
    have same : (∑ k, z k • col k) = ∑ k, x k • col k := by
      rw [sum_on z (fun k hk => by simp [z,hk,x0 k hk]),sum_on x x0]
      simp only [atKey,sub_smul,mul_smul,Finset.sum_sub_distrib,← Finset.smul_sum,zero,smul_zero,sub_zero]
    obtain ⟨w,hw,sw,eq,cap⟩ := improve z hz
    exact ⟨w,hw,sw.trans sub,eq.trans same,cap⟩
  termination_by (univ.filter (fun i => 0 < x i)).card
  decreasing_by exact strict
  obtain ⟨x,hx,sub,eq,cap⟩ := improve initial pos
  exact ⟨x,hx,fun i hi => (mem_filter.mp (sub (mem_filter.mpr ⟨mem_univ _,hi⟩))).2,eq,cap⟩

/-- With consistent cell fractions, at most agents times slots many cells
need be split. All slot values for all agents are kept exactly and a zero
entry stays zero. Thus previously integral cells can stay fixed. -/
theorem sparse_cells {E J A : Type*} [Fintype E] [Fintype J] [Fintype A]
    [DecidableEq J] (w : A → E → ℝ) (p : E → J → ℝ) (positive : ∀ e j, 0 ≤ p e j)
    (rows : ∀ e, ∑ j, p e j = 1) :
    ∃ z : E → J → ℝ, (∀ e j, 0 ≤ z e j) ∧ (∀ e j, 0 < z e j → 0 < p e j) ∧
      (∀ e, ∑ j, z e j = 1) ∧
      (∀ a j, ∑ e, z e j * w a e = ∑ e, p e j * w a e) ∧
      (univ.filter (fun e => 1 < (univ.filter (fun j => 0 < z e j)).card)).card ≤
        Fintype.card A * Fintype.card J := by
  classical
  let col (k : E × J) : E ⊕ (A × J) → ℝ
    | .inl e => if k.1 = e then 1 else 0
    | .inr (a,j) => if k.2 = j then w a k.1 else 0
  obtain ⟨x,hx,sub,eq,cap⟩ := sparse col (fun k => p k.1 k.2) (fun k => positive ..)
  let z := fun e j => x (e,j)
  have cell (e : E) : (∑ j, z e j) = 1 := by
    have h := congrFun eq (.inl e)
    simp only [Finset.sum_apply,Pi.smul_apply,smul_eq_mul,Fintype.sum_prod_type,col] at h
    simpa [z,mul_ite,Finset.sum_ite_irrel,rows] using h
  refine ⟨z,fun _ _ => hx _,fun _ _ => sub _,cell,?_,?_⟩
  · intro a j
    have h := congrFun eq (.inr (a,j))
    simp only [Finset.sum_apply,Pi.smul_apply,smul_eq_mul,Fintype.sum_prod_type,col] at h
    simpa [z,mul_ite] using h
  · let c := fun e => (univ.filter (fun j => 0 < z e j)).card
    have one (e) : 0 < c e := by
      by_contra! no
      dsimp [c] at no
      have empty : (univ.filter (fun j => 0 < z e j)) = ∅ := card_eq_zero.mp (by omega)
      have all (j) : z e j = 0 := by
        apply le_antisymm _ (hx _)
        by_contra! h
        have member : j ∈ univ.filter (fun j => 0 < z e j) := mem_filter.mpr ⟨mem_univ _,h⟩
        simp [empty] at member
      have impossible := cell e
      simp [all] at impossible
    have hsum := Finset.sum_le_sum (s := (univ : Finset E)) (fun e _ =>
      (show 1 + (if 1 < c e then 1 else 0) ≤ c e by have := one e; split <;> omega))
    simp only [Finset.sum_add_distrib,Finset.sum_const,card_univ,smul_eq_mul,mul_one,
      Finset.sum_boole] at hsum
    have hc : (∑ e, c e) = (univ.filter (fun k : E × J => 0 < x k)).card := by
      calc
        _ = ∑ e, ∑ j, if 0 < x (e,j) then 1 else 0 := by simp [c,z]
        _ = ∑ k : E × J, if 0 < x k then 1 else 0 := (Fintype.sum_prod_type (fun k : E × J => if 0 < x k then (1:ℕ) else 0)).symm
        _ = _ := by simp
    change Fintype.card E + ((univ.filter (fun e => 1 < c e)).card : ℕ) ≤ ∑ e, c e at hsum
    rw [hc] at hsum
    simp only [Fintype.card_sum,Fintype.card_prod] at cap
    change (univ.filter (fun e => 1 < c e)).card ≤ _
    omega

/-- Select one of the observed half-mass marks so that at least half the
aggregate weight is weakly on each side, including repeated marks. -/
theorem weighted_median {A K : Type*} [Fintype A] [Nonempty A] [LinearOrder K]
    (mark : A → K) (w : A → ℝ) (nonneg : ∀ i, 0 ≤ w i) :
    ∃ m : A, (∑ i, w i)/2 ≤ ∑ i ∈ univ.filter (fun i => mark i ≤ mark m), w i ∧
      (∑ i, w i)/2 ≤ ∑ i ∈ univ.filter (fun i => mark m ≤ mark i), w i := by
  classical
  let W := ∑ i, w i
  let B (k : K) := univ.filter (fun i => mark i ≤ k)
  let C := univ.filter (fun i => W/2 ≤ ∑ a ∈ B (mark i), w a)
  obtain ⟨j,_,top⟩ := univ.exists_max_image mark univ_nonempty
  have full : B (mark j) = univ := eq_univ_iff_forall.mpr (fun i => mem_filter.mpr ⟨mem_univ _,top _ (mem_univ _)⟩)
  have Wpos : 0 ≤ W := sum_nonneg (fun i _ => nonneg i)
  have cne : C.Nonempty := ⟨j,mem_filter.mpr ⟨mem_univ _,by rw [full]; change W/2 ≤ W; linarith⟩⟩
  obtain ⟨m,hm,lowest⟩ := C.exists_min_image mark cne
  refine ⟨m,(mem_filter.mp hm).2,?_⟩
  let L := univ.filter (fun i => mark i < mark m)
  have small : (∑ i ∈ L, w i) ≤ W/2 := by
    by_cases ne : L.Nonempty
    · obtain ⟨a,ha,topa⟩ := L.exists_max_image mark ne
      have am := (mem_filter.mp ha).2
      have notin : a ∉ C := fun h => am.not_ge (lowest a h)
      have tooSmall : ¬ W/2 ≤ ∑ i ∈ B (mark a), w i := fun h => notin (mem_filter.mpr ⟨mem_univ _,h⟩)
      have sub : L ⊆ B (mark a) := fun i hi => mem_filter.mpr ⟨mem_univ _,topa i hi⟩
      exact (sum_le_sum_of_subset_of_nonneg sub (fun i _ _ => nonneg i)).trans (le_of_not_ge tooSmall)
    · rw [Finset.not_nonempty_iff_eq_empty.mp ne,Finset.sum_empty]; linarith
  have part := sum_filter_add_sum_filter_not univ (fun i => mark i < mark m) w
  simp only [not_lt] at part
  change (∑ i ∈ L, w i) + _ = W at part
  change W/2 ≤ _
  linarith

/-- If the marks on the two sides represent half of each observer's value,
each child gets at most three quarters of the total value. -/
theorem bounds_at {A K : Type*} [Fintype A] [Nonempty A] [LinearOrder K]
    (mark : A → K) (w : A → ℝ)
    (left : A → K → ℝ) (hm : ∀ i, Monotone (left i))
    (half : ∀ i, left i (mark i) = w i / 2)
    (lo : ∀ i k, 0 ≤ left i k) (hi : ∀ i k, left i k ≤ w i) :
    ∀ m, ((∑ i, w i)/2 ≤ ∑ i ∈ univ.filter (fun i => mark i ≤ mark m), w i ∧
      (∑ i, w i)/2 ≤ ∑ i ∈ univ.filter (fun i => mark m ≤ mark i), w i) →
      (∑ i : A, left i (mark m)) ≤ 3*(∑ i, w i)/4 ∧
      (∑ i : A, (w i - left i (mark m))) ≤ 3*(∑ i, w i)/4 := by
  classical
  rintro m ⟨wl,wr⟩
  let k := mark m
  let L := univ.filter (fun i => mark i ≤ k)
  let U := univ.filter (fun i => k ≤ mark i)
  have lower : (∑ i ∈ L, w i)/2 ≤ ∑ i, left i k := by
    rw [Finset.sum_div]
    exact (sum_le_sum (fun i (h : i ∈ L) => (half i).symm ▸ hm i (mem_filter.mp h).2)).trans
      (sum_le_sum_of_subset_of_nonneg (subset_univ L) (fun i _ _ => lo i k))
  have upper : (∑ i ∈ U, w i)/2 ≤ ∑ i : A, (w i - left i k) := by
    rw [Finset.sum_div]
    apply (sum_le_sum (s := U) (fun i h => (show w i/2 ≤ w i - left i k by
      have bound := hm i (mem_filter.mp h).2; rw [half i] at bound; linarith))).trans
    exact sum_le_sum_of_subset_of_nonneg (subset_univ U) (fun i _ _ => sub_nonneg.mpr (hi i k))
  change _ ≤ ∑ i ∈ L, w i at wl
  change _ ≤ ∑ i ∈ U, w i at wr
  change (∑ i, left i k) ≤ _ ∧ (∑ i : A, (w i - left i k)) ≤ _
  rw [Finset.sum_sub_distrib] at upper ⊢
  constructor <;> linarith

end CakeCutting.CommonShares
