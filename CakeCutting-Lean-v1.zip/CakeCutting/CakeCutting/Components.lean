import CakeCutting.DecisionTree
import CakeCutting.PhysicalCuts

/-! One-query forward and inverse access to suffixes of a list of physical
components. Component order can differ from geometric order. Empty components,
empty bundles, plateaus and cut replies beyond the queried component are allowed. -/
namespace CakeCutting.Components
open Set MeasureTheory DecisionTree

inductive Mark : Bundle → Type
  | empty : Mark []
  | here {a : Interval} {s : Bundle} (p : Point) (left : a.left ≤ p) (right : p ≤ a.right) :
    Mark (a::s)
  | later {a : Interval} {s : Bundle} (p : Mark s) : Mark (a::s)

/-- Records store a single observer's mass for each component. -/
def total (record : Interval → ℝ) (s : Bundle) := (s.map record).sum

noncomputable def mass (v : Valuation) (a : Interval) := v.measure.real (Icc a.left a.right)

noncomputable def retained (v : Valuation) : {s : Bundle} → Mark s → ℝ
  | _,.empty => 0
  | a::s,.here p _ _ => v.measure.real (Icc p a.right) + total (mass v) s
  | _::_,.later p => retained v p

theorem interval_add (v : Valuation) (a : Interval) (p : Point) (hl : a.left ≤ p) (hr : p ≤ a.right) :
    v.measure.real (Icc a.left p) + v.measure.real (Icc p a.right) = mass v a := by
  letI := v.finite
  letI := v.atomless
  have h := measureReal_union_add_inter (μ := v.measure) (s := Icc a.left p)
    (t := Icc p a.right) measurableSet_Icc
  simpa [mass,Icc_union_Icc_eq_Icc hl hr,Icc_inter_Icc_eq_singleton hl hr,Measure.real] using h.symm

theorem recorded_total (v : Valuation) (record : Interval → ℝ) (s : Bundle)
    (ok : ∀ a ∈ s, record a = mass v a) : total record s = total (mass v) s := by
  unfold total
  rw [List.map_congr_left ok]

/-- Read a suffix by evaluating the retained part of its boundary component. -/
noncomputable def eval {n : ℕ} (i : Fin n) (record : Interval → ℝ) :
    {s : Bundle} → Mark s → Tree n ℝ
  | _,.empty => .ret 0
  | a::s,.here p _ _ => .ask (.eval i p a.right) (fun (w : ℝ) => .ret (w + total record s))
  | _::_,.later p => eval i record p

theorem eval_good {n : ℕ} (v : Fin n → Valuation) (i : Fin n) (record : Interval → ℝ)
    {s : Bundle} (p : Mark s) (ok : ∀ a ∈ s, record a = mass (v i) a) :
    Good v (· = retained (v i) p) 1 (eval i record p) := by
  induction p with
  | empty => rfl
  | here p hl hr =>
    refine ⟨⟨_,hr,rfl⟩,?_⟩
    rintro _ ⟨_,rfl⟩
    exact congrArg (_ + ·) (recorded_total _ _ _ (fun a ha => ok a (List.mem_cons_of_mem _ ha)))
  | later p ih => exact ih (fun a ha => ok a (List.mem_cons_of_mem _ ha))

/-- From the recorded totals choose the boundary component. The answer to
an unrestricted cut is clamped to this component. This also handles a valid
answer strictly beyond its right endpoint. -/
noncomputable def cut {n : ℕ} (i : Fin n) (record : Interval → ℝ) (w : ℝ) :
    (s : Bundle) → Tree n (Mark s)
  | [] => .ret .empty
  | a::s => if w ≤ total record s then
      bind (cut i record w s) (fun p => .ret (.later p))
    else .ask (.cut i a.left (record a + total record s - w)) fun (p : Point) =>
      .ret (.here (max a.left (min p a.right)) (le_max_left ..) (max_le a.ordered (min_le_right ..)))

theorem cut_good {n : ℕ} (v : Fin n → Valuation) (i : Fin n) (record : Interval → ℝ)
    (w : ℝ) (nonneg : 0 ≤ w) (s : Bundle) (cap : w ≤ total record s)
    (ok : ∀ a ∈ s, record a = mass (v i) a) :
    Good v (fun p => retained (v i) p = w) 1 (cut i record w s) := by
  induction s with
  | nil =>
    have hw : w = 0 := le_antisymm (by simpa [total] using cap) nonneg
    simp [cut,retained,hw]
  | cons a s ih =>
    have head := ok a (List.mem_cons_self ..)
    have tail := recorded_total _ _ _ (fun b hb => ok b (List.mem_cons_of_mem _ hb))
    simp only [total,List.map_cons,List.sum_cons] at cap
    change w ≤ record a + total record s at cap
    by_cases small : w ≤ total record s
    · rw [cut,if_pos small]
      apply bind_good v (fun p => retained (v i) p = w) _ _ _ 1 0
        (ih small (fun b hb => ok b (List.mem_cons_of_mem _ hb)))
      intro p hp
      exact (good_ret ..).2 hp
    · rw [cut,if_neg small]
      let u := record a + total record s - w
      have lo : 0 ≤ u := sub_nonneg.mpr cap
      have hi : u ≤ mass (v i) a := by dsimp [u]; linarith
      obtain ⟨c,hc,_,cm⟩ := PhysicalCuts.cut_exists (v i) a.left a.right a.ordered u lo hi
      refine ⟨⟨c,hc,cm⟩,?_⟩
      intro p
      change Point at p
      rintro ⟨hl,hp⟩
      let z := max a.left (min p a.right)
      have za : a.left ≤ z := le_max_left ..
      have zb : z ≤ a.right := max_le a.ordered (min_le_right ..)
      have vz : (v i).measure.real (Icc a.left z) = u := by
        letI := (v i).finite
        by_cases pr : (p : Point) ≤ a.right
        · simpa [z,min_eq_left pr,max_eq_right hl] using hp
        · have zz : z = a.right := by simp [z,min_eq_right (le_of_not_ge pr),max_eq_right a.ordered]
          rw [zz]
          refine le_antisymm (le_trans (measureReal_mono (Icc_subset_Icc_right (le_of_not_ge pr))) hp.le) hi
      have add := interval_add (v i) a z za zb
      change (v i).measure.real (Icc z a.right) + total (mass (v i)) s = w
      dsimp [u] at vz
      linarith

end CakeCutting.Components
