import CakeCutting.Repair
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-! Quantitative cutter guarantee following an equal division and a certified
trim. Values here are those of the cutter. -/
namespace CakeCutting.Core
open Finset

theorem cutter_advantage {R : Type*} [Fintype R] [DecidableEq R]
    (hn : 2 ≤ Fintype.card R) (r : R) (value : R → ℝ) (whole : R → Prop)
    (order : R ≃ Fin (Fintype.card R)) (τ residue : ℝ)
    (cert : ∀ j, whole j ∨ ∃ i, order i < order j)
    (equal_pieces : ∀ j, whole j → value j = τ) (bounded : ∀ j, value j ≤ τ)
    (ef : ∀ j, value j ≤ value r)
    (account : residue = (Fintype.card R : ℝ)*τ - ∑ j, value j) :
    value r = τ ∧ ∃ h ≠ r, residue / ((Fintype.card R : ℝ)-1) ≤ value r - value h := by
  classical
  let j := order.symm ⟨0,by omega⟩
  have lowest : (order j).val = 0 := by simp [j]
  have w : whole j := (cert j).resolve_right (by
    rintro ⟨i,lt⟩
    have : (order i).val < (order j).val := lt
    omega)
  have vr := le_antisymm (bounded r) ((equal_pieces j w).symm ▸ ef j)
  refine ⟨vr,?_⟩
  let D := (univ : Finset R).erase r
  have size : D.card + 1 = Fintype.card R := by simp [D,card_erase_of_mem, Nat.sub_add_cancel (by omega : 1 ≤ Fintype.card R)]
  have dne : D.Nonempty := card_pos.mp (by omega)
  have cast : (D.card : ℝ)+1 = (Fintype.card R : ℝ) := by exact_mod_cast size
  have positive : (D.card : ℝ) ≠ 0 := by exact_mod_cast (card_pos.mpr dne).ne'
  have total : ∑ j ∈ D, (value r - value j) = residue := by
    have sum := sum_erase_add (univ : Finset R) (fun j => value r - value j) (mem_univ r)
    simp only [sub_self,add_zero] at sum
    rw [show D = univ.erase r from rfl,sum,sum_sub_distrib, sum_const,card_univ,nsmul_eq_mul,vr,account]
  have sum_le : (∑ _j ∈ D, residue / (D.card : ℝ)) ≤ ∑ j ∈ D, (value r - value j) := by
    rw [sum_const,nsmul_eq_mul,total,mul_comm,div_mul_cancel₀ _ positive]
  obtain ⟨h,hh,large⟩ := exists_le_of_sum_le dne sum_le
  refine ⟨h,(mem_erase.mp hh).1,?_⟩
  rwa [show (Fintype.card R : ℝ)-1 = D.card by linarith]

end CakeCutting.Core
