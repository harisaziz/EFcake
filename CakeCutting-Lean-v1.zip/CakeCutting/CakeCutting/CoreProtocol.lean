import CakeCutting.EqualPieces
import CakeCutting.Core

/-! Physical Core, including the cutter guarantee, exact partition of the
active piece, and records for every interval of the outputs. -/
namespace CakeCutting.CoreProtocol
open DecisionTree Components Registry AdaptiveTrim BoundaryRecords Set Finset MeasureTheory
noncomputable section
variable {n : ℕ} [NeZero n]

def recordAll (s : Pieces n) (o : CertifiedTrim.Output s) (rec : Records n) :
    List (Fin n) → Tree n (Records n)
  | [] => .ret rec
  | j::js => bind (refresh rec (boundary (o.mark j))) fun t => recordAll s o t js

omit [NeZero n] in
theorem recordAll_good (s : Pieces n) (v : Fin n → Valuation) (o : CertifiedTrim.Output s) (rec : Records n)
    (l : List (Fin n)) (ok : correct v s rec) :
    Good v (fun T => Preserves v rec T ∧ ∀ j ∈ l,
      Known v T (suffix (o.mark j)) ∧ Known v T (trimmings (o.mark j))) (l.length*(2*n))
      (recordAll s o rec l) := by
  induction l generalizing rec with
  | nil => exact (good_ret ..).2 ⟨preserves_refl v rec,by simp⟩
  | cons j js ih =>
    rw [List.length_cons,Nat.succ_mul,Nat.add_comm]
    apply bind_good v _ _ _ _ _ _ (boundary_good v rec (o.mark j) (fun i => ok i j))
    rintro t ⟨keep,sk,tk⟩
    apply OracleTree.strengthen _ _ _ _ _ (ih t (fun i k e he => keep i e (ok i k e he)))
    rintro T ⟨more,rest⟩
    refine ⟨preserves_trans keep more,?_⟩
    intro k hk
    rcases List.mem_cons.mp hk with rfl | old
    · exact ⟨fun i e he => more i e (sk i e he),fun i e he => more i e (tk i e he)⟩
    · exact rest k old

def join {R : Type} [Fintype R] (s : R → Bundle) : Bundle := univ.toList.flatMap s

theorem join_points {R : Type} [Fintype R] (s : R → Bundle) : (join s).points = ⋃ i, (s i).points := by
  ext x
  simp only [join,Bundle.points,mem_setOf_eq,List.mem_flatMap,mem_toList,Finset.mem_univ,true_and,
    mem_iUnion]
  constructor
  · rintro ⟨e,⟨i,hi⟩,hx⟩; exact ⟨i,e,hi,hx⟩
  · rintro ⟨i,e,hi,hx⟩; exact ⟨e,⟨i,hi⟩,hx⟩

theorem join_separate {R : Type} [Fintype R] (s : R → Bundle) (sep : ∀ i, Separate (s i))
    (ds : ∀ i j, i ≠ j → Disjoint (s i).points (s j).points) : Separate (join s) := by
  unfold join Separate
  apply List.pairwise_flatMap.mpr
  refine ⟨fun i _ => sep i,?_⟩
  apply (univ : Finset R).nodup_toList.imp
  intro i j ne a ha b hb
  apply Set.disjoint_left.mpr
  intro x hx hy
  exact Set.disjoint_left.mp (ds i j ne) (show x ∈ (s i).points from ⟨a,ha,hx⟩) ⟨b,hb,hy⟩

structure Output (n : ℕ) where
  held : Allocation n
  residue : Bundle
  record : Records n

def report (s : Pieces n) (o : CertifiedTrim.Output s) (rec : Records n) : Output n :=
  ⟨fun i => suffix (o.mark (o.holder.symm i)),join (fun j => trimmings (o.mark j)),rec⟩

def k (n : ℕ) := n-1
def label : Fin n ≃ Fin (k n + 1) := finCongr (by unfold k; have := NeZero.pos n; omega)
def feed (z : EqualPieces.Out n (k n+1)) : Pieces n := fun j => z.piece (label j)

def cost (n : ℕ) := k n*(1+2*n) + (CertifiedTrim.budget n + n*(2*n))
def protocol (r : Fin n) (s : Bundle) (rec : Records n) : Tree n (Output n) :=
  bind (EqualPieces.divide r (total (rec r) s / n) s rec (k n)) fun z =>
    bind (CertifiedTrim.protocol (feed z) z.record) fun o =>
      bind (recordAll _ o z.record univ.toList) fun T => .ret (report _ o T)

structure Spec (v : Fin n → Valuation) (r : Fin n) (s : Bundle) (rec : Records n) (z : Output n) : Prop where
  held_separate : ∀ i, Separate (z.held i)
  residue_separate : Separate z.residue
  pairwise : ∀ i j, i ≠ j → Disjoint (z.held i).points (z.held j).points
  leftover : ∀ i, Disjoint (z.held i).points z.residue.points
  cover : ∀ x, x ∈ s.points ↔ x ∈ z.residue.points ∨ ∃ i, x ∈ (z.held i).points
  ef : EnvyFree v z.held
  keep : Preserves v rec z.record
  held_known : ∀ i, Known v z.record (z.held i)
  residue_known : Known v z.record z.residue
  cutter : (v r).measure.real (z.held r).points = (v r).measure.real s.points / n
  advantage : ∃ i ≠ r, (v r).measure.real z.residue.points / ((n:ℝ)-1) ≤
    (v r).measure.real (z.held r).points - (v r).measure.real (z.held i).points

theorem protocol_good (hn : 2 ≤ n) (v : Fin n → Valuation) (r : Fin n) (s : Bundle) (rec : Records n)
    (sep : Separate s) (known : Known v rec s) : Good v (Spec v r s rec) (cost n) (protocol r s rec) := by
  classical
  let τ := total (rec r) s / n
  have old := recorded_total (v r) _ _ (known r)
  have size : k n+1 = n := by unfold k; omega
  have nr : (n:ℝ) ≠ 0 := by exact_mod_cast (by omega : n ≠ 0)
  have pos : 0 ≤ τ := by
    unfold τ; rw [old,total_eq_measure _ _ sep]; positivity
  have eq := EqualPieces.divide_good r v τ pos s rec (k n) known sep (by
    rw [size,← old]; dsimp [τ]; field_simp)
  apply bind_good v _ _ _ _ _ _ eq
  intro z hz
  let p := feed z
  have records : correct v p z.record := fun i j e he => hz.known (label j) i e he
  apply bind_good v _ _ _ _ _ _ (CertifiedTrim.protocol_good p z.record v records)
  intro o ho
  apply bind_good v _ _ _ _ (n*(2*n)) 0 (by simpa using recordAll_good p v o z.record univ.toList records)
  rintro T ⟨keep,all⟩
  apply (good_ret ..).2
  let S := fun j => suffix (o.mark j)
  let D := fun j => trimmings (o.mark j)
  let h := o.holder
  have sp (j) := hz.separate (label j)
  have parts (j) := partition (o.mark j) (sp j)
  have left (j) : (D j).points ⊆ (p j).points := (parts j).1 ▸ Set.subset_union_left
  have right (j) : (S j).points ⊆ (p j).points := (parts j).1 ▸ Set.subset_union_right
  have dis (j l : Fin n) (ne : j ≠ l) : Disjoint (p j).points (p l).points :=
    hz.disjoint _ _ (fun eq => ne (label.injective eq))
  have ddis (j l) (ne : j ≠ l) : Disjoint (D j).points (D l).points := (dis j l ne).mono (left j) (left l)
  have val (j i) : (v i).measure.real (S j).points = o.value j i :=
    (suffix_value (v i) (o.mark j) (sp j)).symm.trans (ho.1 j i).symm
  have common (j) : (v r).measure.real (p j).points = τ :=
    (total_eq_measure _ _ (sp j)).symm.trans (hz.equal (label j))
  let amt := fun i => (v r).measure.real (S (h.symm i)).points
  let W := fun i => o.mark (h.symm i) = wholeMark (p (h.symm i))
  let rank := h.symm.trans o.rank
  have cert (i) : W i ∨ ∃ a, rank a < rank i := by
    rcases ho.2.2 (h.symm i) with w | ⟨a,lt,_⟩
    · exact Or.inl w
    · exact Or.inr ⟨h a,by simpa [rank] using lt⟩
  have whole (i) (w : W i) : amt i = τ := by
    change (v r).measure.real (S (h.symm i)).points = τ
    rw [← suffix_value _ _ (sp _),show o.mark (h.symm i) = _ from w]
    exact (endpoint_values (v r) (p (h.symm i))).2.trans (hz.equal _)
  have cutterEF (i) : amt i ≤ amt r := by
    dsimp only [amt]; rw [val,val]
    simpa [h] using ho.2.1 (h.symm r) (h.symm i)
  have account : (v r).measure.real (join D).points = (n:ℝ)*τ - ∑ i, amt i := by
    letI := (v r).finite
    rw [join_points,measureReal_iUnion_fintype (fun _ _ => ddis _ _) (fun j => measurable_points _)]
    have one (j) : (v r).measure.real (D j).points + (v r).measure.real (S j).points = τ := by
      rw [← measureReal_union (parts j).2 (measurable_points _),(parts j).1,common]
    have totals := Finset.sum_congr (s₁ := (univ : Finset (Fin n))) rfl (fun j _ => one j)
    simp only [sum_add_distrib,sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul] at totals
    rw [show (∑ i, amt i) = ∑ j, (v r).measure.real (S j).points from h.symm.sum_comp (fun j => (v r).measure.real (S j).points)]
    linarith
  have q := Core.cutter_advantage (R := Fin n) (by simpa using hn) r amt W
    (rank.trans (finCongr (Fintype.card_fin n).symm)) τ _ cert whole (fun i => by
      letI := (v r).finite
      exact (measureReal_mono (right (h.symm i))).trans_eq (common _)) cutterEF (by simpa using account)
  refine ⟨fun i => suffix_separate _ (sp _),join_separate D (fun j => trimmings_separate _ (sp j)) ddis,
    ?_,?_,?_,?_,preserves_trans hz.keep keep,fun i => (all (h.symm i)).1,?_,?_,?_⟩
  · intro i j ne
    exact (dis _ _ (fun eq => ne (h.symm.injective eq))).mono (right _) (right _)
  · intro i
    change Disjoint (S (h.symm i)).points (join D).points
    rw [join_points,Set.disjoint_iUnion_right]
    intro j; by_cases eq : h.symm i = j
    · subst j; exact (parts _).2.symm
    · exact (dis _ _ eq).mono (right _) (left _)
  · intro x
    change x ∈ s.points ↔ x ∈ (join D).points ∨ ∃ i, x ∈ (S (h.symm i)).points
    rw [join_points,mem_iUnion,hz.cover x]
    constructor
    · rintro ⟨j,hj⟩
      let a := label.symm j
      have hit : x ∈ (p a).points := by simpa [p,feed,a] using hj
      rw [← (parts a).1] at hit
      rcases hit with hd | hs
      · exact Or.inl ⟨a,hd⟩
      · exact Or.inr ⟨h a,by simpa using hs⟩
    · rintro (⟨j,hj⟩ | ⟨i,hi⟩)
      · exact ⟨label j,left _ hj⟩
      · exact ⟨label (h.symm i),right _ hi⟩
  · intro i j
    letI := (v i).finite
    apply (ENNReal.toReal_le_toReal (measure_ne_top _ _) (measure_ne_top _ _)).mp
    change (v i).measure.real (S (h.symm j)).points ≤ (v i).measure.real (S (h.symm i)).points
    rw [val,val]; simpa [h] using ho.2.1 (h.symm i) (h.symm j)
  · intro i e he
    obtain ⟨j,_,hit⟩ := List.mem_flatMap.mp he
    exact (all j).2 i e hit
  · change amt r = _; rw [q.1]; dsimp [τ]; rw [old,total_eq_measure _ _ sep]
  · simpa [amt,h,report] using q.2

end
end CakeCutting.CoreProtocol
