import CakeCutting.Model
import CakeCutting.OracleTree

/-! Composable typed decision trees for the Robertson–Webb protocol.
Every internal node costs one query, with a separate continuation for each
answer. Compilation yields precisely the history-only protocol of Model. -/
namespace CakeCutting.DecisionTree

abbrev Tree (n : ℕ) (α : Type) := OracleTree.Tree (@Query.Answer n) α
variable {n : ℕ} {α β : Type}
abbrev bind (t : Tree n α) (g : α → Tree n β) := OracleTree.bind t g
abbrev Good (v : Fin n → Valuation) (post : α → Prop) := OracleTree.Good (Valid v) post
@[simp] theorem good_ret (v : Fin n → Valuation) (P : α → Prop) (k : ℕ) (a : α) :
    Good v P k (.ret a) ↔ P a := OracleTree.good_ret .. 
theorem mono (v : Fin n → Valuation) (post : α → Prop) {k l : ℕ} (hkl : k ≤ l)
    (t : Tree n α) (h : Good v post k t) : Good v post l t := OracleTree.mono _ _ hkl t h
theorem bind_good (v : Fin n → Valuation) (P : α → Prop) (Q : β → Prop)
    (t : Tree n α) (g : α → Tree n β) (k l : ℕ)
    (h : Good v P k t) (hg : ∀ a, P a → Good v Q l (g a)) :
    Good v Q (k+l) (bind t g) := OracleTree.bind_good _ _ _ t g k l h hg

/-- Replay keeps the previous node if the stored query is inconsistent.
Only correctly typed reachable histories enter the correctness proof. -/
noncomputable def advance (t : Tree n α) (e : (q : Query n) × q.Answer) : Tree n α := by
  classical
  cases t with
  | ret a => exact .ret a
  | ask q next =>
    exact if h : e.1 = q then next (h ▸ e.2) else .ask q next

private theorem advance_ask (q : Query n) (next : q.Answer → Tree n α) (a : q.Answer) :
    advance (.ask q next) ⟨q,a⟩ = next a := by simp [advance]

noncomputable def replay (t : Tree n α) : History n → Tree n α
  | [] => t
  | e :: h => advance (replay t h) e

noncomputable def compile (t : Tree n (Allocation n)) (h : History n) : Step n :=
  match replay t h with
  | .ret X => .finish X
  | .ask q _ => .ask q

theorem compiles (t : Tree n (Allocation n)) (v : Fin n → Valuation)
    (k : ℕ) (h : History n) :
    Good v (fun X => Complete X ∧ EnvyFree v X) k (replay t h) →
      DeliversWithin (compile t) v k h := by
  induction k generalizing h with
  | zero =>
    cases e : replay t h <;> simp [compile,e,Good,OracleTree.Good,DeliversWithin]
  | succ k ih =>
    cases e : replay t h with
    | ret X => simp [Good,OracleTree.Good,DeliversWithin,compile,e]
    | ask q next =>
      intro ok
      simp only [Good,OracleTree.Good,DeliversWithin,compile,e] at ok ⊢
      refine ⟨ok.1,fun a ha => ih (⟨q,a⟩ :: h) ?_⟩
      simpa only [replay,e,advance_ask] using ok.2 a ha

theorem start (t : Tree n (Allocation n)) (v : Fin n → Valuation) (k : ℕ)
    (h : Good v (fun X => Complete X ∧ EnvyFree v X) k t) :
    DeliversWithin (compile t) v k [] := compiles t v k [] h

end CakeCutting.DecisionTree
