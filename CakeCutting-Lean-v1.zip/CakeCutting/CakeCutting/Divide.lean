import CakeCutting.DominatedGroup

/-! A bounded history-only protocol for every population size. All recursive
calls act on the same physical cake and use records already known to their members. -/
namespace CakeCutting.Division
open Finset Set MeasureTheory Components AdaptiveTrim BoundaryRecords DecisionTree
noncomputable section

def logFactor (n : ℕ) := (2*n).log2+1

theorem log_mono {n N : ℕ} (hn : 0 < n) (le : n ≤ N) : logFactor n ≤ logFactor N := by
  unfold logFactor
  apply Nat.add_le_add_right
  apply (Nat.le_log2 (by omega : 2*N ≠ 0)).2
  exact ((Nat.le_log2 (by omega : 2*n ≠ 0)).1 le_rfl).trans (by omega)

theorem round_bound (n : ℕ) (hn : 2 ≤ n) : roundCost n ≤ 1700*n^5*logFactor n := by
  let L := logFactor n
  have pos : 0 < n := by omega
  have lpos : 0 < L := by simp [L,logFactor]
  have a : n ≤ n^5 := by simpa using Nat.pow_le_pow_right pos (by decide : 1 ≤ 5)
  have b : n*n ≤ n^5 := by simpa [pow_two] using Nat.pow_le_pow_right pos (by decide : 2 ≤ 5)
  have up := Nat.le_mul_of_pos_right (n^5) lpos
  have w : (n-1)*(1+2*n) ≤ 3*(n^5*L) := by
    calc
      _ ≤ n*(1+2*n) := Nat.mul_le_mul_right _ (Nat.sub_le ..)
      _ = n + 2*(n*n) := by ring
      _ ≤ _ := by have := a.trans up; have := b.trans up; omega
  have k : n*(2*n) ≤ 2*(n^5*L) := by rw [show n*(2*n)=2*(n*n) by ring]; exact Nat.mul_le_mul_left _ (b.trans up)
  have trim : CertifiedTrim.budget n ≤ 774*(n^5*L) := by simpa only [Nat.mul_assoc] using CertifiedTrim.query_bound n pos
  have factor : 2*n+8 ≤ 6*n := by omega
  have share : RepairRounds.rounds n * ((n*(n*n))*(3*n)) ≤ 54*(n^5*L) := by
    change (3*((2*n+8)*L))*_ ≤ _
    calc
      _ ≤ (3*((6*n)*L))*((n*(n*n))*(3*n)) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 3 (Nat.mul_le_mul_right L factor))
      _ = _ := by ring
  change (n-1)*(1+2*n)+(CertifiedTrim.budget n+n*(2*n)) +
    (RepairRounds.rounds n*((n*(n*n))*(3*n))+(CertifiedTrim.budget n+n*(2*n))) ≤ 1700*n^5*L
  rw [Nat.mul_assoc 1700]; omega

def perLevel (N : ℕ) := 3400*N^7*logFactor N

theorem level_bound {n N : ℕ} (hn : 2 ≤ n) (le : n ≤ N) : (n*n+1)*roundCost n ≤ perLevel N := by
  have bound := round_bound n hn
  have nl : 0 < n*n := Nat.mul_pos (by omega) (by omega)
  calc
    _ ≤ (2*(n*n))*(1700*n^5*logFactor n) := Nat.mul_le_mul (by omega) bound
    _ = 3400*n^7*logFactor n := by ring
    _ ≤ _ := Nat.mul_le_mul (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left le _)) (log_mono (by omega) le)

def restrict (r : Records n) (H : Finset (Fin n)) : Records H.card := fun j => r (name H j)

def divide : ℕ → (n : ℕ) → Bundle → Records n → Tree n (Allocation n)
  | 0,_,_,_ => .ret (fun _ => [])
  | k+1,n,C,r => by
    classical
    if hn : 2 ≤ n then
      letI : NeZero n := ⟨by omega⟩
      exact bind (loop (n*n+1) (initial C r)) fun z =>
        bind (rename (name z.members) (divide k z.members.card z.state.residue (restrict z.state.record z.members))) fun F =>
          .ret (finish z.state z.members F)
    else exact .ret (fun _ => C)

set_option maxHeartbeats 600000 in
theorem divide_good (N k : ℕ) : ∀ (n : ℕ) (C : Bundle) (r : Records n) (v : Fin n → Valuation)
    (_ : 0 < n) (_ : n ≤ k) (_ : n ≤ N) (_ : Separate C) (_ : Known v r C),
    Good v (Divided v C) (k*perLevel N) (divide k n C r) := by
  induction k with
  | zero => intros; omega
  | succ k ih =>
    intro n C r v pos depth le sep know
    rw [divide]
    by_cases hn : 2 ≤ n
    · rw [dif_pos hn]
      letI : NeZero n := ⟨by omega⟩
      have loopOk := loop_good hn v C (n*n+1) (initial C r) (init_ok v C r sep know) (by omega)
      rw [Nat.succ_mul,Nat.add_comm]
      apply bind_good v _ _ _ _ _ _ (mono v _ (level_bound hn le) _ loopOk)
      rintro z ⟨inv,group⟩
      have less : z.members.card < n := by simpa using (z.members.card_lt_iff_ne_univ).2 group.2.1
      have gp := Finset.card_pos.mpr group.1
      have recurse := ih z.members.card _ (restrict z.state.record z.members) (v ∘ name z.members) gp (by omega) (by omega)
        inv.res (fun j => inv.residual (name _ j))
      apply bind_good v _ _ _ _ _ 0 (rename_good v (name z.members) _ _ _ recurse)
      intro F hf
      exact (good_ret ..).2 (group_finish v C _ _ _ inv group hf)
    · rw [dif_neg hn]
      apply (good_ret ..).2
      have one : n=1 := by omega
      subst n
      refine ⟨fun _ => sep,fun i j ne => False.elim (ne (Subsingleton.elim _ _)),?_,fun _ _ => le_rfl⟩
      intro p; exact ⟨fun hp => ⟨0,hp⟩,fun ⟨_,hp⟩ => hp⟩

def whole : Interval := ⟨⟨0,by simp⟩,⟨1,by simp⟩,by change (0:ℝ) ≤ 1; norm_num⟩

theorem whole_cover (p : Point) : p ∈ Bundle.points [whole] := by
  refine ⟨whole,by simp, p.property.1,?_⟩
  rcases lt_or_eq_of_le p.property.2 with lt|eq
  · exact Or.inl lt
  · exact Or.inr ⟨Subtype.ext eq,rfl⟩

def startTree (n : ℕ) : Tree n (Allocation n) :=
  bind (refresh (fun _ _ => 0) [whole]) fun r => divide n n [whole] r

theorem start_good (n : ℕ) (hn : 2 ≤ n) (v : Fin n → Valuation) :
    Good v (fun X => Complete X ∧ EnvyFree v X) (3401*n^8*logFactor n) (startTree n) := by
  have pos : 0 < n := by omega
  have small : n ≤ n^8 := by simpa using Nat.pow_le_pow_right pos (by decide : 1 ≤ 8)
  have up : n^8 ≤ n^8*logFactor n := Nat.le_mul_of_pos_right _ (Nat.succ_pos _)
  have budget : n+n*perLevel n ≤ 3401*n^8*logFactor n := by
    unfold perLevel
    have eq : n*(3400*n^7*logFactor n) = 3400*(n^8*logFactor n) := by ring
    rw [eq,Nat.mul_assoc 3401]; have := small.trans up; omega
  apply mono v _ budget
  apply bind_good v _ _ _ _ n _ (by simpa using refresh_good v (fun _ _ => 0) [whole])
  rintro r ⟨_,ok⟩
  apply OracleTree.strengthen _ _ _ _ _ (divide_good n n n [whole] r v pos le_rfl le_rfl (by simp [Separate]) ok)
  intro X h
  exact ⟨⟨h.dis,fun p => (h.cover p).1 (whole_cover p)⟩,h.ef⟩

end
end CakeCutting.Division

namespace CakeCutting

/-- The manuscript's full statement, for all finite atomless valuations and all valid replies. -/
theorem mainClaim_proof : MainClaim := by
  refine ⟨3401,by decide,fun n hn => ⟨DecisionTree.compile (Division.startTree n),fun v => ?_⟩⟩
  exact DecisionTree.start _ v _ (Division.start_good n hn v)

end CakeCutting
