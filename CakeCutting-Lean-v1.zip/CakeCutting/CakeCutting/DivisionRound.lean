import CakeCutting.DivisionState

/-! One physical iteration either exposes a proper dominated group or strictly
increases the number of dominated ordered pairs while preserving the exact partition. -/
namespace CakeCutting.Division
open Finset Set MeasureTheory Components AdaptiveTrim BoundaryRecords DecisionTree RepairProtocol
noncomputable section
variable {n : ℕ} [NeZero n]

def after (w : RepairProtocol.Out n) : State n := ⟨w.held,w.residue,w.record⟩
inductive Outcome (n : ℕ) where
  | split (s : State n) (H : Finset (Fin n))
  | next (s : State n)

def roundCost (n : ℕ) := CoreProtocol.cost n + RepairProtocol.cost n

def round (x : State n) : Tree n (Outcome n) := by
  classical
  exact bind (CoreProtocol.protocol 0 x.residue x.record) fun y =>
    let z := add x y (Equiv.refl _)
    if ex : ∃ H, group z H then .ret (.split z (Classical.choose ex)) else
      let m := chooseMove x y
      bind (RepairProtocol.program (add x y m.perm).held y.residue y.record m.alpha) fun w => .ret (.next (after w))

def StepOK (v : Fin n → Valuation) (C : Bundle) (x : State n) : Outcome n → Prop
  | .split z H => Invariant v C z ∧ group z H
  | .next z => Invariant v C z ∧ (pairs x).card < (pairs z).card

set_option maxHeartbeats 800000 in
theorem round_good (hn : 2 ≤ n) (v : Fin n → Valuation) (C : Bundle) (x : State n) (hx : Invariant v C x) :
    Good v (StepOK v C x) (roundCost n) (round x) := by
  classical
  apply bind_good v _ _ _ _ _ _ (CoreProtocol.protocol_good hn v 0 x.residue x.record hx.res hx.residual)
  intro y h
  have hy := core_inv h
  let z := add x y (Equiv.refl _)
  have hz := provisional hx hy h.keep
  by_cases yes : ∃ H, group z H
  · rw [dif_pos yes]
    exact (good_ret ..).2 ⟨hz,Classical.choose_spec yes⟩
  · rw [dif_neg yes]
    let m := chooseMove x y
    let d := add x y m.perm
    obtain ⟨positive,legal,absent⟩ := core_move hn hx h yes
    obtain ⟨_,lb,ub,loss,gain⟩ := legal
    change t n ^ (n+1) ≤ m.alpha at lb
    change m.alpha ≤ (t n)^2 at ub
    have dp := add_part C x y m.perm hx.toPartition hy.toPartition
    have nr : (2:ℝ) ≤ n := by exact_mod_cast hn
    have Kp : 0 < K n := by unfold K; positivity
    have tp : 0 < t n := one_div_pos.mpr Kp
    have apos : 0 < m.alpha := lt_of_lt_of_le (pow_pos tp _) lb
    have floor : 1 / (4*(n:ℝ)^2)^(n+1) ≤ m.alpha := by simpa only [t,K,div_pow,one_pow] using lb
    have cap : m.alpha ≤ 1/(8*(n:ℝ)^2) := by
      apply ub.trans
      simp only [t,K,div_pow,one_pow]
      apply one_div_le_one_div_of_le (by positivity)
      nlinarith [sq_nonneg ((n:ℝ)^2-1),sq_nonneg ((n:ℝ)-1)]
    let M := fun i => val (v i) y.residue
    have pos (i) : 0 < M i := (positive i).trans_eq (res_obs hy i)
    have gapEq (i j) : gap y i j = (val (v i) (y.held i) - val (v i) (y.held j))/M i := by
      simp only [gap,held_obs hy,res_obs hy,M]
    have cg : K n * m.alpha ≤ gap y m.a (m.perm m.b) := by
      simpa [t,div_eq_mul_inv,mul_comm,m] using gain
    have input := Reassign.value_bounds (fun i j => val (v i) (x.held j)) (fun i j => val (v i) (y.held j))
      M pos (fun i j => (le_real ..).1 (hx.ef i j)) (fun i j => (le_real ..).1 (hy.ef i j))
      m.perm m.a m.b m.alpha (K n) (fun i => (gapEq ..) ▸ loss i) ((gapEq ..) ▸ cg)
    have eq (i j) := added_val m.perm (v i) hx.toPartition hy.toPartition j
    have envy (i j) : val (v i) (d.held j) ≤ val (v i) (d.held i) + m.alpha*M i := by
      simpa only [d,eq] using input.1 i j
    have far : (K n - 1)*m.alpha*M m.a ≤ val (v m.a) (d.held m.a) - val (v m.a) (d.held m.b) := by
      simpa only [d,eq] using input.2
    apply bind_good v _ _ _ _ _ 0 (RepairProtocol.program_good hn v d.held y.residue y.record m.alpha
      dp.sep hy.res dp.dis dp.apart (added_known _ hx hy h.keep) hy.residual positive apos cap floor envy)
    intro w hw
    apply (good_ret ..).2
    have iw : Invariant v C (after w) :=
      ⟨⟨hw.sep,hw.res_sep,hw.dis,hw.apart,fun p => (dp.cover p).trans (hw.cover p)⟩,hw.ef,hw.known,hw.res_known⟩
    refine ⟨iw,Progress.count_increases _ _ w.holder m.a m.b ?_ ?_ ?_⟩
    · intro i j old
      apply mem_filter.mpr
      refine ⟨Finset.mem_univ _,preserve_dom hx iw w.holder ?_ ?_ ?_ (mem_filter.mp old).2⟩
      · intro j
        have left : (x.held j).points ⊆ (d.held j).points := by
          rw [show (d.held j).points = _ from Buffered.append_points _ _]; exact Set.subset_union_left
        exact left.trans (hw.intact j)
      · intro j p hp
        rcases hw.contained j hp with old | ry
        · change p ∈ Bundle.points (x.held j ++ y.held (m.perm j)) at old
          rw [Buffered.append_points] at old
          rcases old with prior | yy
          · exact Or.inl prior
          · exact Or.inr ((h.cover p).2 (Or.inr ⟨_,yy⟩))
        · exact Or.inr ((h.cover p).2 (Or.inl ry))
      · exact fun p hp => (h.cover p).2 (Or.inl (hw.residual_sub hp))
    · exact fun h => absent (mem_filter.mp h).2
    · apply mem_filter.mpr
      refine ⟨Finset.mem_univ _,(dom_iff iw _ _).2 ?_⟩
      let unit := m.alpha*M m.a
      apply Progress.new_domination n hn unit
        (val (v m.a) (d.held m.a) - val (v m.a) (d.held m.b)) _ _ (mul_nonneg apos.le (pos _).le)
      · simpa only [unit,K,mul_assoc] using far
      · have a := hw.difference m.a m.b m.a
        have b := (le_real ..).1 (hw.ef m.a (w.holder m.a))
        change _ ≤ val (v m.a) (w.held m.a) - val (v m.a) (w.held (w.holder m.b))
        dsimp [unit,M]; nlinarith only [a,b]
      · simpa only [after,unit,M,mul_assoc] using hw.small m.a

end
end CakeCutting.Division
