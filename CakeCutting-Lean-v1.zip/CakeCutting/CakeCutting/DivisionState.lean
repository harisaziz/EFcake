import CakeCutting.RepairProtocol
import CakeCutting.Reassign
import CakeCutting.Progress

/-! Partial allocation invariant, disjoint extension, and the complete
record-only selection step for the physical division loop. -/
namespace CakeCutting.Division
open Finset Set MeasureTheory Components AdaptiveTrim BoundaryRecords RepairProtocol
noncomputable section
variable {n : ℕ}

abbrev State := CoreProtocol.Output
structure Partition (C : Bundle) (X : Allocation n) (R : Bundle) : Prop where
  sep : ∀ i, Separate (X i)
  res : Separate R
  dis : ∀ i j, i ≠ j → Disjoint (X i).points (X j).points
  apart : ∀ i, Disjoint (X i).points R.points
  cover : ∀ x, x ∈ C.points ↔ x ∈ R.points ∨ ∃ i, x ∈ (X i).points

structure Invariant (v : Fin n → Valuation) (C : Bundle) (s : State n) : Prop extends Partition C s.held s.residue where
  ef : EnvyFree v s.held
  known : ∀ i, Known v s.record (s.held i)
  residual : Known v s.record s.residue

def initial (C : Bundle) (r : Records n) : State n := ⟨fun _ => [],C,r⟩
theorem init_ok (v : Fin n → Valuation) (C : Bundle) (r : Records n) (sep : Separate C) (know : Known v r C) :
    Invariant v C (initial C r) :=
  ⟨⟨fun _ => List.Pairwise.nil,sep,by simp [initial,empty_points],by simp [initial,empty_points],
    by simp [initial,empty_points]⟩,fun _ _ => le_rfl,by simp [initial,Known],know⟩

def add (x y : State n) (π : Equiv.Perm (Fin n)) : State n :=
  ⟨fun i => x.held i ++ y.held (π i),y.residue,y.record⟩

theorem add_part (C : Bundle) (x y : State n) (π : Equiv.Perm (Fin n))
    (h : Partition C x.held x.residue) (g : Partition x.residue y.held y.residue) :
    Partition C (add x y π).held y.residue := by
  have sub (i) : (y.held i).points ⊆ x.residue.points := fun z hz => (g.cover z).2 (Or.inr ⟨i,hz⟩)
  have res : y.residue.points ⊆ x.residue.points := fun z hz => (g.cover z).2 (Or.inl hz)
  have apart (i j) := (h.apart i).mono_right (sub j)
  refine ⟨fun i => RepairPacking.append_separate _ _ (h.sep i) (g.sep _) (apart _ _),g.res,?_,?_,?_⟩
  · intro i j ne; simp only [add,Buffered.append_points]
    exact Disjoint.union_left (Disjoint.union_right (h.dis _ _ ne) (apart _ _))
      (Disjoint.union_right (apart _ _).symm (g.dis _ _ (fun e => ne (π.injective e))))
  · intro i; simp only [add,Buffered.append_points]
    exact Disjoint.union_left ((h.apart _).mono_right res) (g.apart _)
  · intro z; rw [h.cover,g.cover]; simp only [add,Buffered.append_points,Set.mem_union]
    constructor
    · rintro ((r|⟨i,hi⟩)|⟨i,hi⟩)
      · exact Or.inl r
      · exact Or.inr ⟨π.symm i,Or.inr (by simpa using hi)⟩
      · exact Or.inr ⟨i,Or.inl hi⟩
    · rintro (r|⟨i,old|new⟩)
      · exact Or.inl (Or.inl r)
      · exact Or.inr ⟨i,old⟩
      · exact Or.inl (Or.inr ⟨π i,new⟩)

def obs (s : State n) (i : Fin n) (b : Bundle) := total (s.record i) b
def dom (s : State n) (i j : Fin n) := obs s i s.residue ≤ obs s i (s.held i) - obs s i (s.held j)
def pairs (s : State n) : Finset (Fin n × Fin n) := by
  classical
  exact Finset.univ.filter (fun p => dom s p.1 p.2)
def group (s : State n) (H : Finset (Fin n)) :=
  H.Nonempty ∧ H ≠ Finset.univ ∧ ∀ i ∉ H, ∀ j ∈ H, dom s i j

theorem val_known (v : Fin n → Valuation) (rec : Records n) (s : Bundle) (sep : Separate s) (ok : Known v rec s) (i) :
    total (rec i) s = val (v i) s := (recorded_total _ _ _ (ok i)).trans (total_eq_measure _ _ sep)

theorem held_obs {v : Fin n → Valuation} {C} {s : State n} (h : Invariant v C s) (i j) :
    obs s i (s.held j) = val (v i) (s.held j) := val_known v _ _ (h.sep _) (h.known _) i
theorem res_obs {v : Fin n → Valuation} {C} {s : State n} (h : Invariant v C s) (i) :
    obs s i s.residue = val (v i) s.residue := val_known v _ _ h.res h.residual i
theorem dom_iff {v : Fin n → Valuation} {C} {s : State n} (h : Invariant v C s) (i j) :
    dom s i j ↔ val (v i) s.residue ≤ val (v i) (s.held i) - val (v i) (s.held j) := by
  simp only [dom,res_obs h,held_obs h]

theorem le_real (v : Valuation) (a b : Bundle) : v.measure a.points ≤ v.measure b.points ↔ val v a ≤ val v b := by
  letI := v.finite
  exact (ENNReal.toReal_le_toReal (measure_ne_top _ _) (measure_ne_top _ _)).symm

theorem append_val (v : Valuation) (a b : Bundle) (d : Disjoint a.points b.points) :
    val v (a++b) = val v a + val v b := by
  letI := v.finite
  unfold RepairProtocol.val; rw [Buffered.append_points,measureReal_union d (measurable_points _)]

theorem added_val {C} {x y : State n} (π : Equiv.Perm (Fin n)) (v : Valuation)
    (h : Partition C x.held x.residue) (g : Partition x.residue y.held y.residue) (j) :
    val v ((add x y π).held j) = val v (x.held j) + val v (y.held (π j)) :=
  append_val _ _ _ ((h.apart _).mono_right (fun z hz => (g.cover z).2 (Or.inr ⟨_,hz⟩)))

theorem added_known {v : Fin n → Valuation} {C} {x y : State n} (π : Equiv.Perm (Fin n))
    (h : Invariant v C x) (g : Invariant v x.residue y) (keep : Preserves v x.record y.record) (j) :
    Known v y.record ((add x y π).held j) := fun i e he => (List.mem_append.mp he).elim
      (fun a => keep i e (h.known _ i e a)) (g.known _ i e)

theorem provisional {v : Fin n → Valuation} {C} {x y : State n}
    (h : Invariant v C x) (g : Invariant v x.residue y) (keep : Preserves v x.record y.record) :
    Invariant v C (add x y (Equiv.refl _)) := by
  refine ⟨add_part _ _ _ _ h.toPartition g.toPartition,?_,added_known _ h g keep,g.residual⟩
  intro i j
  apply (le_real ..).2
  simp only [added_val _ _ h.toPartition g.toPartition,Equiv.refl_apply]
  exact add_le_add ((le_real ..).1 (h.ef _ _)) ((le_real ..).1 (g.ef _ _))

theorem preserve_dom {v : Fin n → Valuation} {C} {x z : State n} (h : Invariant v C x)
    (g : Invariant v C z) (σ : Equiv.Perm (Fin n))
    (intact : ∀ j, (x.held j).points ⊆ (z.held (σ j)).points)
    (inside : ∀ j, (z.held (σ j)).points ⊆ (x.held j).points ∪ x.residue.points)
    (res : z.residue.points ⊆ x.residue.points) {i j} (old : dom x i j) : dom z i (σ j) := by
  letI := (v i).finite
  rw [dom_iff h] at old; rw [dom_iff g]
  apply Progress.follows_label _ _ _ _ _ _ old
  · exact (measureReal_mono (intact i)).trans ((le_real ..).1 (g.ef i (σ i)))
  · have sub : (z.held (σ j)).points ⊆ (x.held j).points ∪ (x.residue.points \ z.residue.points) := by
      intro t ht
      rcases inside j ht with left | right
      · exact Or.inl left
      · exact Or.inr ⟨right,fun rz => Set.disjoint_left.mp (g.apart _) ht rz⟩
    exact (measureReal_mono sub).trans ((measureReal_union_le _ _).trans_eq
      (by rw [measureReal_diff res (measurable_points _)]; rfl))

def K (n : ℕ) : ℝ := 4*n^2
def t (n : ℕ) : ℝ := 1/K n
def gap (y : State n) (i j : Fin n) := (obs y i (y.held i)-obs y i (y.held j))/obs y i y.residue

structure Move (n : ℕ) where
  a : Fin n
  b : Fin n
  perm : Equiv.Perm (Fin n)
  alpha : ℝ

def legal (x y : State n) (m : Move n) :=
  ¬ dom (add x y (Equiv.refl _)) m.a m.b ∧ (t n)^(n+1) ≤ m.alpha ∧ m.alpha ≤ (t n)^2 ∧
  (∀ i, gap y i (m.perm i) ≤ m.alpha) ∧ m.alpha/t n ≤ gap y m.a (m.perm m.b)

def chooseMove [NeZero n] (x y : State n) : Move n := by
  classical
  exact if ex : ∃ m, legal x y m then Classical.choose ex else ⟨0,0,Equiv.refl _,0⟩

theorem core_inv [NeZero n] {v : Fin n → Valuation} {x y : State n} {r} (h : CoreProtocol.Spec v r x.residue x.record y) :
    Invariant v x.residue y := ⟨⟨h.held_separate,h.residue_separate,h.pairwise,h.leftover,h.cover⟩,h.ef,h.held_known,h.residue_known⟩

theorem core_move [NeZero n] (hn : 2 ≤ n) {v : Fin n → Valuation} {C} {x y : State n} {r}
    (h : Invariant v C x) (g : CoreProtocol.Spec v r x.residue x.record y)
    (absent : ¬ ∃ H, group (add x y (Equiv.refl _)) H) :
    let m := chooseMove x y
    (∀ i, 0 < obs y i y.residue) ∧ legal x y m ∧ ¬ dom x m.a m.b := by
  classical
  let z := add x y (Equiv.refl _)
  have inv := core_inv g
  have hz := provisional h inv g.keep
  have escape (H : Finset (Fin n)) (nonempty : H.Nonempty) (proper : H ≠ Finset.univ) :
      ∃ a ∉ H, ∃ b ∈ H, ¬dom z a b := by
    by_contra! no
    exact absent ⟨H,nonempty,proper,no⟩
  have pos (i) : 0 < obs y i y.residue := by
    let H := Finset.univ.erase i
    have ne : H.Nonempty := Finset.card_pos.mp (by simp [H,card_erase_of_mem (Finset.mem_univ i)]; omega)
    have proper : H ≠ Finset.univ := by
      intro eq
      have hit : i ∈ H := by rw [eq]; exact Finset.mem_univ i
      simp [H] at hit
    obtain ⟨a,ha,b,_,arc⟩ := escape H ne proper
    have eq : a=i := by simpa [H] using ha
    subst a
    by_contra! zero
    apply arc
    rw [dom_iff hz]
    have e := (le_real ..).1 (hz.ef i b)
    exact (res_obs inv i ▸ zero).trans (sub_nonneg.mpr e)
  have nr : (2:ℝ) ≤ n := by exact_mod_cast hn
  have tp : 0 < t n := by unfold t K; positivity
  have small : t n < 1 := by unfold t K; apply (div_lt_iff₀ (by positivity)).mpr; nlinarith [sq_nonneg ((n:ℝ)-2)]
  obtain ⟨b,_,adv⟩ := g.advantage
  have big : t n < gap y r b := by
    rw [gap,held_obs inv,held_obs inv,res_obs inv]
    have positive : 0 < val (v r) y.residue := res_obs inv r ▸ pos r
    have aux : t n < 1/((n:ℝ)-1) := by
      unfold t K; apply one_div_lt_one_div_of_lt (by linarith); nlinarith [sq_nonneg ((n:ℝ)-2)]
    apply (lt_div_iff₀ positive).mpr
    exact (mul_lt_mul_of_pos_right aux positive).trans_le (by simpa only [one_div,inv_mul_eq_div] using adv)
  obtain ⟨a,b',π,α,arc,lo,hi,loss,gain⟩ := Reassign.selection (fun i j => ¬dom z i j) escape (gap y)
    (fun i => by simp [gap]) (t n) tp small (by simpa using hn) r b big
  have ex : ∃ m, legal x y m := ⟨⟨a,b',π,α⟩,arc,by simpa using lo,hi,loss,gain⟩
  have m : legal x y (chooseMove x y) := by simp only [chooseMove,dif_pos ex]; exact Classical.choose_spec ex
  refine ⟨pos,m,fun old => m.1 ?_⟩
  apply preserve_dom h hz (Equiv.refl _) _ _ _ old
  · intro j; simp [add,Buffered.append_points,Set.subset_union_left]
  · intro j
    simp only [add,Equiv.refl_apply,Buffered.append_points]
    exact Set.union_subset_union_right _ (fun p hp => (g.cover p).2 (Or.inr ⟨_,hp⟩))
  · exact fun p hp => (g.cover p).2 (Or.inl hp)

end
end CakeCutting.Division
