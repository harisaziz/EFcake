import CakeCutting.DivisionRound

/-! Bounded iteration to a dominated group and physical integration of a
complete division of its residue. Queries on group members lift without overhead. -/
namespace CakeCutting.Division
open Finset Set MeasureTheory Components DecisionTree AdaptiveTrim BoundaryRecords RepairProtocol
noncomputable section
variable {n : ℕ}

structure Stop (n : ℕ) where
  state : State n
  members : Finset (Fin n)

def stopOK (v : Fin n → Valuation) (C : Bundle) (z : Stop n) :=
  Invariant v C z.state ∧ group z.state z.members

def loop [NeZero n] : ℕ → State n → Tree n (Stop n)
  | 0,x => .ret ⟨x,∅⟩
  | k+1,x => bind (round x) fun o => match o with
    | .split z H => .ret ⟨z,H⟩
    | .next z => loop k z

theorem loop_good [NeZero n] (hn : 2 ≤ n) (v : Fin n → Valuation) (C : Bundle)
    (k : ℕ) (x : State n) (hx : Invariant v C x) (fuel : n*n < (pairs x).card + k) :
    Good v (stopOK v C) (k * roundCost n) (loop k x) := by
  induction k generalizing x with
  | zero =>
    have bound := card_le_univ (pairs x)
    simp only [Fintype.card_prod,Fintype.card_fin] at bound
    omega
  | succ k ih =>
    rw [Nat.succ_mul,Nat.add_comm]
    apply bind_good v _ _ _ _ _ _ (round_good hn v C x hx)
    rintro (⟨z,H⟩|z) h
    · exact (good_ret ..).2 h
    · exact ih z h.1 (by have := h.2; omega)

def name (H : Finset (Fin n)) (i : Fin H.card) : Fin n := (H.equivFin.symm i).val

def rename {m : ℕ} {A : Type} (f : Fin m → Fin n) : Tree m A → Tree n A
  | .ret a => .ret a
  | .ask (.eval i a b) next => .ask (.eval (f i) a b) fun (w : ℝ) => rename f (next w)
  | .ask (.cut i a w) next => .ask (.cut (f i) a w) fun (b : Point) => rename f (next b)

theorem rename_good {m : ℕ} {A : Type} (v : Fin n → Valuation) (f : Fin m → Fin n)
    (t : Tree m A) (P : A → Prop) (k : ℕ) (h : Good (v ∘ f) P k t) : Good v P k (rename f t) := by
  induction t generalizing k with
  | ret a => exact (good_ret ..).2 ((good_ret ..).1 h)
  | ask q cont ih =>
    cases k with
    | zero => exact h.elim
    | succ k =>
      cases q with
      | eval i a b => exact ⟨h.1,fun w hw => ih w k (h.2 w hw)⟩
      | cut i a w => exact ⟨h.1,fun b hb => ih b k (h.2 b hb)⟩

structure Divided (v : Fin n → Valuation) (C : Bundle) (X : Allocation n) : Prop where
  sep : ∀ i, Separate (X i)
  dis : ∀ i j, i ≠ j → Disjoint (X i).points (X j).points
  cover : ∀ p, p ∈ C.points ↔ ∃ i, p ∈ (X i).points
  ef : EnvyFree v X

def addition (H : Finset (Fin n)) (F : Allocation H.card) (i : Fin n) : Bundle :=
  if mem : i ∈ H then F (H.equivFin ⟨i,mem⟩) else []
def finish (s : State n) (H : Finset (Fin n)) (F : Allocation H.card) : Allocation n :=
  fun i => s.held i ++ addition H F i

theorem group_finish (v : Fin n → Valuation) (C : Bundle) (s : State n) (H : Finset (Fin n))
    (F : Allocation H.card) (h : Invariant v C s) (g : group s H) (hf : Divided (v ∘ name H) s.residue F) :
    Divided v C (finish s H F) := by
  classical
  let B := addition H F
  have idn (i) (hi : i ∈ H) : name H (H.equivFin ⟨i,hi⟩) = i := by simp [name]
  have selected (i : Fin H.card) : B (name H i) = F i := by
    have mem : name H i ∈ H := (H.equivFin.symm i).property
    change addition H F (name H i) = F i
    rw [addition,dif_pos mem]
    simp [name]
  have sub (i) : (B i).points ⊆ s.residue.points := by
    by_cases hi : i ∈ H
    · simp only [B,addition,dif_pos hi]; exact fun p hp => (hf.cover p).2 ⟨_,hp⟩
    · simp [B,addition,hi,empty_points]
  have cross (i j) := (h.apart i).mono_right (sub j)
  have bs (i) : Separate (B i) := by
    by_cases hi : i∈H
    · simpa only [B,addition,dif_pos hi] using hf.sep (H.equivFin ⟨i,hi⟩)
    · simpa only [B,addition,dif_neg hi] using (List.Pairwise.nil : Separate [])
  have dis (i j) (ne : i≠j) : Disjoint (B i).points (B j).points := by
    by_cases hi : i∈H <;> by_cases hj : j∈H <;> simp [B,addition,hi,hj,empty_points]
    exact hf.dis _ _ (fun eq => ne (congrArg Subtype.val (H.equivFin.injective eq)))
  refine ⟨fun i => RepairPacking.append_separate _ _ (h.sep i) (bs i) (cross _ _),?_,?_,?_⟩
  · intro i j ne
    simp only [finish,Buffered.append_points]
    exact Disjoint.union_left (Disjoint.union_right (h.dis _ _ ne) (cross _ _))
      (Disjoint.union_right (cross _ _).symm (dis _ _ ne))
  · intro p; rw [h.cover]; simp only [finish,Buffered.append_points,Set.mem_union]
    constructor
    · rintro (rp|⟨i,hp⟩)
      · obtain ⟨j,hj⟩ := (hf.cover p).1 rp
        exact ⟨name H j,Or.inr (show p ∈ (B _).points by rw [selected]; exact hj)⟩
      · exact ⟨i,Or.inl hp⟩
    · rintro ⟨i,old|new⟩
      · exact Or.inr ⟨i,old⟩
      · exact Or.inl (sub i new)
  · intro i j
    letI := (v i).finite
    apply (le_real ..).2
    change val (v i) (s.held j ++ B j) ≤ val (v i) (s.held i ++ B i)
    rw [append_val _ _ _ (cross j j),append_val _ _ _ (cross i i)]
    have old := (le_real ..).1 (h.ef i j)
    by_cases hj : j∈H
    · by_cases hi : i∈H
      · apply add_le_add old
        have e := (le_real ..).1 (hf.ef (H.equivFin ⟨i,hi⟩) (H.equivFin ⟨j,hj⟩))
        simpa only [B,addition,dif_pos hi,dif_pos hj,Function.comp_apply,idn] using e
      · have dom := (dom_iff h i j).1 (g.2.2 i hi j hj)
        have bounded : val (v i) (B j) ≤ val (v i) s.residue := measureReal_mono (sub j)
        have nonneg : 0 ≤ val (v i) (B i) := measureReal_nonneg
        linarith
    · have zero : val (v i) (B j) = 0 := by simp [B,addition,hj,RepairProtocol.val,empty_points]
      have nonneg : 0 ≤ val (v i) (B i) := measureReal_nonneg
      linarith

end
end CakeCutting.Division
