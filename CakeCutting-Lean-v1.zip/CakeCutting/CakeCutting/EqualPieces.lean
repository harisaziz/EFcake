import CakeCutting.BoundaryRecords

/-! Core's physical equal division on any ordered active bundle with component
records. Each new piece costs one cut and at most two evaluations per observer. -/
namespace CakeCutting.EqualPieces
open Finset Set MeasureTheory Components BoundaryRecords AdaptiveTrim DecisionTree
noncomputable section
variable {n : ℕ}

structure Out (n m : ℕ) where
  piece : Fin m → Bundle
  record : Records n

def divide (r : Fin n) (τ : ℝ) (s : Bundle) (rec : Records n) : (k : ℕ) → Tree n (Out n (k+1))
  | 0 => .ret ⟨fun _ => s,rec⟩
  | k+1 => bind (cut r (rec r) τ s) fun p => bind (refresh rec (boundary p)) fun rec' =>
      bind (divide r τ (trimmings p) rec' k) fun z => .ret ⟨Fin.cons (suffix p) z.piece,z.record⟩

structure Spec (r : Fin n) (v : Fin n → Valuation) (τ : ℝ) (s : Bundle) (rec : Records n)
    {k : ℕ} (z : Out n k) : Prop where
  separate : ∀ j, Separate (z.piece j)
  known : ∀ j, Known v z.record (z.piece j)
  keep : Preserves v rec z.record
  equal : ∀ j, total (mass (v r)) (z.piece j) = τ
  cover : ∀ x, x ∈ s.points ↔ ∃ j, x ∈ (z.piece j).points
  disjoint : ∀ i j, i ≠ j → Disjoint (z.piece i).points (z.piece j).points

theorem divide_good (r : Fin n) (v : Fin n → Valuation) (τ : ℝ) (nonneg : 0 ≤ τ)
    (s : Bundle) (rec : Records n) (k : ℕ) (known : Known v rec s) (sep : Separate s)
    (balance : total (mass (v r)) s = (k+1 : ℕ)*τ) :
    Good v (Spec r v τ s rec) (k*(1+2*n)) (divide r τ s rec k) := by
  classical
  induction k generalizing s rec with
  | zero =>
    apply (good_ret ..).2
    refine ⟨fun _ => sep,fun _ => known,preserves_refl v rec,fun _ => by simpa using balance,?_,?_⟩
    · intro x; exact ⟨fun h => ⟨0,h⟩,fun ⟨_,h⟩ => h⟩
    · intro i j hn; exact False.elim (hn (Fin.ext (by have := i.isLt; have := j.isLt; omega)))
  | succ k ih =>
    have totalRec := recorded_total (v r) _ _ (known r)
    have cap : τ ≤ total (rec r) s := by
      rw [totalRec,balance]
      push_cast
      nlinarith [Nat.cast_nonneg (α := ℝ) k,mul_nonneg (Nat.cast_nonneg (α := ℝ) k) nonneg]
    have adjust : (k+1)*(1+2*n) = 1+(2*n+k*(1+2*n)) := by ring
    rw [adjust]
    apply bind_good v _ _ _ _ 1 _ (cut_good v r _ _ nonneg s cap (known r))
    intro p hp
    apply bind_good v _ _ _ _ (2*n) _ (boundary_good v rec p known)
    rintro new ⟨keep,suf,trim⟩
    have sufs := suffix_separate p sep
    have ts := trimmings_separate p sep
    have eq : total (mass (v r)) (suffix p) = τ := by
      rw [total_eq_measure _ _ sufs,← suffix_value _ p sep,hp]
    have left : total (mass (v r)) (trimmings p) = ((k+1:ℕ):ℝ)*τ := by
      have account := split_mass (v r) p sep
      rw [hp,balance] at account
      push_cast at account ⊢
      linarith
    apply bind_good v _ _ _ _ _ 0 (ih _ _ trim ts left)
    intro z old
    apply (good_ret ..).2
    obtain ⟨cov,dis⟩ := partition p sep
    have inside (j) : (z.piece j).points ⊆ (trimmings p).points := fun x hx => (old.cover x).2 ⟨j,hx⟩
    refine ⟨Fin.cases sufs old.separate,Fin.cases (fun i e he => old.keep i e (suf i e he)) old.known,
      preserves_trans keep old.keep,Fin.cases eq old.equal,?_,?_⟩
    · intro x
      rw [← cov,Set.mem_union,old.cover x]
      constructor
      · rintro (⟨j,h⟩ | h)
        · exact ⟨j.succ,h⟩
        · exact ⟨0,h⟩
      · rintro ⟨j,h⟩
        exact Fin.cases (fun hit => Or.inr hit) (fun i hit => Or.inl ⟨i,hit⟩) j h
    · intro i
      refine Fin.cases ?_ ?_ i
      · intro j; refine Fin.cases (fun hn => False.elim (hn rfl)) ?_ j
        intro j _
        exact (dis.mono_left (inside j)).symm
      · intro i j
        refine Fin.cases (fun _ => dis.mono_left (inside i)) ?_ j
        intro j ne; exact old.disjoint i j (fun eq => ne (congrArg Fin.succ eq))

end
end CakeCutting.EqualPieces
