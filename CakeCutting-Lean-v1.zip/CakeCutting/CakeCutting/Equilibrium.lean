import CakeCutting.Median

/-! The greatest-equilibrium and uniqueness consequences of full exposability,
from the proposition labelled `pr:pinned`. -/

namespace CakeCutting.Equilibrium

open Finset CakeCutting.Matching

variable {R C V W : Type*} [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C]
  [LinearOrder V] [LinearOrder W]

/-- The pin participates in comparisons and is excluded from the assignment. -/
def Capped (pin : C) (f : R → C → V → W) (x : C → V) : Prop :=
  ∃ m : R → C, Function.Injective m ∧
    (∀ j, j ≠ pin → ∃ i, m i = j) ∧ ∀ i, m i ∈ (tight (table f x) i).erase pin

omit [DecidableEq R] in
/-- Every capped equilibrium is dominated coordinatewise by every fully
exposable vector with the same pin level. -/
theorem greatest [Nonempty C] (pin : C) (f : R → C → V → W)
    (hf : ∀ i j, StrictMono (f i j)) (x y : C → V) (hp : y pin = x pin)
    (hx : FullyExposable (tight (table f x))) (hy : Capped pin f y) :
    ∀ j, y j ≤ x j := by
  classical
  intro j
  by_contra! hj
  obtain ⟨m, hm, onto, hedge⟩ := hy
  let T := univ.filter (fun k => x k < y k)
  let I := (univ : Finset R).filter (fun i => m i ∈ T)
  have hpT : pin ∉ T := by simp [T, hp]
  have himage : I.image m = T := by
    ext k
    constructor
    · intro hk
      obtain ⟨i, hi, rfl⟩ := mem_image.mp hk
      exact (mem_filter.mp hi).2
    · intro hk
      obtain ⟨i, hi⟩ := onto k (fun h => hpT (h ▸ hk))
      exact mem_image.mpr ⟨i, mem_filter.mpr ⟨mem_univ _, hi ▸ hk⟩, hi⟩
  have hT : j ∈ T := mem_filter.mpr ⟨mem_univ _, hj⟩
  have hI : I.Nonempty := by
    rw [← himage] at hT
    obtain ⟨i, hi, _⟩ := mem_image.mp hT
    exact ⟨i, hi⟩
  have hsub : neighbors (tight (table f x)) I ⊆ T := by
    intro k hk
    obtain ⟨i, hi, hki⟩ := mem_biUnion.mp hk
    by_contra hkn
    have hky : y k ≤ x k := le_of_not_gt (fun h => hkn (mem_filter.mpr ⟨mem_univ _, h⟩))
    have hmi : x (m i) < y (m i) := (mem_filter.mp (mem_filter.mp hi).2).2
    have ha := (mem_tight ..).1 (mem_erase.mp (hedge i)).2 k
    have hb := (mem_tight ..).1 hki (m i)
    have hcycle : f i (m i) (y (m i)) ≤ f i (m i) (x (m i)) :=
      (ha.trans ((hf i k).monotone hky)).trans hb
    exact (not_le_of_gt (hf i (m i) hmi)) hcycle
  have count := (fullyExposable_iff_strictHall _ (tight_nonempty _)).1 hx I hI
  have bounded := card_le_card hsub
  have same : I.card = T.card := by rw [← himage, card_image_of_injective _ hm]
  omega

omit [DecidableEq R] [LinearOrder V] in
/-- The matching leaving the pin free uses every ordinary column. -/
theorem exposable_capped (pin : C) (hd : Fintype.card C = Fintype.card R + 1)
    (f : R → C → V → W) (x : C → V) (hx : FullyExposable (tight (table f x))) :
    Capped pin f x := by
  obtain ⟨m, hm, hmem⟩ := hx pin
  refine ⟨m, hm, ?_, hmem⟩
  intro j hj
  have hc := Median.covers_except hd hm (fun i => (mem_erase.mp (hmem i)).1)
  have h : j ∈ (univ : Finset R).image m := hc.symm ▸ mem_erase.mpr ⟨hj, mem_univ _⟩
  obtain ⟨i, _, hi⟩ := mem_image.mp h
  exact ⟨i, hi⟩

omit [DecidableEq R] in
/-- Uniqueness at the specified pin level. Existence is a separate claim. -/
theorem unique [Nonempty C] (pin : C) (hd : Fintype.card C = Fintype.card R + 1)
    (f : R → C → V → W) (hf : ∀ i j, StrictMono (f i j)) (x y : C → V)
    (hp : y pin = x pin) (hx : FullyExposable (tight (table f x)))
    (hy : FullyExposable (tight (table f y))) : x = y := by
  funext j
  exact le_antisymm (greatest pin f hf y x hp.symm hy (exposable_capped pin hd f x hx) j)
    (greatest pin f hf x y hp hx (exposable_capped pin hd f y hy) j)

end CakeCutting.Equilibrium
