import CakeCutting.Solver
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.Instances.NNReal.Lemmas
import Mathlib.Topology.Order.OrderClosed

/-! Existence of a fully exposable vector in a capped square. Rows and
ordinary columns have the same finite index type, with a separate pin. -/
namespace CakeCutting.Exposure
open Finset CakeCutting.Matching
open scoped NNReal

variable {R : Type*} [Fintype R] [DecidableEq R]

omit [Fintype R] in
/-- A nonempty finite set closed under a successor contains a nonempty
subset on which that successor permutes. -/
private theorem stable_image (s : Finset R) (hs : s.Nonempty) (b : R → R)
    (hb : ∀ i ∈ s, b i ∈ s) :
    ∃ t : Finset R, t.Nonempty ∧ t ⊆ s ∧ t.image b = t := by
  classical
  let sets := s.powerset.filter (fun t => t.Nonempty ∧ t.image b ⊆ t)
  have hs' : s ∈ sets := mem_filter.mpr ⟨mem_powerset.mpr Subset.rfl, hs, by
    intro j hj; obtain ⟨i, hi, rfl⟩ := mem_image.mp hj; exact hb i hi⟩
  obtain ⟨t,ht,hmin⟩ := sets.exists_min_image Finset.card ⟨s,hs'⟩
  obtain ⟨hts, htn,hsub⟩ := mem_filter.mp ht
  refine ⟨t,htn,mem_powerset.mp hts,eq_of_subset_of_card_le hsub (hmin _ ?_)⟩
  exact mem_filter.mpr ⟨mem_powerset.mpr (hsub.trans (mem_powerset.mp hts)),
    htn.image b, image_subset_image hsub⟩

/-- A permutation which improves the assigned cost on some nonempty
subset and changes nothing outside it. -/
private theorem improve (s : Finset R) (hs : s.Nonempty) (cost : R → R → ℝ≥0)
    (h : ∀ i ∈ s, ∃ j ∈ s, cost i j < cost i i) :
    ∃ e : Equiv.Perm R, (∀ i, cost i (e i) ≤ cost i i) ∧
      (∑ i, cost i (e i)) < ∑ i, cost i i := by
  classical
  let b := fun i => if hi : i ∈ s then (h i hi).choose else i
  have hb (i) (hi : i ∈ s) : b i ∈ s ∧ cost i (b i) < cost i i := by
    simpa [b,hi] using (h i hi).choose_spec
  obtain ⟨t,hn,hsub,he⟩ := stable_image s hs b (fun i hi => (hb i hi).1)
  have forward : t.image b ⊆ t := le_of_eq he
  have back : t ⊆ t.image b := le_of_eq he.symm
  let m : t → t := fun i => ⟨b i, forward (mem_image_of_mem b i.property)⟩
  have surj : Function.Surjective m := by
    intro j
    have hj := back j.property
    obtain ⟨i,hi,hij⟩ := mem_image.mp hj
    exact ⟨⟨i,hi⟩,Subtype.ext hij⟩
  let e : Equiv.Perm t := Equiv.ofBijective m ((Fintype.bijective_iff_surjective_and_card _).2 ⟨surj,rfl⟩)
  let perm := e.extendDomain (Equiv.refl t)
  have inside (i) (hi : i ∈ t) : perm i = b i :=
    e.extendDomain_apply_image (Equiv.refl t) (⟨i,hi⟩ : t)
  have weak (i) : cost i (perm i) ≤ cost i i := by
    by_cases hi : i ∈ t
    · rw [inside i hi]; exact (hb i (hsub hi)).2.le
    · rw [show perm i = i from e.extendDomain_apply_not_subtype (Equiv.refl t) hi]
  obtain ⟨i,hi⟩ := hn
  exact ⟨perm, weak, sum_lt_sum (fun j _ => weak j)
    ⟨i,mem_univ _, by rw [inside i hi]; exact (hb i (hsub hi)).2⟩⟩

variable (f : R → R → ℝ≥0 ≃o ℝ≥0) (cap : R → ℝ≥0)

/-- With tolerance e, a row can pay at most its cap and at most e above any
ordinary alternative. The matching is a bijection on the ordinary indices. -/
def Feasible (e : ℝ≥0) (m : Equiv.Perm R) (u : R → ℝ≥0) : Prop :=
  ∀ i, f i (m i) (u (m i)) ≤ cap i ∧
    ∀ j, f i (m i) (u (m i)) ≤ f i j (u j) + e

def total (m : Equiv.Perm R) (u : R → ℝ≥0) := ∑ i, f i (m i) (u (m i))

def box : Set (R → ℝ≥0) := Set.Icc 0 (fun j => ∑ i, (f i j).symm (cap i))

omit [DecidableEq R] in
private theorem in_box {e m u} (h : Feasible f cap e m u) : u ∈ box f cap := by
  refine ⟨fun _ => zero_le _, fun j => ?_⟩
  let i := m.symm j
  have hc := (h i).1
  rw [show m i = j from m.apply_symm_apply j] at hc
  exact ((f i j).le_symm_apply.mpr hc).trans (single_le_sum (fun a _ => zero_le ((f a j).symm (cap a))) (mem_univ i))

omit [Fintype R] [DecidableEq R] in
private theorem feasible_closed (e : ℝ≥0) (m : Equiv.Perm R) :
    IsClosed {u | Feasible f cap e m u} := by
  have cont (i j : R) : Continuous (fun u : R → ℝ≥0 => f i j (u j)) :=
    (f i j).continuous.comp (continuous_apply j)
  have eqn : {u | Feasible f cap e m u} = (⋂ i, ({u | f i (m i) (u (m i)) ≤ cap i} ∩
    ⋂ j, {u | f i (m i) (u (m i)) ≤ f i j (u j) + e})) := by ext u; simp [Feasible, Set.mem_iInter]
  rw [eqn]
  exact isClosed_iInter fun i => (isClosed_le (cont i _) continuous_const).inter
    (isClosed_iInter fun j => isClosed_le (cont i _) ((cont i j).add continuous_const))

/-- Select optimal levels, then a minimum-cost assignment at those levels. -/
private theorem optimum (e : ℝ≥0) :
    ∃ u m, Feasible f cap e m u ∧
      (∀ v m', Feasible f cap e m' v → (∑ j, v j) ≤ ∑ j, u j) ∧
      ∀ m', Feasible f cap e m' u → total f m u ≤ total f m' u := by
  classical
  let S := ⋃ m : Equiv.Perm R, {u | Feasible f cap e m u}
  have closed : IsClosed S := isClosed_iUnion_of_finite (feasible_closed f cap e)
  have compact : IsCompact S := isCompact_Icc.of_isClosed_subset closed (by
    intro u hu; obtain ⟨m,hm⟩ := Set.mem_iUnion.mp hu; exact in_box f cap hm)
  have hz : (0 : R → ℝ≥0) ∈ S := by
    apply Set.mem_iUnion.mpr
    refine ⟨Equiv.refl _, fun i => ?_⟩
    have zero (j : R) : f i j 0 = 0 := (f i j).map_bot
    simp [zero]
  obtain ⟨u,hu,hmax⟩ := compact.exists_isMaxOn ⟨_,hz⟩
    (f := fun v => ∑ j, v j) (continuous_finset_sum _ (fun j _ => continuous_apply j)).continuousOn
  obtain ⟨m0,hm0⟩ := Set.mem_iUnion.mp hu
  let pool := univ.filter (fun m => Feasible f cap e m u)
  obtain ⟨m,hm,hmin⟩ := pool.exists_min_image (fun m => total f m u)
    ⟨m0,mem_filter.mpr ⟨mem_univ _,hm0⟩⟩
  exact ⟨u,m,(mem_filter.mp hm).2,fun v m' h => hmax (Set.mem_iUnion.mpr ⟨m',h⟩),
    fun m' h => hmin m' (mem_filter.mpr ⟨mem_univ _,h⟩)⟩

def price (u : R → ℝ≥0) (i : R) : Option R → ℝ≥0
  | none => cap i
  | some j => f i j (u j)

noncomputable def edges (e : ℝ≥0) (u : R → ℝ≥0) (i : R) : Finset (Option R) :=
  univ.filter (fun j => ∀ k, price f cap u i j ≤ price f cap u i k + e)

private theorem approx (e : ℝ≥0) (he : 0 < e) :
    ∃ u ∈ box f cap, StrictHall (edges f cap e u) := by
  classical
  obtain ⟨u,m,feas,hmax,hmin⟩ := optimum f cap e
  have own (i) : some (m i) ∈ edges f cap e u i := by
    apply mem_filter.mpr
    refine ⟨mem_univ _,fun k => ?_⟩
    cases k with
    | none => exact (feas i).1.trans (le_self_add)
    | some j => exact (feas i).2 j
  refine ⟨u,in_box f cap feas,fun S hS => ?_⟩
  have inj : Function.Injective (fun i => some (m i)) := fun i j h => m.injective (Option.some.inj h)
  let J := S.image (fun i => some (m i))
  have sub : J ⊆ neighbors (edges f cap e u) S := by
    intro k hk; obtain ⟨i,hi,rfl⟩ := mem_image.mp hk
    exact mem_biUnion.mpr ⟨i,hi,own i⟩
  by_contra! fail
  have eqn : J = neighbors (edges f cap e u) S :=
    eq_of_subset_of_card_le sub (by simpa [J,card_image_of_injective _ inj] using fail)
  have inJ (i) (hi : i ∈ S) {k} (hk : k ∈ edges f cap e u i) : k ∈ J := by
    rw [eqn]; exact mem_biUnion.mpr ⟨i,hi,hk⟩
  have sink : ∃ i ∈ S, ∀ j, f i (m i) (u (m i)) ≤ f i j (u j) := by
    by_contra! nn
    have cheaper (i) (hi : i ∈ S) :
        ∃ j ∈ S, f i (m j) (u (m j)) < f i (m i) (u (m i)) := by
      obtain ⟨j,hj⟩ := nn i hi
      have edge : some j ∈ edges f cap e u i :=
        mem_filter.mpr ⟨mem_univ _,fun k => hj.le.trans ((mem_filter.mp (own i)).2 k)⟩
      obtain ⟨b,hb,hbj⟩ := mem_image.mp (inJ i hi edge)
      exact ⟨b,hb,by rwa [Option.some.inj hbj]⟩
    obtain ⟨rot,hweak,hstrict⟩ := improve S hS (fun i j => f i (m j) (u (m j))) cheaper
    have hrot : Feasible f cap e (rot.trans m) u := fun i =>
      ⟨(hweak i).trans (feas i).1,fun j => (hweak i).trans ((feas i).2 j)⟩
    exact hstrict.not_ge (hmin _ hrot)
  obtain ⟨i,hi,cheap⟩ := sink
  let c := m i
  let d := f i c (u c)
  have slack : d < cap i := by
    apply lt_of_le_of_ne (feas i).1
    intro heq
    have edge : none ∈ edges f cap e u i := by
      apply mem_filter.mpr
      refine ⟨mem_univ _,fun k => ?_⟩
      change cap i ≤ _
      rw [← heq]
      exact (mem_filter.mp (own i)).2 k
    simpa [J] using inJ i hi edge
  let next := min (cap i) (d + e)
  have higher : d < next := lt_min slack (lt_add_of_pos_right _ he)
  let v := Function.update u c ((f i c).symm next)
  have atc : v c = (f i c).symm next := Function.update_self ..
  have better : u c < v c := by rw [atc]; exact (f i c).lt_symm_apply.mpr higher
  have larger (j) : u j ≤ v j := by
    by_cases h : j = c
    · simpa [h] using better.le
    · simp [v,Function.update_of_ne h]
  have hnew : Feasible f cap e m v := by
    intro b
    by_cases hbi : b = i
    · subst b
      change f i c (v c) ≤ _ ∧ _
      rw [atc,OrderIso.apply_symm_apply]
      refine ⟨min_le_left _ _,fun j => ?_⟩
      exact (min_le_right _ _).trans (add_le_add_right
        ((cheap j).trans ((f i j).monotone (larger j))) _)
    · have hbc : m b ≠ c := fun hh => hbi (m.injective hh)
      have hv : v (m b) = u (m b) := Function.update_of_ne hbc ..
      rw [hv]
      exact ⟨(feas b).1,fun j => ((feas b).2 j).trans
        (add_le_add_right ((f b j).monotone (larger j)) _)⟩
  exact (sum_lt_sum (fun j _ => larger j) ⟨c,mem_univ _,better⟩).not_ge (hmax v m hnew)

/-- The joint locus of tolerances and levels at which every column can
be exposed is closed: each fixed matching is finitely many closed
inequalities, and there are finitely many matching choices. -/
private theorem closed_locus :
    IsClosed {z : ℝ≥0 × (R → ℝ≥0) | FullyExposable (edges f cap z.1 z.2)} := by
  classical
  let S := fun (c : Option R) (m : R → Option R) =>
    {z : ℝ≥0 × (R → ℝ≥0) | ∀ i k, price f cap z.2 i (m i) ≤ price f cap z.2 i k + z.1}
  let choices := fun c => {m : R → Option R // Function.Injective m ∧ ∀ i, m i ≠ c}
  have eqn : {z : ℝ≥0 × (R → ℝ≥0) | FullyExposable (edges f cap z.1 z.2)} =
      ⋂ c, ⋃ m : choices c, S c m.val := by
    ext z
    simp only [Set.mem_setOf_eq,Set.mem_iInter,Set.mem_iUnion,S]
    constructor
    · intro h c
      obtain ⟨m,hm,ht⟩ := h c
      exact ⟨⟨m,hm,fun i => (mem_erase.mp (ht i)).1⟩,
        fun i => (mem_filter.mp (mem_erase.mp (ht i)).2).2⟩
    · intro h c
      obtain ⟨m,hm⟩ := h c
      exact ⟨m.val,m.property.1,fun i => mem_erase.mpr ⟨m.property.2 i,
        mem_filter.mpr ⟨mem_univ _,hm i⟩⟩⟩
  rw [eqn]
  apply isClosed_iInter
  intro c
  apply isClosed_iUnion_of_finite
  intro m
  have cont (i : R) (k : Option R) :
      Continuous (fun z : ℝ≥0 × (R → ℝ≥0) => price f cap z.2 i k) := by
    cases k with
    | none => exact continuous_const
    | some j => exact (f _ _).continuous.comp ((continuous_apply j).comp continuous_snd)
  have ee : S c m.val = ⋂ i, ⋂ k, {z : ℝ≥0 × (R → ℝ≥0) |
      price f cap z.2 i (m.val i) ≤ price f cap z.2 i k + z.1} := by
    ext; simp [S]
  rw [ee]
  exact isClosed_iInter fun i => isClosed_iInter fun k =>
    isClosed_le (cont _ _) ((cont _ _).add continuous_fst)

/-- Existence in the capped square, including ordinary levels on the boundary.
Ordinary columns are identified with rows, and none is the pin at its fixed
row-specific cap. -/
theorem exists_fullyExposable :
    ∃ u : R → ℝ≥0, FullyExposable (tight (price f cap u)) := by
  classical
  let region : Set (ℝ≥0 × (R → ℝ≥0)) := Set.Icc 0 1 ×ˢ box f cap
  let locus := {z : ℝ≥0 × (R → ℝ≥0) | FullyExposable (edges f cap z.1 z.2)}
  let P := Prod.fst '' (region ∩ locus)
  have compactRegion : IsCompact region := isCompact_Icc.prod isCompact_Icc
  have closedP : IsClosed P := ((compactRegion.inter_right (closed_locus f cap)).image continuous_fst).isClosed
  have pos (e : ℝ≥0) (h : 0 < e) (h1 : e ≤ 1) : e ∈ P := by
    obtain ⟨u,hu,hh⟩ := approx f cap e h
    have ne (i : R) : (edges f cap e u i).Nonempty := by
      obtain ⟨k,hk,hmin⟩ := (univ : Finset (Option R)).exists_min_image (price f cap u i) univ_nonempty
      exact ⟨k,mem_filter.mpr ⟨mem_univ _,fun j => (hmin j (mem_univ _)).trans le_self_add⟩⟩
    exact ⟨(e,u), ⟨⟨⟨zero_le _,h1⟩,hu⟩,(fullyExposable_iff_strictHall _ ne).2 hh⟩,rfl⟩
  have zeroP : (0 : ℝ≥0) ∈ P := by
    have subset : Set.Ioc (0 : ℝ≥0) 1 ⊆ P := fun e he => pos e he.1 he.2
    have h := closure_minimal subset closedP
    rw [closure_Ioc (by norm_num : (0 : ℝ≥0) ≠ 1)] at h
    exact h ⟨le_rfl,zero_le _⟩
  obtain ⟨⟨e,u⟩,⟨_,hl⟩,he⟩ := zeroP
  change e = 0 at he
  subst e
  have h : edges f cap 0 u = tight (price f cap u) := by
    funext i
    ext j
    simp [edges, tight]
  exact ⟨u,h ▸ hl⟩

end CakeCutting.Exposure
