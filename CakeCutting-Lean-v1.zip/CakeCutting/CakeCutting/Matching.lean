import Mathlib.Combinatorics.Hall.Finite
import Mathlib.Data.Finset.Max
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Real.Basic
import Mathlib.Tactic.ByContra

/-! A table-only matching test for v3, `le:which`. A minimum-size Hall
obstruction gives the same output guarantee as the alternating-path searches.
Finite enumeration simplifies the proof and preserves oracle query counts. -/

namespace CakeCutting.Matching

open Finset

variable {R C : Type*} [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C]

def neighbors (G : R → Finset C) (S : Finset R) : Finset C := S.biUnion G

def StrictHall (G : R → Finset C) : Prop :=
  ∀ S : Finset R, S.Nonempty → S.card < (neighbors G S).card

def Bad (G : R → Finset C) (S : Finset R) : Prop :=
  S.Nonempty ∧ (neighbors G S).card ≤ S.card

def MinimalBad (G : R → Finset C) (S : Finset R) : Prop :=
  Bad G S ∧ ∀ U, Bad G U → S.card ≤ U.card

/-- Matching all rows, with any one specified column unused. -/
def FullyExposable (G : R → Finset C) : Prop :=
  ∀ c : C, ∃ m : R → C, Function.Injective m ∧ ∀ i, m i ∈ (G i).erase c

omit [Fintype C] [DecidableEq R] in
theorem fullyExposable_iff_strictHall (G : R → Finset C) (hne : ∀ i, (G i).Nonempty) :
    FullyExposable G ↔ StrictHall G := by
  classical
  constructor
  · intro h S hS
    obtain ⟨i, hi⟩ := hS
    obtain ⟨c, hc⟩ := hne i
    obtain ⟨m, hm, hmem⟩ := h c
    have hcN : c ∈ neighbors G S := mem_biUnion.mpr ⟨i, hi, hc⟩
    have hs : S.image m ⊆ (neighbors G S).erase c := by
      intro k hk
      obtain ⟨a, ha, rfl⟩ := mem_image.mp hk
      obtain ⟨hneq, hin⟩ := mem_erase.mp (hmem a)
      exact mem_erase.mpr ⟨hneq, mem_biUnion.mpr ⟨a, ha, hin⟩⟩
    have hcard := card_le_card hs
    rw [card_image_of_injective _ hm] at hcard
    have := card_erase_add_one hcN
    omega
  · intro h c
    apply (Finset.all_card_le_biUnion_card_iff_existsInjective'
      (fun i => (G i).erase c)).mp
    intro S
    by_cases hs : S.Nonempty
    · have hsub : (neighbors G S).erase c ⊆ S.biUnion (fun i => (G i).erase c) := by
        intro k hk
        obtain ⟨hne', hmem⟩ := mem_erase.mp hk
        obtain ⟨i, hi, hki⟩ := mem_biUnion.mp hmem
        exact mem_biUnion.mpr ⟨i, hi, mem_erase.mpr ⟨hne', hki⟩⟩
      have hlt := h S hs
      have hcard := card_le_card hsub
      by_cases hc : c ∈ neighbors G S
      · have := card_erase_add_one hc
        omega
      · rw [erase_eq_of_notMem hc] at hcard
        omega
    · simp [not_nonempty_iff_eq_empty.mp hs]

omit [Fintype C] [DecidableEq R] in
private theorem exists_minimalBad (G : R → Finset C) (h : ¬ StrictHall G) :
    ∃ S, MinimalBad G S := by
  classical
  have hex : ∃ S, Bad G S := by
    by_contra! hh
    apply h
    intro S hS
    exact lt_of_not_ge (fun hle => hh S ⟨hS, hle⟩)
  let pool := (Finset.univ : Finset (Finset R)).filter (Bad G)
  have hp : pool.Nonempty := by
    obtain ⟨S, hS⟩ := hex
    exact ⟨S, by simpa [pool] using hS⟩
  obtain ⟨S, hs, hm⟩ := pool.exists_min_image Finset.card hp
  exact ⟨S, (by simpa [pool] using hs), fun U hU => hm U (by simpa [pool] using hU)⟩

/-- If a row is tight with an exact column in the trial graph G, all its
true tight columns H are exact and are also trial-tight. -/
def Transfers (G H : R → Finset C) (E : Finset C) : Prop :=
  ∀ i, (∃ j ∈ G i, j ∈ E) → ∀ k ∈ H i, k ∈ G i ∧ k ∈ E

omit [Fintype R] [Fintype C] in
/-- Every neighbor of a minimum-size obstruction is strictly short. -/
theorem obstruction_disjoint {G H : R → Finset C} {E : Finset C} {S : Finset R}
    (hs : MinimalBad G S) (hh : StrictHall H) (ht : Transfers G H E) :
    ∀ k ∈ neighbors G S, k ∉ E := by
  classical
  intro k hk hke
  let J := neighbors G S
  let T := J ∩ E
  let I := S.filter (fun i => ∃ j ∈ G i, j ∈ E)
  let U := S \ I
  have hI : I.Nonempty := by
    obtain ⟨i, hi, hki⟩ := mem_biUnion.mp hk
    exact ⟨i, mem_filter.mpr ⟨hi, k, hki, hke⟩⟩
  have hIT : neighbors H I ⊆ T := by
    intro a ha
    obtain ⟨i, hi, hai⟩ := mem_biUnion.mp ha
    obtain ⟨his, hit⟩ := mem_filter.mp hi
    obtain ⟨hga, hea⟩ := ht i hit a hai
    exact mem_inter.mpr ⟨mem_biUnion.mpr ⟨i, his, hga⟩, hea⟩
  have hU : neighbors G U ⊆ J \ T := by
    intro a ha
    obtain ⟨i, hi, hai⟩ := mem_biUnion.mp ha
    obtain ⟨his, hni⟩ := mem_sdiff.mp hi
    exact mem_sdiff.mpr ⟨mem_biUnion.mpr ⟨i, his, hai⟩,
      fun hat => hni (mem_filter.mpr ⟨his, a, hai, (mem_inter.mp hat).2⟩)⟩
  have h1 := hh I hI
  have h2 := card_le_card hIT
  have h3 := card_le_card hU
  have h4 : U.card + I.card = S.card := card_sdiff_add_card_eq_card (filter_subset ..)
  have h5 : (J \ T).card + T.card = J.card := card_sdiff_add_card_eq_card inter_subset_left
  have h6 : J.card ≤ S.card := hs.1.2
  have h7 : 0 < I.card := card_pos.mpr hI
  have hu : Bad G U := ⟨card_pos.mp (by omega), by omega⟩
  have := hs.2 U hu
  omega

/-- At a passing table all coordinates must be exact. -/
theorem exact_of_pass {G H : R → Finset C} {E : Finset C} (he : E.Nonempty)
    (hd : Fintype.card C = Fintype.card R + 1) (hg : StrictHall G)
    (hh : StrictHall H) (ht : Transfers G H E) : E = univ := by
  classical
  by_contra hproper
  let I := (univ : Finset R).filter (fun i => ∃ j ∈ G i, j ∈ E)
  let U := (univ : Finset R) \ I
  have hsub : neighbors H I ⊆ E := by
    intro k hk
    obtain ⟨i, hi, hki⟩ := mem_biUnion.mp hk
    exact (ht i (mem_filter.mp hi).2 k hki).2
  have hi : I.card < E.card := by
    by_cases h : I.Nonempty
    · exact lt_of_lt_of_le (hh I h) (card_le_card hsub)
    · simpa [not_nonempty_iff_eq_empty.mp h] using card_pos.mpr he
  have he' : E.card < Fintype.card C :=
    lt_of_le_of_ne (card_le_univ E) (fun h => hproper (eq_univ_of_card E h))
  have hu : U.card + I.card = Fintype.card R := by
    simpa [U] using card_sdiff_add_card_eq_card (subset_univ I)
  have hcomp : ((univ : Finset C) \ E).card + E.card = Fintype.card C := by
    simpa using card_sdiff_add_card_eq_card (subset_univ E)
  have husub : neighbors G U ⊆ univ \ E := by
    intro k hk
    obtain ⟨i, hmem, hki⟩ := mem_biUnion.mp hk
    exact mem_sdiff.mpr ⟨mem_univ _, fun hke =>
      (mem_sdiff.mp hmem).2 (mem_filter.mpr ⟨mem_univ _, k, hki, hke⟩)⟩
  have hx := hg U (card_pos.mp (by omega))
  have hy := card_le_card husub
  omega

/-- A finite, fixed tie order, independent of any true levels or valuations. -/
private noncomputable def first {α : Type*} [Fintype α] (p : α → Prop) (hp : ∃ a, p a) :
    {a // p a} := by
  classical
  let e := Fintype.equivFin α
  let good := univ.filter (fun k => p (e.symm k))
  have h : good.Nonempty := by
    obtain ⟨a, ha⟩ := hp
    exact ⟨e a, by simpa [good] using ha⟩
  exact ⟨e.symm (good.min' h), (mem_filter.mp (good.min'_mem h)).2⟩

inductive Result (R C : Type*) where
  | matching (assign : R → C)
  | short (column : C)

/-- Test using the observed graph alone. For a nonempty row type each branch
uses only finite searches and comparisons on the public table. -/
noncomputable def test (G : R → Finset C) (pin : C) (hne : ∀ i, (G i).Nonempty) :
    Result R C := by
  classical
  if pass : StrictHall G then
    let h := (fullyExposable_iff_strictHall G hne).2 pass pin
    exact .matching (first _ h).val
  else
    let S := first (MinimalBad G) (exists_minimalBad G pass)
    have hJ : (neighbors G S.val).Nonempty := by
      obtain ⟨i, hi⟩ := S.property.1.1
      obtain ⟨k, hk⟩ := hne i
      exact ⟨k, mem_biUnion.mpr ⟨i, hi, hk⟩⟩
    exact .short (first (· ∈ neighbors G S.val) hJ).val

theorem test_correct {G H : R → Finset C} {E : Finset C} (pin : C) (hp : pin ∈ E)
    (hd : Fintype.card C = Fintype.card R + 1) (hne : ∀ i, (G i).Nonempty)
    (hh : StrictHall H) (ht : Transfers G H E) :
    match test G pin hne with
    | .matching m => E = univ ∧ Function.Injective m ∧ ∀ i, m i ∈ (G i).erase pin
    | .short k => k ∉ E := by
  classical
  by_cases h : StrictHall G
  · simp only [test, dif_pos h]
    exact ⟨exact_of_pass ⟨pin, hp⟩ hd h hh ht,
      (first (fun m : R → C => Function.Injective m ∧ ∀ i, m i ∈ (G i).erase pin)
        ((fullyExposable_iff_strictHall G hne).2 h pin)).property⟩
  · simp only [test, dif_neg h]
    let S := first (MinimalBad G) (exists_minimalBad G h)
    apply obstruction_disjoint S.property hh ht
    exact (first (fun k => k ∈ neighbors G S.val) _).property

/-- Row minima, computed before deleting the pin. -/
noncomputable def tight {V : Type*} [LinearOrder V] (t : R → C → V) (i : R) : Finset C := by
  classical
  exact univ.filter (fun k => ∀ j, t i k ≤ t i j)

omit [Fintype R] [DecidableEq R] [DecidableEq C] in
@[simp] theorem mem_tight {V : Type*} [LinearOrder V] (t : R → C → V) (i : R) (k : C) :
    k ∈ tight t i ↔ ∀ j, t i k ≤ t i j := by classical simp [tight]

omit [Fintype R] [DecidableEq R] [DecidableEq C] in
theorem tight_nonempty {V : Type*} [LinearOrder V] [Nonempty C] (t : R → C → V) (i : R) :
    (tight t i).Nonempty := by
  obtain ⟨k, _, h⟩ := (univ : Finset C).exists_min_image (t i) univ_nonempty
  exact ⟨k, (mem_tight ..).2 (fun j => h j (mem_univ j))⟩

def table {V W : Type*} (f : R → C → V → W) (x : C → V) : R → C → W :=
  fun i j => f i j (x j)

omit [Fintype R] [DecidableEq R] [DecidableEq C] in
/-- The analytic fact used by both branches of the test. -/
theorem transfers_of_monotone {V W : Type*} [LinearOrder V] [LinearOrder W]
    (f : R → C → V → W) (hf : ∀ i j, StrictMono (f i j)) (y x : C → V)
    (hle : ∀ j, y j ≤ x j) :
    Transfers (tight (table f y)) (tight (table f x)) (univ.filter (fun j => y j = x j)) := by
  classical
  intro i hex k hk
  obtain ⟨j, hj, hej⟩ := hex
  have hje := (mem_filter.mp hej).2
  have hmin := (mem_tight ..).1 hj
  have hstar := (mem_tight ..).1 hk j
  change f i k (x k) ≤ f i j (x j) at hstar
  rw [← hje] at hstar
  have hback : f i k (x k) ≤ f i k (y k) := hstar.trans (hmin k)
  have heq := (hf i k).injective (le_antisymm ((hf i k).monotone (hle k)) hback)
  exact ⟨(mem_tight ..).2 (fun b => by simpa [table, heq] using hstar.trans (hmin b)),
    mem_filter.mpr ⟨mem_univ _, heq⟩⟩

/-- Manuscript `le:which`. Only the finite trial table and the pin are inputs to
the test. The pin equality and the true graph occur only in its guarantee.
A matching into the ordinary columns is bijective by the size hypothesis. -/
theorem matchingTest {V W : Type*} [LinearOrder V] [LinearOrder W] [Nonempty C]
    (pin : C) (hd : Fintype.card C = Fintype.card R + 1)
    (f : R → C → V → W) (hf : ∀ i j, StrictMono (f i j))
    (y x : C → V) (hle : ∀ j, y j ≤ x j) (hp : y pin = x pin)
    (hex : FullyExposable (tight (table f x))) :
    match test (tight (table f y)) pin (tight_nonempty _) with
    | .matching m => y = x ∧ Function.Injective m ∧
        ∀ i, m i ∈ (tight (table f x) i).erase pin
    | .short k => k ≠ pin ∧ y k < x k := by
  classical
  let E := univ.filter (fun j => y j = x j)
  have hp' : pin ∈ E := by simpa [E] using hp
  have h := test_correct pin hp' hd (tight_nonempty (table f y))
    ((fullyExposable_iff_strictHall _ (tight_nonempty _)).1 hex)
    (transfers_of_monotone f hf y x hle)
  cases result : test (tight (table f y)) pin (tight_nonempty _) with
  | matching m =>
    rw [result] at h
    obtain ⟨hE, hm, hm'⟩ := h
    have hyx : y = x := by
      funext j
      have hj : j ∈ E := hE.symm ▸ mem_univ j
      exact (mem_filter.mp hj).2
    exact ⟨hyx, hm, hyx ▸ hm'⟩
  | short k =>
    rw [result] at h
    exact ⟨fun hkp => h (hkp ▸ hp'), lt_of_le_of_ne (hle k)
      (fun he => h (mem_filter.mpr ⟨mem_univ _, he⟩))⟩

end CakeCutting.Matching
