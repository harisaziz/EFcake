import CakeCutting.Matching
import CakeCutting.Bounds
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Order.Hom.Basic

/-! Supporting assignments, progress in one rounded relaxation, and the
finite averaging argument in `le:median`. All cardinalities count candidates
with multiplicity of their estimates. -/

namespace CakeCutting.Median

open Finset CakeCutting.Matching

variable {R C : Type*} [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C]

omit [DecidableEq R] in
/-- A set containing every column except a specified free one is the image
of any injection of all rows that avoids that column. -/
theorem covers_except {m : R → C} {free : C}
    (hd : Fintype.card C = Fintype.card R + 1)
    (h : Function.Injective m) (hfree : ∀ i, m i ≠ free) :
    (univ : Finset R).image m = univ.erase free := by
  apply eq_of_subset_of_card_le
  · intro k hk
    obtain ⟨i, _, rfl⟩ := mem_image.mp hk
    exact mem_erase.mpr ⟨hfree i, mem_univ _⟩
  · rw [card_image_of_injective _ h, card_univ, card_erase_of_mem (mem_univ _), card_univ]
    omega

omit [DecidableEq R] in
/-- Each column in a proper set can be assigned a different row tight with
it at the fully exposable vector. -/
theorem covers_subset (G : R → Finset C) (hd : Fintype.card C = Fintype.card R + 1)
    (hx : FullyExposable G) (S : Finset C) (hs : S ≠ univ) :
    ∃ (a : S → R), Function.Injective a ∧ ∀ j, j.val ∈ G (a j) := by
  classical
  have freeExists : ∃ c, c ∉ S := by
    by_contra! h
    exact hs (Finset.eq_univ_iff_forall.mpr h)
  obtain ⟨free, hfree⟩ := freeExists
  obtain ⟨m, hinj, hmem⟩ := hx free
  have cover := covers_except hd hinj (fun i => (mem_erase.mp (hmem i)).1)
  have pick (j : S) : ∃ i, m i = j.val := by
    have h : j.val ∈ (univ : Finset R).image m := by
      rw [cover]
      exact mem_erase.mpr ⟨fun hj => hfree (hj ▸ j.property), mem_univ _⟩
    obtain ⟨i, _, hi⟩ := mem_image.mp h
    exact ⟨i, hi⟩
  choose a ha using pick
  refine ⟨a, ?_, ?_⟩
  · intro j k h
    apply Subtype.ext
    exact (ha j).symm.trans ((congrArg m h).trans (ha k))
  · intro j
    rw [← ha j]
    exact (mem_erase.mp (hmem (a j))).2

/-- The growth inequality before averaging. A column in `colError` or a
row in `rowError` is one carried above the true threshold by its grid.
`advance` is the local implication supplied by a non-crossing tight edge. -/
theorem rounded_step (G : R → Finset C) (hd : Fintype.card C = Fintype.card R + 1)
    (hx : FullyExposable G) (pin : C) (assign : R → C) (hinj : Function.Injective assign)
    (hpin : ∀ i, assign i ≠ pin) (L L' colError : Finset C) (rowError : Finset R)
    (hmono : L ⊆ L') (hkeep : pin ∈ L')
    (advance : ∀ j ∈ L, j ∉ colError → ∀ i, j ∈ G i → i ∉ rowError → assign i ∈ L') :
    L.card + (if L = univ then 0 else 1) ≤ L'.card + colError.card + rowError.card := by
  classical
  by_cases full : L = univ
  · simp only [if_pos full, Nat.add_zero]
    have := card_le_card hmono
    omega
  · simp only [if_neg full]
    let K := L \ colError
    have hproper : K ≠ univ := by
      intro h
      apply full
      apply eq_univ_iff_forall.mpr
      intro c
      have : c ∈ K := h.symm ▸ mem_univ c
      exact (mem_sdiff.mp this).1
    obtain ⟨a, ha, ht⟩ := covers_subset G hd hx K hproper
    let rows := (univ : Finset K).image a
    let good := rows \ rowError
    have nrows : rows.card = K.card := by
      simp [rows, card_image_of_injective _ ha]
    have hnext : good.image assign ⊆ L'.erase pin := by
      intro c hc
      obtain ⟨i, hi, rfl⟩ := mem_image.mp hc
      obtain ⟨hirows, hierror⟩ := mem_sdiff.mp hi
      obtain ⟨j, _, haj⟩ := mem_image.mp hirows
      subst i
      obtain ⟨hjL, hjerr⟩ := mem_sdiff.mp j.property
      exact mem_erase.mpr ⟨hpin _, advance j.val hjL hjerr _ (ht j) hierror⟩
    have a1 : L.card ≤ K.card + colError.card := card_le_card_sdiff_add_card
    have a2 : rows.card ≤ good.card + rowError.card := card_le_card_sdiff_add_card
    have a3 := card_le_card hnext
    rw [card_image_of_injective _ hinj] at a3
    have a4 := card_erase_add_one hkeep
    omega

/-- A supporting edge preserves the upper bound in the simultaneous update.
The level and cost spaces may include infinity. -/
theorem supporting_update {V W : Type*} [LinearOrder V] [LinearOrder W]
    (curve : V ≃o W) (x old : V) (trueCost roundedCost : W)
    (hold : x ≤ old) (hedge : curve x = trueCost) (hcost : trueCost ≤ roundedCost) :
    x ≤ min old (curve.symm roundedCost) := by
  apply le_min hold
  exact curve.le_symm_apply.mpr (hedge ▸ hcost)

/-- Stalled candidates cannot exceed three eighths of the pool when the
total averaged progress and both rounding errors satisfy the per-round
bounds. `size t` is the sum of settled-set sizes across all candidates. -/
theorem phase_five_eighths (q P : ℕ) (hq : 0 < q) (size bad err : ℕ → ℕ)
    (step : ∀ t < 4*q, size t + bad t ≤ size (t+1) + err t)
    (errorCap : ∀ t < 4*q, 8 * err t ≤ P)
    (persistent : ∀ t < 4*q, bad (4*q) ≤ bad t)
    (sizeCap : size (4*q) ≤ size 0 + q*P) :
    8 * bad (4*q) ≤ 3*P := by
  have prefixBound : ∀ t ≤ 4*q, size 0 + (∑ s ∈ range t, bad s) ≤
      size t + (∑ s ∈ range t, err s) := by
    intro t
    induction t with
    | zero => simp
    | succ t ih =>
      intro ht
      rw [sum_range_succ, sum_range_succ]
      have h := ih (by omega)
      have h' := step t (by omega)
      omega
  have hsum := prefixBound (4*q) le_rfl
  have hbad : (4*q) * bad (4*q) ≤ ∑ t ∈ range (4*q), bad t := by
    simpa using (sum_le_sum (s := range (4*q))
      (f := fun _ => bad (4*q)) (g := bad) (fun t ht => persistent t (mem_range.mp ht)))
  have herr : 8 * (∑ t ∈ range (4*q), err t) ≤ (4*q) * P := by
    rw [mul_sum]
    simpa using (sum_le_sum (s := range (4*q))
      (f := fun t => 8 * err t) (g := fun _ => P) (fun t ht => errorCap t (mem_range.mp ht)))
  exact CakeCutting.Bounds.five_eighths q P (bad (4*q)) _ hq (by omega) herr

end CakeCutting.Median
