import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.MeasureTheory.Measure.Typeclasses.NoAtoms
import Mathlib.MeasureTheory.Measure.Real
import Mathlib.Topology.Instances.Real.Lemmas

/-! Robertson–Webb model and the statement labelled `thm:main` in v3. -/

namespace CakeCutting

open Set MeasureTheory

abbrev Point := Set.Icc (0 : ℝ) 1

/-- The underlying measure is on the cake itself. Zero valuations are allowed. -/
structure Valuation where
  measure : Measure Point
  finite : IsFiniteMeasure measure
  atomless : NoAtoms measure

/-- Component intervals may be listed in any order. -/
structure Interval where
  left : Point
  right : Point
  ordered : left ≤ right

/-- Half-open on the right except at the cake's right endpoint. -/
def Interval.points (a : Interval) : Set Point :=
  {x | a.left ≤ x ∧ (x < a.right ∨ (x = a.right ∧ (a.right : ℝ) = 1))}

abbrev Bundle := List Interval

def Bundle.points (b : Bundle) : Set Point := {x | ∃ a ∈ b, x ∈ a.points}

abbrev Allocation (n : ℕ) := Fin n → Bundle

def Complete {n : ℕ} (X : Allocation n) : Prop :=
  (∀ i j, i ≠ j → Disjoint (X i).points (X j).points) ∧
  (∀ x : Point, ∃ i, x ∈ (X i).points)

def EnvyFree {n : ℕ} (v : Fin n → Valuation) (X : Allocation n) : Prop :=
  ∀ i j, (v i).measure (X j).points ≤ (v i).measure (X i).points

inductive Query (n : ℕ) where
  | eval (agent : Fin n) (left right : Point)
  | cut (agent : Fin n) (left : Point) (target : ℝ)

def Query.Answer {n : ℕ} : Query n → Type
  | .eval .. => ℝ
  | .cut .. => Point

def Valid {n : ℕ} (v : Fin n → Valuation) :
    (q : Query n) → q.Answer → Prop
  | .eval i a b, w => a ≤ b ∧ w = (v i).measure.real (Icc a b)
  | .cut i a w, b => a ≤ b ∧ (v i).measure.real (Icc a b) = w

inductive Step (n : ℕ) where
  | ask (q : Query n)
  | finish (X : Allocation n)

abbrev History (n : ℕ) := List ((q : Query n) × q.Answer)

/-- History is newest first. The strategy has no argument giving it the valuation profile. -/
abbrev Protocol (n : ℕ) := History n → Step n

/-- Every legal reply consumes one unit of budget. An infeasible question fails
even if it has no possible continuation. Finishing consumes no queries. -/
def DeliversWithin {n : ℕ} (P : Protocol n) (v : Fin n → Valuation) :
    ℕ → History n → Prop
  | 0, h =>
    match P h with
    | .finish X => Complete X ∧ EnvyFree v X
    | .ask _ => False
  | k + 1, h =>
    match P h with
    | .finish X => Complete X ∧ EnvyFree v X
    | .ask q => (∃ a, Valid v q a) ∧
      ∀ a, Valid v q a → DeliversWithin P v k (⟨q, a⟩ :: h)

/-- Statement of the main theorem. An absolute constant witnesses the bound
simultaneously for all population sizes, instances and valid runs. -/
def MainClaim : Prop :=
  ∃ C : ℕ, 0 < C ∧ ∀ n : ℕ, 2 ≤ n → ∃ P : Protocol n,
    ∀ v : Fin n → Valuation,
      DeliversWithin P v (C * n ^ 8 * (Nat.log2 (2 * n) + 1)) []

end CakeCutting
