import CakeCutting.OracleTree
import CakeCutting.CappedSquare

/-! Counted shared-table program with a general query alphabet. -/
namespace CakeCutting.OracleTables
open Finset OracleTree Quantiles Matching Relaxation
variable {Q : Type} {Ans : Q → Type} {I B : Type} [DecidableEq I]

noncomputable def read (ask : I → Tree Ans B) (default : B) : List I → Tree Ans (I → B)
  | [] => .ret (fun _ => default)
  | i::is => bind (ask i) fun b =>
    bind (read ask default is) fun t => .ret (Function.update t i b)

/-- Even when queries admit several legal cut answers, each table is filled
correctly if each individual accessor meets its specification. -/
theorem collect_good (v : (q : Q) → Ans q → Prop) (ask : I → Tree Ans B) (pred : I → B → Prop)
    (default : B) (entries : List I) (ok : ∀ i ∈ entries, Good v (pred i) 1 (ask i)) :
    Good v (fun t => ∀ i ∈ entries, pred i (t i)) entries.length (read ask default entries) := by
  induction entries with
  | nil => simp [read]
  | cons i is ih =>
    unfold read
    rw [List.length_cons,Nat.add_comm]
    apply bind_good v (pred i) _ _ _ 1 is.length (ok _ (by simp))
    intro b hb
    rw [← Nat.add_zero is.length]
    apply bind_good v (fun t => ∀ j ∈ is, pred j (t j)) _ _ _ _ 0
      (ih (fun j hj => ok j (List.mem_cons_of_mem _ hj)))
    intro t ht
    apply (good_ret ..).2
    intro j hj
    rcases List.mem_cons.mp hj with rfl | hj
    · simpa using hb
    · by_cases eq : j = i
      · subst j; simpa using hb
      · simpa only [Function.update_of_ne eq] using ht j hj

theorem read_good (v : (q : Q) → Ans q → Prop) (ask : I → Tree Ans B) (truth : I → B)
    (default : B) (entries : List I) (ok : ∀ i ∈ entries, Good v (· = truth i) 1 (ask i)) :
    Good v (fun t => ∀ i ∈ entries, t i = truth i) entries.length (read ask default entries) :=
  collect_good v ask (fun i b => b = truth i) default entries ok

structure Access {Q : Type} (Ans : Q → Type) (R C V W : Type) where
  forward : R → C → V → Tree Ans W
  inverse : R → C → W → Tree Ans V

variable {A R C V W : Type} [Fintype A] [Nonempty A] [DecidableEq A]
  [Fintype R] [Fintype C] [Nonempty C] [DecidableEq R] [DecidableEq C]
  [LinearOrder V] [OrderTop V] [LinearOrder W] [OrderTop W]

def Answers (v : (q : Q) → Ans q → Prop) (port : Access Ans R C V W) (f : R → C → V ≃o W) :=
  (∀ i j x, Good v (· = f i j x) 1 (port.forward i j x)) ∧
  (∀ i j y, Good v (· = (f i j).symm y) 1 (port.inverse i j y))

noncomputable def oneRound (port : Access Ans R C V W) (g : ℕ) (hg : 0 < g)
    (pin : C) (M : A → Assignment R C pin) (u : A → C → V) : Tree Ans (A → C → V) := by
  classical
  let col := fun j a => u a j
  let s := SharedTables.addresses (I := R) col g
  exact bind (read (fun d => port.forward d.2.1 d.1 d.2.2) ⊤ s.toList) fun tc =>
    let row := fun i (a : A) => univ.inf' univ_nonempty (fun j =>
      tc ⟨j,(i,roundUp (col j) g hg a)⟩)
    let t := SharedTables.addresses (I := C) row g
    bind (read (fun d => port.inverse d.1 d.2.1 d.2.2) ⊤ t.toList) fun tr =>
      .ret (fun a j => if j = pin then u a j else
        let i := (M a).row j
        min (u a j) (tr ⟨i,(j,roundUp (row i) g hg a)⟩))

def roundCost (r c g : ℕ) := c*(r*g) + r*(c*g)

omit [DecidableEq A] in
theorem oneRound_good (v : (q : Q) → Ans q → Prop) (port : Access Ans R C V W)
    (f : R → C → V ≃o W) (answers : Answers v port f) (g : ℕ) (hg : 0 < g)
    (pin : C) (M : A → Assignment R C pin) (u : A → C → V) :
    Good v (· = update f g hg pin M u) (roundCost (Fintype.card R) (Fintype.card C) g)
      (oneRound port g hg pin M u) := by
  classical
  let col := fun j a => u a j
  let s := SharedTables.addresses (I := R) col g
  let val := fun (d : (j : C) × R × V) => f d.2.1 d.1 d.2.2
  let truth := fun i a => trial f g hg u a i
  let t := SharedTables.addresses (I := C) truth g
  let inv := fun (d : (i : R) × C × W) => (f d.1 d.2.1).symm d.2.2
  unfold oneRound roundCost
  apply bind_good v (fun tc => ∀ d ∈ s.toList, tc d = val d) _ _ _
  · apply mono v _ _ _ (read_good v _ val _ s.toList (fun d _ => answers.1 ..))
    simpa [s] using SharedTables.address_count (I := R) col g
  · intro tc hc
    let row := fun i (a : A) => univ.inf' univ_nonempty (fun j =>
      tc ⟨j,(i,roundUp (col j) g hg a)⟩)
    have ht : row = truth := by
      funext i a
      unfold row truth trial rowCost
      congr 1
      funext j
      exact hc _ (mem_toList.mpr (SharedTables.requested_address col g hg a j i))
    change Good v _ _ (bind (read _ _ (SharedTables.addresses (I := C) row g).toList) _)
    rw [ht]
    rw [← Nat.add_zero (Fintype.card R * (Fintype.card C * g))]
    apply bind_good v (fun tr => ∀ d ∈ t.toList, tr d = inv d) _ _ _ _ 0
    · apply mono v _ _ _ (read_good v _ inv _ t.toList (fun d _ => answers.2 ..))
      simpa [t] using SharedTables.address_count (I := C) truth g
    · intro tr hc'
      apply (good_ret ..).2
      funext a j
      by_cases eq : j = pin
      · simp [update,eq]
      · simp only [update,if_neg eq]
        congr 1
        change tr ⟨(M a).row j,(j,roundUp (row ((M a).row j)) g hg a)⟩ = _
        rw [ht]
        exact hc' _ (mem_toList.mpr (SharedTables.requested_address truth g hg a ((M a).row j) j))

noncomputable def rounds (port : Access Ans R C V W) (g : ℕ) (hg : 0 < g) (pin : C)
    (p : V) (M : A → Assignment R C pin) : ℕ → Tree Ans (A → C → V)
  | 0 => .ret (fun _ j => if j = pin then p else ⊤)
  | k+1 => bind (rounds port g hg pin p M k) (oneRound port g hg pin M)

omit [DecidableEq A] in
theorem rounds_good (v : (q : Q) → Ans q → Prop) (port : Access Ans R C V W) (f : R → C → V ≃o W)
    (answers : Answers v port f) (g : ℕ) (hg : 0 < g) (pin : C) (p : V)
    (M : A → Assignment R C pin) (k : ℕ) :
    Good v (· = Phase.estimates f g hg pin p M k)
      (k*roundCost (Fintype.card R) (Fintype.card C) g) (rounds port g hg pin p M k) := by
  induction k with
  | zero => simp [rounds,Phase.estimates]
  | succ k ih =>
    rw [Nat.succ_mul,rounds]
    apply bind_good v _ _ _ _ _ _ ih
    rintro _ rfl
    exact oneRound_good v port f answers g hg pin M _

noncomputable def phaseTree (port : Access Ans R C V W) (pin : C) (p : V)
    (M : A → Assignment R C pin) (s : Finset A) (hs : s.Nonempty) :
    Tree Ans (Solver.Outcome A C V R) := by
  classical
  letI : Nonempty s := hs.to_subtype
  let q := Fintype.card R
  let g := 8*(2*q+1)
  exact bind (rounds port g (by dsimp [g]; omega) pin p (fun a : s => M a) (4*q)) fun u =>
    let y := fun j => quantile (fun a => u a j) 2 1 (by decide)
    bind (read (fun d : R × C => port.forward d.1 d.2 (y d.2)) ⊤ univ.toList) fun t =>
      let z := fun i j => t (i,j)
      match test (tight z) pin (tight_nonempty z) with
      | .matching m => .ret (.done y m)
      | .short j => .ret (.again ((univ.filter (fun a : s => y j < u a j)).image Subtype.val))

private theorem phaseCost (q : ℕ) (hq : 0 < q) :
    (4*q)*roundCost q (q+1) (8*(2*q+1)) + q*(q+1) ≤ 386*q^4 := by
  have h1 : q+1 ≤ 2*q := by omega
  have h2 : 8*(2*q+1) ≤ 24*q := by omega
  have hh := Nat.mul_le_mul (Nat.mul_le_mul_left q h1) h2
  have ht := Nat.mul_le_mul_left (4*q) (Nat.mul_le_mul_left 2 hh)
  have last : q*(q+1) ≤ 2*q^4 := by
    have h := Nat.mul_le_mul_left q h1
    have hpow : q^2 ≤ q^4 := Nat.pow_le_pow_right hq (by decide)
    nlinarith only [h,hpow]
  unfold roundCost
  convert (Nat.add_le_add ht last).trans (show _ ≤ 386*q^4 by ring_nf; omega) using 1; ring

omit [Fintype A] [Nonempty A] in
theorem phaseTree_good (v : (q : Q) → Ans q → Prop) (port : Access Ans R C V W) (f : R → C → V ≃o W)
    (answers : Answers v port f) (pin : C) (p : V) (M : A → Assignment R C pin)
    (s : Finset A) (hs : s.Nonempty) (hq : 0 < Fintype.card R)
    (dim : Fintype.card C = Fintype.card R + 1) :
    Good v (· = Solver.phase f pin p M s hs) (386*(Fintype.card R)^4)
      (phaseTree port pin p M s hs) := by
  classical
  letI : Nonempty s := hs.to_subtype
  let q := Fintype.card R
  let g := 8*(2*q+1)
  have hg : 0 < g := by dsimp [g]; omega
  let u := Phase.estimates f g hg pin p (fun a : s => M a) (4*q)
  let y := fun j => quantile (fun a => u a j) 2 1 (by decide)
  apply mono v _ (by simpa only [dim] using phaseCost q hq :
    4*q*roundCost q (Fintype.card C) g + q* (Fintype.card C) ≤ 386*q^4)
  unfold phaseTree
  apply bind_good v _ _ _ _ _ _ (rounds_good v port f answers g hg pin p (fun a : s => M a) (4*q))
  rintro _ rfl
  rw [← Nat.add_zero (q*Fintype.card C)]
  let val := fun d : R × C => f d.1 d.2 (y d.2)
  apply bind_good v (fun t => ∀ d ∈ (univ : Finset (R × C)).toList, t d = val d) _ _ _ _ 0
  · simpa [q] using read_good v _ val ⊤ univ.toList (fun d _ => answers.1 d.1 d.2 _)
  · intro t ht
    have eqn : (fun i j => t (i,j)) = table (fun i j z => f i j z) y :=
      funext (fun i => funext (fun j => ht (i,j) (by simp)))
    unfold Solver.phase
    dsimp only
    rw [eqn]
    let z := table (fun i j w => f i j w) y
    change Good v (fun out =>
      out = match test (tight z) pin (tight_nonempty z) with
      | .matching m => .done y m
      | .short j => .again ((univ.filter (fun a : s => y j < u a j)).image Subtype.val)) 0
      (match test (tight z) pin (tight_nonempty z) with
      | .matching m => .ret (Solver.Outcome.done y m)
      | .short j => .ret (.again ((univ.filter (fun a : s => y j < u a j)).image Subtype.val)))
    cases h : test (tight z) pin (tight_nonempty z) <;> rfl

noncomputable def runTree (port : Access Ans R C V W) (pin : C) (p : V)
    (M : A → Assignment R C pin) : ℕ → Finset A → Tree Ans (Option ((C → V) × (R → C)))
  | 0,_ => .ret none
  | k+1,s => if hs : s.Nonempty then bind (phaseTree port pin p M s hs) fun out =>
      match out with
      | .done y m => .ret (some (y,m))
      | .again t => runTree port pin p M k t
    else .ret none

omit [Fintype A] [Nonempty A] in
theorem runTree_good (v : (q : Q) → Ans q → Prop) (port : Access Ans R C V W) (f : R → C → V ≃o W)
    (answers : Answers v port f) (pin : C) (p : V) (M : A → Assignment R C pin)
    (hq : 0 < Fintype.card R) (dim : Fintype.card C = Fintype.card R + 1) (k : ℕ) (s : Finset A) :
    Good v (· = Solver.run f pin p M k s) (k*(386*(Fintype.card R)^4))
      (runTree port pin p M k s) := by
  induction k generalizing s with
  | zero => simp [runTree,Solver.run]
  | succ k ih =>
    rw [runTree,Solver.run]
    by_cases hs : s.Nonempty
    · simp only [dif_pos hs]
      rw [Nat.succ_mul,Nat.add_comm]
      apply bind_good v _ _ _ _ _ _ (phaseTree_good v port f answers pin p M s hs hq dim)
      rintro _ rfl
      cases h : Solver.phase f pin p M s hs with
      | done y m => exact (good_ret ..).2 rfl
      | again t => exact ih t
    · simp [hs]

end CakeCutting.OracleTables
