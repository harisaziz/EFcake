import Mathlib.Data.Nat.Basic
/-! Typed decision trees with a variable query alphabet and admissible-answer relation. -/
namespace CakeCutting.OracleTree
inductive Tree {I : Type} (Ans : I → Type) (α : Type) where
  | ret (a : α)
  | ask (q : I) (next : Ans q → Tree Ans α)

variable {I : Type} {Ans : I → Type} {α β : Type}

def bind (t : Tree Ans α) (g : α → Tree Ans β) : Tree Ans β :=
  match t with
  | .ret a => g a
  | .ask q next => .ask q (fun a => bind (next a) g)

def Good (v : (q : I) → Ans q → Prop) (post : α → Prop) : ℕ → Tree Ans α → Prop
  | _, .ret a => post a
  | 0, .ask .. => False
  | k+1, .ask q next => (∃ a, v q a) ∧ ∀ a, v q a → Good v post k (next a)

@[simp] theorem good_ret (v : (q : I) → Ans q → Prop) (P : α → Prop) (k : ℕ) (a : α) :
    Good v P k (.ret a) ↔ P a := by cases k <;> rfl

theorem mono (v : (q : I) → Ans q → Prop) (post : α → Prop) {k l : ℕ} (hkl : k ≤ l)
    (t : Tree Ans α) (h : Good v post k t) : Good v post l t := by
  induction t generalizing k l with
  | ret a => exact (good_ret ..).2 ((good_ret ..).1 h)
  | ask q next ih =>
    cases k with
    | zero => exact False.elim h
    | succ k =>
      cases l with
      | zero => omega
      | succ l => exact ⟨h.1,fun a ha => ih a (by omega) (h.2 a ha)⟩

theorem bind_good (v : (q : I) → Ans q → Prop) (P : α → Prop) (Q : β → Prop)
    (t : Tree Ans α) (g : α → Tree Ans β) (k l : ℕ)
    (h : Good v P k t) (hg : ∀ a, P a → Good v Q l (g a)) :
    Good v Q (k+l) (bind t g) := by
  induction t generalizing k with
  | ret a => exact mono v Q (by omega) _ (hg a ((good_ret ..).1 h))
  | ask q next ih =>
    cases k with
    | zero => exact False.elim h
    | succ k =>
      rw [Nat.succ_add]
      exact ⟨h.1,fun a ha => ih a k (h.2 a ha)⟩

theorem strengthen (v : (q : I) → Ans q → Prop) (A B : α → Prop)
    (k : ℕ) (t : Tree Ans α) (h : Good v A k t) (imp : ∀ a, A a → B a) : Good v B k t := by
  induction t generalizing k with
  | ret => exact (good_ret ..).2 (imp _ ((good_ret ..).1 h))
  | ask q next ih =>
    cases k with
    | zero => exact h.elim
    | succ k => exact ⟨h.1,fun a ha => ih a k (h.2 a ha)⟩

end CakeCutting.OracleTree
