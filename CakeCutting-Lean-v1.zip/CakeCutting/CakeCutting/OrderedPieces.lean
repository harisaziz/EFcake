import CakeCutting.PhysicalBundles
import CakeCutting.CommonShares
import CakeCutting.TableProtocol
import Mathlib.Data.Sum.Order

/-! One physical order of suffix positions shared by all observers of a bundle.
As marks increase in this order, the retained value is nondecreasing. -/
namespace CakeCutting.Components
open Set MeasureTheory DecisionTree Finset

private def Key : Bundle → Type
  | [] => Unit
  | _::s => Key s ⊕ₗ Pointᵒᵈ

private noncomputable def keyOrder : (s : Bundle) → LinearOrder (Key s)
  | [] => inferInstanceAs (LinearOrder Unit)
  | _::s => letI : LinearOrder (Key s) := keyOrder s; inferInstanceAs (LinearOrder (_ ⊕ₗ Pointᵒᵈ))

private def key : {s : Bundle} → Mark s → Key s
  | _,.empty => ()
  | _::_,.here p _ _ => toLex (.inr (OrderDual.toDual p))
  | _::_,.later p => toLex (.inl (key p))

private theorem key_inj (s : Bundle) : Function.Injective (@key s) := by
  induction s with
  | nil => intro p q; cases p; cases q; intro; rfl
  | cons a s ih =>
    intro p q eq
    cases p <;> cases q
    · congr 1; exact Sum.inr.inj (toLex.injective eq)
    · cases toLex.injective eq
    · cases toLex.injective eq
    · congr 1; exact ih (Sum.inl.inj (toLex.injective eq))

noncomputable instance markOrder (s : Bundle) : LinearOrder (Mark s) :=
  letI : LinearOrder (Key s) := keyOrder s
  LinearOrder.lift' key (key_inj s)

def emptyMark : (s : Bundle) → Mark s
  | [] => .empty
  | _::s => .later (emptyMark s)

def wholeMark : (s : Bundle) → Mark s
  | [] => .empty
  | a::_ => .here a.left le_rfl a.ordered

theorem endpoint_values (v : Valuation) (s : Bundle) :
    retained v (emptyMark s) = 0 ∧ retained v (wholeMark s) = total (mass v) s := by
  induction s with
  | nil => exact ⟨rfl,rfl⟩
  | cons a s ih => exact ⟨ih.1,rfl⟩

theorem mark_range (s : Bundle) (p : Mark s) : emptyMark s ≤ p ∧ p ≤ wholeMark s := by
  induction p with
  | empty => exact ⟨le_rfl,le_rfl⟩
  | @here a s p hl hr =>
    letI := keyOrder s
    exact ⟨Sum.Lex.inl_le_inr (key (emptyMark s)) (OrderDual.toDual p),
      Sum.Lex.inr_le_inr_iff.mpr (OrderDual.toDual_le_toDual.mpr hl)⟩
  | @later a s p ih =>
    letI := keyOrder s
    exact ⟨Sum.Lex.inl_le_inl_iff.mpr ih.1,Sum.Lex.inl_le_inr (key p) (OrderDual.toDual a.left)⟩

private theorem retained_le (v : Valuation) {s : Bundle} (p : Mark s) : retained v p ≤ total (mass v) s := by
  letI := v.finite
  induction p with
  | empty => rfl
  | here p hl hr =>
    apply add_le_add_right
    exact measureReal_mono (Icc_subset_Icc_left hl)
  | @later a s p ih =>
    change retained v p ≤ mass v a + total (mass v) s
    exact ih.trans (le_add_of_nonneg_left measureReal_nonneg)

theorem monotone_retained (v : Valuation) (s : Bundle) : Monotone (@retained v s) := by
  letI := v.finite
  induction s with
  | nil => intro p q; cases p; cases q; intro; rfl
  | cons a s ih =>
    letI := keyOrder s
    intro p q h
    cases p <;> cases q
    · rename_i p hp hp' q hq hq'
      have pq : q ≤ p := OrderDual.toDual_le_toDual.mp (Sum.Lex.inr_le_inr_iff.mp h)
      exact add_le_add_right (measureReal_mono (Icc_subset_Icc_left pq)) _
    · exact (Sum.Lex.not_inr_le_inl h).elim
    · rename_i p q hq hq'
      exact (retained_le v p).trans (le_add_of_nonneg_left measureReal_nonneg)
    · rename_i p q
      have le : key p ≤ key q := Sum.Lex.inl_le_inl_iff.mp h
      exact ih (show p ≤ q from le)

/-- A node collecting one answer per agent, followed by the weighted median.
The selected mark splits the aggregate mass between one quarter and three
quarters for every legal set of cut answers. -/
noncomputable def balanced {n : ℕ} [NeZero n] (s : Bundle) (record : Fin n → Interval → ℝ) :
    Tree n (Mark s) :=
  let w := fun i => total (record i) s
  bind (TableProtocol.read (fun i => cut i (record i) (w i/2) s) (emptyMark s) univ.toList) fun marks =>
    .ret (marks (Classical.choose (CommonShares.weighted_median marks (fun i => max 0 (w i))
      (fun _ => le_max_left ..))))

theorem balanced_good {n : ℕ} [NeZero n] (v : Fin n → Valuation) (s : Bundle)
    (record : Fin n → Interval → ℝ) (ok : ∀ i a, a ∈ s → record i a = mass (v i) a) :
    let W := ∑ i, total (record i) s
    Good v (fun p => (∑ i, retained (v i) p) ≤ 3*W/4 ∧
      W-(∑ i, retained (v i) p) ≤ 3*W/4) n (balanced s record) := by
  classical
  let w := fun i => total (record i) s
  have wn (i) : 0 ≤ w i := by
    rw [show w i = total (mass (v i)) s from recorded_total _ _ _ (ok i)]
    exact List.sum_nonneg (fun x h => by obtain ⟨a,_,rfl⟩ := List.mem_map.mp h; exact measureReal_nonneg)
  let post := fun (t : Fin n → Mark s) => ∀ i ∈ (univ : Finset (Fin n)).toList, retained (v i) (t i) = w i/2
  dsimp only
  unfold balanced
  apply bind_good v post _ _ _ n 0
  · have := TableProtocol.collect_good v (fun i => cut i (record i) (w i/2) s)
      (fun i p => retained (v i) p = w i/2) (emptyMark s) univ.toList (fun i _ =>
        cut_good v i _ _ (by have := wn i; linarith) s (by have := wn i; change w i/2 ≤ w i; linarith) (ok i))
    simpa [post] using this
  · intro t h
    let g := fun i => max 0 (w i)
    have ge : g = w := funext (fun i => max_eq_right (wn i))
    let m := Classical.choose (CommonShares.weighted_median t g (fun _ => le_max_left ..))
    have spec := Classical.choose_spec (CommonShares.weighted_median t g (fun _ => le_max_left ..))
    change _ ≤ _ ∧ _ ≤ _ at spec
    change (∑ i, g i)/2 ≤ ∑ i ∈ univ.filter (fun i => t i ≤ t m), g i ∧
      (∑ i, g i)/2 ≤ ∑ i ∈ univ.filter (fun i => t m ≤ t i), g i at spec
    rw [ge] at spec
    apply (good_ret ..).2
    change (∑ i, retained (v i) (t m)) ≤ _ ∧ _ ≤ _
    have hh := CommonShares.bounds_at t w (fun i => @retained (v i) s) (fun i => monotone_retained _ _)
      (fun i => h i (by simp)) (fun i k => by
        have e := (endpoint_values (v i) s).1
        exact e ▸ monotone_retained _ _ (mark_range s k).1)
      (fun i k => (retained_le _ k).trans_eq (recorded_total _ _ _ (ok i)).symm) m spec
    simpa only [Finset.sum_sub_distrib] using hh

end CakeCutting.Components
