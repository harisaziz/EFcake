import CakeCutting.Relaxation

/-! The median theorem for an actual phase at the paper's quantile resolution. -/
namespace CakeCutting.Phase

open Finset CakeCutting.Matching CakeCutting.Relaxation CakeCutting.Quantiles

variable {A R C V W : Type*} [Fintype A] [Nonempty A] [DecidableEq A]
  [Fintype R] [Fintype C] [Nonempty C] [DecidableEq C] [DecidableEq R]
  [LinearOrder V] [OrderTop V] [LinearOrder W]

private theorem transpose_count {B K : Type*} [Fintype B] [Fintype K] [DecidableEq B]
    (s : K → Finset B) :
    (∑ b, (univ.filter (fun k => b ∈ s k)).card) = ∑ k, (s k).card := by
  classical
  calc
    _ = ∑ b, ∑ k, if b ∈ s k then 1 else 0 := by simp
    _ = ∑ k, ∑ b, if b ∈ s k then 1 else 0 := sum_comm
    _ = _ := by simp

def estimates (f : R → C → V ≃o W) (g : ℕ) (hg : 0 < g) (pin : C)
    (p : V) (M : A → Assignment R C pin) : ℕ → A → C → V
  | 0 => fun _ j => if j = pin then p else ⊤
  | t+1 => update f g hg pin M (estimates f g hg pin p M t)

/-- For a nonempty pool, at most three eighths are unfinished after 4q
rounded rounds. The actual coordinatewise lower median is a lower bound,
and every supporting candidate has maintained its upper bound at every round. -/
theorem median_phase (f : R → C → V ≃o W) (pin : C) (M : A → Assignment R C pin)
    (x : C → V) (hq : 0 < Fintype.card R) (hd : Fintype.card C = Fintype.card R + 1)
    (hex : FullyExposable (tight (table (fun i j v => f i j v) x))) :
    let q := Fintype.card R
    let g := 8*(2*q+1)
    let u := estimates f g (by dsimp [g]; omega) pin (x pin) M
    8 * (univ.filter (fun a => settled (u (4*q) a) x ≠ univ)).card ≤ 3*Fintype.card A ∧
    (∀ j, quantile (fun a => u (4*q) a j) 2 1 (by decide) ≤ x j) ∧
    (∀ a, (∀ i, (M a).col i ∈ tight (table (fun i j v => f i j v) x) i) →
      ∀ t j, x j ≤ u t a j) := by
  classical
  let q := Fintype.card R
  let P := Fintype.card A
  let g := 8*(2*q+1)
  have hg : 0 < g := by dsimp [g]; omega
  let u := estimates f g hg pin (x pin) M
  let L := fun t a => settled (u t a) x
  let bad := fun t => (univ : Finset A).filter (fun a => L t a ≠ univ)
  let size := fun t => ∑ a, (L t a).card
  let err := fun t => ∑ a, ((colErrors g hg (u t) x a).card + (rowErrors f g hg (u t) x a).card)
  have hp (t : ℕ) (a : A) : u t a pin = x pin := by
    induction t with
    | zero => simp [u, estimates]
    | succ t ih => simpa [u, estimates, update] using ih
  have step (t : ℕ) : size t + (bad t).card ≤ size (t+1) + err t := by
    have h := sum_le_sum (s := (univ : Finset A)) (fun a _ =>
      update_progress f g hg pin M (u t) a x hd (hp t a) hex)
    simp only [sum_add_distrib] at h
    have hcount : (∑ a, if L t a = univ then 0 else 1 : ℕ) = (bad t).card := by
      simpa only [ite_not] using (sum_boole (R := ℕ) (fun a => L t a ≠ univ) univ)
    change size t + (∑ a, if L t a = univ then 0 else 1) ≤
      size (t+1) + _ + _ at h
    simpa only [hcount, err, sum_add_distrib, Nat.add_assoc] using h
  have ecap (t : ℕ) : 8 * err t ≤ P := by
    let cs := fun j => crossings (fun a => u t a j) g hg (x j)
    let rs := fun i => crossings (fun a => trial f g hg (u t) a i) g hg (rowCost f x i)
    have he : err t = (∑ j, (cs j).card) + ∑ i, (rs i).card := by
      exact (sum_add_distrib ..).trans (congrArg₂ (· + ·) (transpose_count cs) (transpose_count rs))
    have c1 : g*(∑ j, (cs j).card) ≤ Fintype.card C * P := by
      rw [mul_sum]
      simpa [P] using sum_le_sum (s := (univ : Finset C))
        (fun j _ => (crossing_bound (fun a => u t a j) g hg (x j)).le)
    have c2 : g*(∑ i, (rs i).card) ≤ q * P := by
      rw [mul_sum]
      simpa [q, P] using sum_le_sum (s := (univ : Finset R))
        (fun i _ => (crossing_bound (fun a => trial f g hg (u t) a i) g hg (rowCost f x i)).le)
    have both := Nat.add_le_add c1 c2
    rw [← Nat.mul_add, ← he, ← Nat.add_mul] at both
    have dim : Fintype.card C + q = 2*q+1 := by dsimp [q]; omega
    rw [dim] at both
    have hc : (2*q+1)*(8*err t) ≤ (2*q+1)*P := by
      simpa only [g, Nat.mul_assoc, Nat.mul_left_comm] using both
    exact Nat.le_of_mul_le_mul_left hc (by omega)
  have grows (a : A) : Monotone (fun t => L t a) := by
    apply monotone_nat_of_le_succ
    intro t j hj
    exact mem_filter.mpr ⟨mem_univ _, (update_le f g hg pin M (u t) a j).trans (mem_filter.mp hj).2⟩
  have persists (t : ℕ) (ht : t < 4*q) : (bad (4*q)).card ≤ (bad t).card := by
    apply card_le_card
    intro a ha
    apply mem_filter.mpr
    refine ⟨mem_univ _, fun hfull => (mem_filter.mp ha).2 ?_⟩
    apply eq_univ_iff_forall.mpr
    intro j
    have hj : j ∈ L t a := hfull.symm ▸ mem_univ j
    exact grows a ht.le hj
  have cap : size (4*q) ≤ size 0 + q*P := by
    have topbound := sum_le_sum (s := (univ : Finset A)) (fun a _ => card_le_univ (L (4*q) a))
    have lower : (∑ _a : A, (1 : ℕ)) ≤ size 0 := sum_le_sum (s := (univ : Finset A)) (fun a (_ : a ∈ univ) =>
      (card_pos (s := L 0 a)).mpr ⟨pin, mem_filter.mpr ⟨mem_univ _, (hp 0 a).le⟩⟩)
    have lo : P ≤ size 0 := by simpa [P, size] using lower
    have hi : size (4*q) ≤ P * (q+1) := by simpa [size,P,q,hd] using topbound
    rw [Nat.mul_add, Nat.mul_one, Nat.mul_comm P q] at hi
    omega
  have count := Median.phase_five_eighths q P hq size (fun t => (bad t).card) err
    (fun t _ => step t) (fun t _ => ecap t) persists cap
  refine ⟨count, ?_, ?_⟩
  · intro j
    apply (lowerMedian _ _ ?_).1
    have sub : univ \ bad (4*q) ⊆ below (fun a => u (4*q) a j) (x j) := by
      intro a ha
      have hsett : L (4*q) a = univ := by
        by_contra h
        exact (mem_sdiff.mp ha).2 (mem_filter.mpr ⟨mem_univ _, h⟩)
      have hj : j ∈ L (4*q) a := hsett.symm ▸ mem_univ _
      exact mem_filter.mpr ⟨mem_univ _, (mem_filter.mp hj).2⟩
    have hs := card_sdiff_add_card_eq_card (subset_univ (bad (4*q)))
    have hle := card_le_card sub
    rw [card_univ] at hs
    change Fintype.card A ≤ 2 * (below (fun a => u (4*q) a j) (x j)).card
    change 8*(bad (4*q)).card ≤ 3*Fintype.card A at count
    omega
  · intro a hm t
    induction t with
    | zero => intro j; by_cases h : j = pin <;> simp [estimates, h]
    | succ t ih => exact support_preserved f g hg pin M (u t) a x ih hm

/-- The median phase from the paper, followed by the table-only matching
test and the candidate filter. The truth vector occurs only in the guarantee;
the pin level is supplied independently as the input p. -/
theorem test_and_filter (f : R → C → V ≃o W) (pin : C) (p : V)
    (M : A → Assignment R C pin) (x : C → V) (hp : x pin = p)
    (hq : 0 < Fintype.card R) (hd : Fintype.card C = Fintype.card R + 1)
    (hex : FullyExposable (tight (table (fun i j v => f i j v) x))) :
    let q := Fintype.card R
    let g := 8*(2*q+1)
    let u := estimates f g (by dsimp [g]; omega) pin p M (4*q)
    let y := fun j => quantile (fun a => u a j) 2 1 (by decide)
    let curves := fun i j v => f i j v
    match test (tight (table curves y)) pin (tight_nonempty _) with
    | .matching m => y = x ∧ Function.Injective m ∧
        ∀ i, m i ∈ (tight (table curves x) i).erase pin
    | .short k => k ≠ pin ∧ y k < x k ∧
        (∀ a, (∀ i, (M a).col i ∈ tight (table curves x) i) → y k < u a k) ∧
        2 * (univ.filter (fun a => y k < u a k)).card ≤ Fintype.card A := by
  classical
  subst p
  let q := Fintype.card R
  let g := 8*(2*q+1)
  have hg : 0 < g := by dsimp [g]; omega
  let est := estimates f g hg pin (x pin) M
  let u := est (4*q)
  let y := fun j => quantile (fun a => u a j) 2 1 (by decide)
  let curves := fun i j v => f i j v
  obtain ⟨_, hle, hsup⟩ := median_phase f pin M x hq hd hex
  have he (t : ℕ) (a : A) : est t a pin = x pin := by
    induction t with
    | zero => simp [est, estimates]
    | succ t ih => simpa [est, estimates, update] using ih
  have pin_eq : y pin = x pin := by
    obtain ⟨a, h⟩ := quantile_observed (fun a => u a pin) 2 1 (by decide)
    exact h.symm.trans (he _ a)
  have result := matchingTest pin hd curves (fun i j => (f i j).strictMono) y x hle pin_eq hex
  change match test (tight (table curves y)) pin (tight_nonempty _) with
    | .matching m => _
    | .short k => _
  cases htest : test (tight (table curves y)) pin (tight_nonempty _) with
  | matching m => simpa only [htest] using result
  | short k =>
    rw [htest] at result
    obtain ⟨hn, hshort⟩ := result
    have rank : Fintype.card A ≤ 2 * (below (fun a => u a k) (y k)).card := by
      simpa [y] using quantile_rank (fun a => u a k) 2 1 (by decide)
    have filterResult := Bounds.filter_short_column (univ : Finset A) (fun a => u a k)
      (y k) (x k) (fun a => ∀ i, (M a).col i ∈ tight (table curves x) i)
      (fun a _ ha => hsup a ha (4*q) k) hshort (by simpa [below] using rank)
    refine ⟨hn, hshort, fun a ha => ?_, ?_⟩
    · exact (mem_filter.mp (filterResult.1 a (mem_univ _) ha)).2
    · simpa using filterResult.2

end CakeCutting.Phase
