import CakeCutting.Components

/-! The retained component sum equals the value of an actual bundle in Model.
Ordered component records may be in any order, with empty components allowed. -/
namespace CakeCutting.Components
open Set MeasureTheory

theorem interval_points (a : Interval) : a.points =
    if (a.right : ℝ) = 1 then Icc a.left a.right else Ico a.left a.right := by
  ext t
  by_cases h : (a.right : ℝ) = 1
  · rw [if_pos h]
    change (a.left ≤ t ∧ (t < a.right ∨ t = a.right ∧ (a.right : ℝ) = 1)) ↔
      a.left ≤ t ∧ t ≤ a.right
    simp only [h,and_true,← le_iff_lt_or_eq]
  · rw [if_neg h]
    change (a.left ≤ t ∧ (t < a.right ∨ t = a.right ∧ (a.right : ℝ) = 1)) ↔
      a.left ≤ t ∧ t < a.right
    simp [h]

theorem interval_mass (v : Valuation) (a : Interval) : v.measure.real a.points = mass v a := by
  letI := v.atomless
  rw [interval_points]
  split
  · rfl
  · exact measureReal_congr Ico_ae_eq_Icc

theorem cons_points (a : Interval) (s : Bundle) : Bundle.points (a::s) = a.points ∪ s.points := by
  ext t
  change (∃ b ∈ a::s, t ∈ b.points) ↔ t ∈ a.points ∨ ∃ b ∈ s, t ∈ b.points
  simp

theorem empty_points : Bundle.points [] = ∅ := by ext t; simp [Bundle.points]

theorem measurable_points (s : Bundle) : MeasurableSet s.points := by
  induction s with
  | nil => rw [empty_points]; exact MeasurableSet.empty
  | cons a s ih =>
    rw [cons_points,interval_points]
    split <;> first | exact measurableSet_Icc.union ih | exact measurableSet_Ico.union ih

def Separate (s : Bundle) := s.Pairwise (fun a b => Disjoint a.points b.points)

private theorem disj_tail {a : Interval} {s : Bundle} (h : Separate (a::s)) :
    Disjoint a.points s.points := by
  apply Set.disjoint_left.mpr
  rintro x hx ⟨b,hb,hit⟩
  exact Set.disjoint_left.mp ((List.pairwise_cons.mp h).1 b hb) hx hit

theorem total_eq_measure (v : Valuation) (s : Bundle) (disj : Separate s) :
    total (mass v) s = v.measure.real s.points := by
  letI := v.finite
  induction s with
  | nil => simp [total,empty_points]
  | cons a s ih =>
    rw [cons_points,measureReal_union (disj_tail disj) (measurable_points s)]
    change mass v a + total (mass v) s = _
    rw [← interval_mass,ih (List.pairwise_cons.mp disj).2]

noncomputable def suffix : {s : Bundle} → Mark s → Bundle
  | _,.empty => []
  | a::s,.here p _ hr => if p = a.right ∧ p ≠ a.left then s else ⟨p,a.right,hr⟩ :: s
  | _::_,.later p => suffix p

private theorem shortened {a : Interval} {p : Point} (hl : a.left ≤ p) (hr : p ≤ a.right) :
    (⟨p,a.right,hr⟩ : Interval).points ⊆ a.points :=
  fun _ h => ⟨hl.trans h.1,h.2⟩

theorem suffix_separate {s : Bundle} (p : Mark s) (disj : Separate s) : Separate (suffix p) := by
  induction p with
  | empty => exact disj
  | here p hl hr =>
    obtain ⟨head,tail⟩ := List.pairwise_cons.mp disj
    unfold suffix
    split
    · exact tail
    · exact List.pairwise_cons.mpr ⟨fun b hb => (head b hb).mono_left (shortened hl hr),tail⟩
  | later p ih => exact ih (List.pairwise_cons.mp disj).2

theorem suffix_value (v : Valuation) {s : Bundle} (p : Mark s) (disj : Separate s) :
    retained v p = v.measure.real (suffix p).points := by
  rw [← total_eq_measure v _ (suffix_separate p disj)]
  induction p with
  | empty => rfl
  | @here a s p hl hr =>
    unfold suffix
    split
    · rename_i eq
      letI := v.atomless
      simp [retained,eq.1,Measure.real]
    · rfl
  | later p ih => exact ih (List.pairwise_cons.mp disj).2

/-- The left complement of a suffix. At the right endpoint a nondegenerate
component stays whole in the trimmings. At the left endpoint it stays whole in
the suffix. This convention also partitions literal singleton components. -/
noncomputable def trimmings : {s : Bundle} → Mark s → Bundle
  | _,.empty => []
  | a::_,.here p hl _ => if p = a.left then [] else [⟨a.left,p,hl⟩]
  | a::_,.later p => a :: trimmings p

/-- Exact coverage and disjointness, including the cake's point 1. -/
theorem partition {s : Bundle} (p : Mark s) (sep : Separate s) :
    (trimmings p).points ∪ (suffix p).points = s.points ∧
      Disjoint (trimmings p).points (suffix p).points := by
  induction p with
  | empty => simp [trimmings,suffix,empty_points]
  | @here a s p hl hr =>
    by_cases left : p = a.left
    · subst p
      simp [trimmings,suffix,empty_points]
    · by_cases right : p = a.right
      · subst p
        simp only [trimmings,suffix,left,if_false,ne_eq,not_false_eq_true,and_self,if_true,
          cons_points,empty_points,Set.union_empty]
        exact ⟨trivial,disj_tail sep⟩
      · let a₁ : Interval := ⟨a.left,p,hl⟩
        let a₂ : Interval := ⟨p,a.right,hr⟩
        have small : (p:ℝ) ≠ 1 := by
          intro h
          exact right (le_antisymm hr (show (a.right:ℝ) ≤ (p:ℝ) from h ▸ a.right.property.2))
        have pt : a₁.points = Ico a.left p := by rw [interval_points,if_neg small]
        have joined : a₁.points ∪ a₂.points = a.points := by
          ext x
          rw [pt]
          change (a.left ≤ x ∧ x < p ∨ p ≤ x ∧ _) ↔ a.left ≤ x ∧ _
          constructor
          · rintro (h | h)
            · exact ⟨h.1,Or.inl (h.2.trans_le hr)⟩
            · exact ⟨hl.trans h.1,h.2⟩
          · intro h
            rcases lt_or_ge x p with lt | ge
            · exact Or.inl ⟨h.1,lt⟩
            · exact Or.inr ⟨ge,h.2⟩
        have apart : Disjoint a₁.points a₂.points :=
          Set.disjoint_left.mpr (fun _ h₁ h₂ => (pt ▸ h₁).2.not_ge h₂.1)
        have sub : a₁.points ⊆ a.points := joined ▸ Set.subset_union_left
        simp only [trimmings,suffix,if_neg left,right,false_and,if_false,cons_points,empty_points,Set.union_empty]
        change a₁.points ∪ (a₂.points ∪ s.points) = a.points ∪ s.points ∧ _
        exact ⟨by rw [← Set.union_assoc,joined],
          Disjoint.union_right apart ((disj_tail sep).mono_left sub)⟩
  | @later a s p ih =>
    obtain ⟨cover,disj⟩ := ih (List.pairwise_cons.mp sep).2
    simp only [trimmings,suffix,cons_points]
    exact ⟨by rw [Set.union_assoc,cover],Disjoint.union_left
      ((disj_tail sep).mono_right (cover ▸ Set.subset_union_right)) disj⟩

end CakeCutting.Components
