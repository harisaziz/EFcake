import CakeCutting.Model
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Topology.Order.IntermediateValue

/-! Feasibility of the physical Robertson–Webb cut query for the exact
valuation type in Model, including intervals with flat cumulative value. -/
namespace CakeCutting.PhysicalCuts
open Set MeasureTheory
noncomputable section

/-- An atomless finite valuation realizes every requested amount from zero
to the value of the interval, including both endpoints. -/
theorem cut_exists (v : Valuation) (a b : Point) (hab : a ≤ b) (w : ℝ)
    (hw : 0 ≤ w) (hwb : w ≤ v.measure.real (Icc a b)) :
    ∃ p : Point, a ≤ p ∧ p ≤ b ∧ v.measure.real (Icc a p) = w := by
  letI := v.finite
  letI := v.atomless
  let μ := v.measure.map (fun t : Point => (t : ℝ))
  have measurable : Measurable (fun t : Point => (t : ℝ)) := measurable_subtype_coe
  letI : IsFiniteMeasure μ := Measure.isFiniteMeasure_map _ _
  letI : NoAtoms μ := by
    constructor
    intro z
    rw [show μ = v.measure.map _ from rfl, Measure.map_apply measurable (measurableSet_singleton _)]
    by_cases hz : z ∈ Icc (0:ℝ) 1
    · have id : (fun t : Point => (t : ℝ)) ⁻¹' {z} = {⟨z,hz⟩} := by
        ext t
        change ((t : ℝ) = z) ↔ t = ⟨z,hz⟩
        exact ⟨fun h => Subtype.ext h, fun h => congrArg Subtype.val h⟩
      rw [id,measure_singleton]
    · have id : (fun t : Point => (t : ℝ)) ⁻¹' {z} = ∅ := by
        ext t; simp only [mem_preimage,mem_singleton_iff,mem_empty_iff_false,iff_false]
        intro h; exact hz (h ▸ t.property)
      simp [id]
  have mass (p : Point) : μ.real (Icc (a : ℝ) (p : ℝ)) = v.measure.real (Icc a p) := by
    unfold Measure.real
    rw [show μ = v.measure.map _ from rfl, Measure.map_apply measurable measurableSet_Icc]
    rfl
  have cont : ContinuousOn (fun z : ℝ => μ.real (Icc (a : ℝ) z)) (Icc (a : ℝ) (b : ℝ)) := by
    have hc := intervalIntegral.continuousOn_primitive_Icc (μ := μ) (a := (a:ℝ)) (b := (b:ℝ))
      (f := fun _ => (1:ℝ)) ((integrable_const (1:ℝ)).integrableOn)
    simpa [Measure.real] using hc
  have cover := intermediate_value_Icc (show (a:ℝ) ≤ (b:ℝ) from hab) cont
  have left : μ.real (Icc (a:ℝ) (a:ℝ)) = 0 := by simp [Measure.real]
  obtain ⟨z,hz,hm⟩ := cover (show w ∈ Icc _ _ from ⟨left ▸ hw,(mass b).symm ▸ hwb⟩)
  let p : Point := ⟨z,a.property.1.trans hz.1,hz.2.trans b.property.2⟩
  exact ⟨p,hz.1,hz.2,(mass p).symm.trans hm⟩

end
end CakeCutting.PhysicalCuts
