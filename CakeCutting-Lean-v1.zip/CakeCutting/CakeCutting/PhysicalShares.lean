import CakeCutting.SharesProtocol

/-! Physical common shares on an arbitrary recorded residue. Values are normalized
by the observed total of each agent. The error bound applies to all subsets of slots. -/
namespace CakeCutting.PhysicalShares
open Finset Set MeasureTheory Components BoundaryRecords AdaptiveTrim DecisionTree RepairRounds Refinement SharesProtocol
noncomputable section
variable {n : ℕ} [NeZero n] {J : Type} [Fintype J] [DecidableEq J]

def scale (rec : Records n) (U : Bundle) (i : Fin n) : ℝ := (total (rec i) U)⁻¹

def program (k : ℕ) (rec : Records n) (U : Bundle) (w : J → ℝ) : Tree n (Result n J) :=
  iterate k (fun _ : Unit => U) (fun _ : Unit => w) rec (scale rec U)

def normalized (v : Fin n → Valuation) (U : Bundle) (i : Fin n) (b : Bundle) : ℝ :=
  (total (mass (v i)) U)⁻¹ * total (mass (v i)) b

structure Guarantees (v : Fin n → Valuation) (rec : Records n) (U : Bundle) (w : J → ℝ)
    (δ : ℝ) (o : Result n J) : Prop where
  sep : ∀ j, Separate (o.part j)
  disj : ∀ j k, j ≠ k → Disjoint (o.part j).points (o.part k).points
  cover : ∀ x, x ∈ U.points ↔ ∃ j, x ∈ (o.part j).points
  keep : Preserves v rec o.record
  known : ∀ j, Known v o.record (o.part j)
  residual : ∀ i, normalized v U i (o.part none) ≤ δ
  deficit : ∀ i, ∑ j, (w j - normalized v U i (o.part (some j))) = normalized v U i (o.part none)
  subsets : ∀ i (F : Finset J),
    (∑ j ∈ F, w j) - δ ≤ ∑ j ∈ F, normalized v U i (o.part (some j)) ∧
    (∑ j ∈ F, normalized v U i (o.part (some j))) ≤ ∑ j ∈ F, w j

theorem program_good (k : ℕ) (v : Fin n → Valuation) (rec : Records n) (U : Bundle)
    (s : Separate U) (ok : Known v rec U) (positive : ∀ i, 0 < total (rec i) U)
    (w : J → ℝ) (wn : ∀ j, 0 ≤ w j) (rows : ∑ j, w j = 1) (δ : ℝ)
    (precision : (n*Fintype.card J : ℕ)*((3/4:ℝ)^k*n) ≤ δ) :
    Good v (Guarantees v rec U w δ) (k*((n*Fintype.card J)*(3*n))) (program k rec U w) := by
  classical
  let M := fun i => total (mass (v i)) U
  let target := fun i j => w j * M i
  have recEq (i) : total (rec i) U = M i := recorded_total _ _ _ (ok i)
  have pos (i) : 0 < M i := recEq i ▸ positive i
  have eqscale (i) : scale rec U i = (M i)⁻¹ := congrArg Inv.inv (recEq i)
  have nonneg (i) : 0 ≤ scale rec U i := by rw [eqscale]; exact inv_nonneg.mpr (pos i).le
  have agg : aggregate v (scale rec U) U = n := by
    unfold aggregate
    change ∑ i, scale rec U i * M i = _
    simp [eqscale,ne_of_gt (pos _)]
  have init : Family v rec U (scale rec U) target n (fun _ : Unit => U) (fun _ : Unit => w) :=
    ⟨fun _ => s,fun a b ne => False.elim (ne (Subsingleton.elim _ _)),by simp,
      fun _ => ok,fun _ => wn,fun _ => rows,by simp [target,M],fun _ _ => agg.le⟩
  apply OracleTree.strengthen _ _ _ _ _ (iterate_good k v rec U _ _ _ nonneg target n (by positivity) init)
  intro o h
  have massNonneg (i j) : 0 ≤ total (mass (v i)) (o.part j) := by
    rw [total_eq_measure _ _ (h.sep _)]; exact measureReal_nonneg
  have upper (i j) : normalized v U i (o.part (some j)) ≤ w j := by
    calc
      _ ≤ (M i)⁻¹ * (w j * M i) := mul_le_mul_of_nonneg_left (h.upper i j) (inv_nonneg.mpr (pos i).le)
      _ = _ := by field_simp [ne_of_gt (pos i)]
  have low (i) : normalized v U i (o.part none) ≤ δ := by
    have one := Finset.single_le_sum (f:=fun a => scale rec U a * total (mass (v a)) (o.part none))
      (fun a _ => mul_nonneg (nonneg a) (massNonneg a none)) (Finset.mem_univ i)
    change scale rec U i * _ ≤ aggregate v (scale rec U) (o.part none) at one
    rw [eqscale i] at one
    exact one.trans (h.residue.trans precision)
  have defic (i) : ∑ j, (w j - normalized v U i (o.part (some j))) = normalized v U i (o.part none) := by
    letI := (v i).finite
    have cov : U.points = ⋃ j, (o.part j).points := by ext x; simpa using h.cover x
    have sum : M i = ∑ j, total (mass (v i)) (o.part j) := by
      change total (mass (v i)) U = _
      simp_rw [total_eq_measure _ _ (h.sep _)]
      rw [total_eq_measure _ _ s,cov,measureReal_iUnion_fintype (fun a b => h.disj a b) (fun _ => measurable_points _)]
    rw [Fintype.sum_option] at sum
    rw [sum_sub_distrib,rows]
    simp only [normalized,← mul_sum]
    change 1 - (M i)⁻¹ * _ = (M i)⁻¹ * _
    field_simp [ne_of_gt (pos i)]
    linarith
  refine ⟨h.sep,h.disj,h.cover,h.keep,h.know,low,defic,?_⟩
  intro i F
  have le := sum_le_sum_of_subset_of_nonneg (s:=F) (t:=univ) (subset_univ F)
    (f:=fun j => w j - normalized v U i (o.part (some j))) (fun j _ _ => sub_nonneg.mpr (upper i j))
  rw [defic,sum_sub_distrib] at le
  exact ⟨by linarith [low i],sum_le_sum (fun j _ => upper i j)⟩

theorem repair_shares (sz : Fintype.card J = n*n) (hn : 2 ≤ n) (v : Fin n → Valuation)
    (rec : Records n) (U : Bundle) (s : Separate U) (ok : Known v rec U)
    (positive : ∀ i, 0 < total (rec i) U) (w : J → ℝ) (wn : ∀ j, 0 ≤ w j)
    (rows : ∑ j, w j = 1) (α : ℝ) (floor : 1/(4*(n:ℝ)^2)^(n+1) ≤ α) :
    Good v (Guarantees v rec U w (α/2)) (rounds n*((n*(n*n))*(3*n)))
      (program (rounds n) rec U w) := by
  rw [← sz]
  apply program_good _ _ _ _ s ok positive _ wn rows
  rw [sz]
  push_cast
  calc
    _ = (n:ℝ)^4*(3/4:ℝ)^rounds n := by ring
    _ ≤ _ := RepairRounds.precision hn α floor

end
end CakeCutting.PhysicalShares
