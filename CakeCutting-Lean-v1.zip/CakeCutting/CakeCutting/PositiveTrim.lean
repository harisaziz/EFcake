import CakeCutting.CappedSquare

/-! Transfer from the capped square to strictly increasing suffix curves.
Rows are pieces; ordinary columns are agents. The supporting assignment
gives a complete order of certification beginning with whole pieces. -/
namespace CakeCutting.PositiveTrim
open Finset CakeCutting.Matching CakeCutting.Exposure
open scoped NNReal
variable {R : Type*} [Fintype R] [Nonempty R] [DecidableEq R]

/-- The positive suffix model with its slope-one continuation already
encoded. F j a t is agent a's value of keeping length t on piece j.
Physical lengths are between zero and one. -/
abbrev Values (R : Type*) := R → R → ℝ≥0 ≃o ℝ≥0

def lengths (F : Values R) (u : R → ℝ≥0) (j : R) : ℝ≥0 :=
  univ.inf' univ_nonempty (price (fun j a => (F j a).symm) (fun _ => 1) u j)

omit [DecidableEq R] in
private theorem shortest (F : Values R) (u : R → ℝ≥0) (j : R) (k : Option R) :
    lengths F u j ≤ price (fun j a => (F j a).symm) (fun _ => 1) u j k :=
  inf'_le _ (mem_univ _)

omit [DecidableEq R] in
private theorem tight_eq (F : Values R) (u : R → ℝ≥0) (j : R) (k : Option R) :
    k ∈ tight (price (fun j a => (F j a).symm) (fun _ => 1) u) j ↔
      lengths F u j = price (fun j a => (F j a).symm) (fun _ => 1) u j k := by
  constructor
  · intro h
    exact le_antisymm (shortest F u j k) (le_inf' _ _ (fun b _ => (mem_tight ..).1 h b))
  · intro h
    exact (mem_tight ..).2 (fun b => h ▸ shortest F u j b)

omit [Nonempty R] in
/-- Strict Hall gives a certifying order for any fixed perfect matching.
The rank is the position in a permutation, so all positions are distinct. -/
theorem certifying_order (G : R → Finset (Option R)) (hall : StrictHall G)
    (holder : R ≃ R) :
    ∃ rank : R ≃ Fin (Fintype.card R), ∀ j,
      none ∈ G j ∨ ∃ i, rank i < rank j ∧ some (holder i) ∈ G j := by
  classical
  let Good (S : Finset R) (r : R → ℕ) := Set.InjOn r S ∧
    (∀ j ∈ S, r j < S.card) ∧
    ∀ j ∈ S, none ∈ G j ∨ ∃ i ∈ S, r i < r j ∧ some (holder i) ∈ G j
  let rec grow (S : Finset R) (r : R → ℕ) (h : Good S r) :
      ∃ rank : R ≃ Fin (Fintype.card R), ∀ j,
        none ∈ G j ∨ ∃ i, rank i < rank j ∧ some (holder i) ∈ G j := by
    by_cases full : S = univ
    · subst S
      let rn : R → Fin (Fintype.card R) := fun i => ⟨r i, by simpa using h.2.1 i (mem_univ i)⟩
      have bij := (Fintype.bijective_iff_injective_and_card rn).2
        ⟨fun i j eq => h.1 (mem_univ _) (mem_univ _) (congrArg Fin.val eq),by simp⟩
      refine ⟨Equiv.ofBijective rn bij, fun j => ?_⟩
      rcases h.2.2 j (mem_univ _) with hn | ⟨i,_,lt,edge⟩
      · exact Or.inl hn
      · exact Or.inr ⟨i,lt,edge⟩
    · let T := (univ : Finset R) \ S
      have hT : T.Nonempty := by
        by_contra! hh
        apply full
        apply eq_univ_iff_forall.mpr
        intro i
        by_contra hn
        exact hh ⟨i,mem_sdiff.mpr ⟨mem_univ _,hn⟩⟩
      let own := T.image (fun i => some (holder i))
      have count := hall T hT
      have missed : ∃ k ∈ neighbors G T, k ∉ own := by
        by_contra! all
        have hc := card_le_card (show neighbors G T ⊆ own from all)
        have ho : own.card ≤ T.card := card_image_le
        omega
      obtain ⟨k,hk,hout⟩ := missed
      obtain ⟨j,hj,hit⟩ := mem_biUnion.mp hk
      have hjS := (mem_sdiff.mp hj).2
      have next : none ∈ G j ∨ ∃ i ∈ S, some (holder i) ∈ G j := by
        cases k with
        | none => exact Or.inl hit
        | some a =>
          let i := holder.symm a
          have hi : i ∈ S := by
            by_contra hn
            exact hout (mem_image.mpr ⟨i,mem_sdiff.mpr ⟨mem_univ _,hn⟩,
              congrArg some (holder.apply_symm_apply a)⟩)
          exact Or.inr ⟨i,hi,by simpa [i] using hit⟩
      let r' := Function.update r j S.card
      have stay (i) (hi : i ∈ S) : r' i = r i :=
        Function.update_of_ne (show i ≠ j from fun eq => hjS (eq ▸ hi)) ..
      have val : r' j = S.card := Function.update_self ..
      have smaller (i) (hi : i ∈ S) : r' i < r' j := by rw [stay i hi,val]; exact h.2.1 i hi
      have bigger := card_insert_of_notMem hjS
      have ng : Good (insert j S) r' := by
        refine ⟨?_,?_,?_⟩
        · intro a ha b hb hab
          by_cases aj : a = j
          · by_cases bj : b = j
            · exact aj.trans bj.symm
            · have hbS : b ∈ S := (mem_insert.mp hb).resolve_left bj
              exact False.elim ((smaller b hbS).ne' (aj ▸ hab))
          · have haS : a ∈ S := (mem_insert.mp ha).resolve_left aj
            by_cases bj : b = j
            · exact False.elim ((smaller a haS).ne (bj ▸ hab))
            · have hbS : b ∈ S := (mem_insert.mp hb).resolve_left bj
              exact h.1 haS hbS (by simpa only [stay _ haS,stay _ hbS] using hab)
        · intro a ha
          rcases mem_insert.mp ha with rfl | ha
          · rw [val,bigger]; omega
          · rw [stay _ ha,bigger]; exact (h.2.1 _ ha).trans (Nat.lt_succ_self _)
        · intro a ha
          rcases mem_insert.mp ha with rfl | ha
          · rcases next with hn | ⟨i,hi,edge⟩
            · exact Or.inl hn
            · exact Or.inr ⟨i,mem_insert_of_mem hi,smaller _ hi,edge⟩
          · rcases h.2.2 a ha with hn | ⟨i,hi,lt,edge⟩
            · exact Or.inl hn
            · exact Or.inr ⟨i,mem_insert_of_mem hi,by rw [stay _ hi,stay _ ha]; exact lt,edge⟩
      exact grow (insert j S) r' ng
  termination_by Fintype.card R - S.card
  decreasing_by have hh := card_le_univ (insert j S); omega
  exact grow ∅ (fun _ => 0) (by simp [Good])

/-- Certified abstract suffix allocation, including the exact output of
the median solver. Agents compare the lengths through their own curves. -/
theorem certified (F : Values R) :
    ∃ (u : R → ℝ≥0) (holder : R ≃ R) (rank : R ≃ Fin (Fintype.card R)),
      Solver.run (CappedSquare.curves (fun j a => (F j a).symm) (fun _ => 1)
        (fun _ => zero_lt_one)) none (↑(1 : ℝ≥0)) (Solver.candidate (R := R) none)
        ((Fintype.card R).factorial.log2+1) univ =
        some (CappedSquare.levels u,fun j => some (holder j)) ∧
      (∀ j, lengths F u j ≤ 1) ∧
      (∀ j, F j (holder j) (lengths F u j) = u (holder j)) ∧
      (∀ j a, F j a (lengths F u j) ≤ u a) ∧
      (∀ j, lengths F u j = 1 ∨ ∃ i, rank i < rank j ∧
        F j (holder i) (lengths F u j) = F i (holder i) (lengths F u i)) := by
  classical
  let f := fun j a => (F j a).symm
  obtain ⟨u,m,output,hex,inj,tightM,_⟩ := CappedSquare.solve f (fun _ => 1) (fun _ => zero_lt_one)
  let G := tight (price f (fun _ => 1) u)
  have mne (j) := (mem_erase.mp (tightM j)).1
  let agent := fun j => (m j).get (Option.isSome_iff_ne_none.mpr (mne j))
  have matchEq (j) : some (agent j) = m j := Option.some_get ..
  have hb : Function.Bijective agent := (Fintype.bijective_iff_injective_and_card _).2
    ⟨fun i j h => inj ((matchEq i).symm.trans ((congrArg some h).trans (matchEq j))),rfl⟩
  let holder := Equiv.ofBijective agent hb
  have tie (j i) (ht : some (holder i) ∈ G j) :
      F j (holder i) (lengths F u j) = u (holder i) := by
    have he := (tight_eq F u j (some (holder i))).1 ht
    change lengths F u j = (F j (holder i)).symm _ at he
    rw [he,OrderIso.apply_symm_apply]
  have own (j) : F j (holder j) (lengths F u j) = u (holder j) :=
    tie j j ((matchEq j).symm ▸ (mem_erase.mp (tightM j)).2)
  obtain ⟨r,hr⟩ := certifying_order G
    ((fullyExposable_iff_strictHall _ (tight_nonempty _)).1 hex) holder
  refine ⟨u,holder,r,?_,fun j => shortest F u j none,own,
    fun j a => (F j a).le_symm_apply.mp (shortest F u j (some a)),fun j => ?_⟩
  · simpa only [show (fun j => some (holder j)) = m from funext matchEq] using output
  · rcases hr j with h | ⟨i,lt,ht⟩
    · exact Or.inl ((tight_eq F u j none).1 h)
    · exact Or.inr ⟨i,lt,(tie _ _ ht).trans (own i).symm⟩

end CakeCutting.PositiveTrim
