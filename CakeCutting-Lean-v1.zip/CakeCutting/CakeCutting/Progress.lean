import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Linarith

/-! The domination inequalities and finite potential in the outer loop. -/

namespace CakeCutting.Progress

open Finset

/-- Numerical form of `lem:follow`. The two bounds on final bundles are the
ones supplied by envy-freeness, inclusion and additivity in the manuscript. -/
theorem follows_label (own oldOther newOwn newOther residue residue' : ℝ)
    (hdom : residue ≤ own - oldOther) (hself : own ≤ newOwn)
    (hother : newOther ≤ oldOther + (residue - residue')) :
    residue' ≤ newOwn - newOther := by linarith

/-- Arithmetic creating a previously absent domination in `lem:progress`.
All values and advantages are from the witnessing agent's perspective. -/
theorem new_domination (n : ℕ) (hn : 2 ≤ n) (unit oldAdv finalAdv residue' : ℝ)
    (hu : 0 ≤ unit) (hadv : (4 * (n : ℝ) ^ 2 - 1) * unit ≤ oldAdv)
    (hloss : oldAdv - 2 * n * unit ≤ finalAdv)
    (hres : residue' ≤ 2 * (n : ℝ) ^ 2 * unit) : residue' ≤ finalAdv := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hc : (2 : ℝ) * n ^ 2 ≤ 4 * (n : ℝ) ^ 2 - 1 - 2 * n := by
    nlinarith [sq_nonneg ((n : ℝ) - 2)]
  have := mul_le_mul_of_nonneg_right hc hu
  linarith

/-- Reindexing old labels by their new holders preserves their count. One
strictly new domination increases the total potential, including self-pairs. -/
theorem count_increases {A : Type*} [DecidableEq A]
    (old new : Finset (A × A)) (holder : A ≃ A) (a b : A)
    (preserves : ∀ i j, (i, j) ∈ old → (i, holder j) ∈ new)
    (habsent : (a, b) ∉ old) (hpresent : (a, holder b) ∈ new) :
    old.card < new.card := by
  classical
  let move : A × A → A × A := fun p => (p.1, holder p.2)
  have hinj : Function.Injective move := by
    intro p q hpq
    change (p.1, holder p.2) = (q.1, holder q.2) at hpq
    exact Prod.ext (Prod.mk.inj hpq).1 (holder.injective (Prod.mk.inj hpq).2)
  have hsub : old.image move ⊆ new := by
    intro k hk
    obtain ⟨⟨i,j⟩, hij, rfl⟩ := mem_image.mp hk
    exact preserves i j hij
  have hmissing : move (a,b) ∉ old.image move := by
    intro h
    obtain ⟨p, hp, hpa⟩ := mem_image.mp h
    exact habsent (hinj hpa ▸ hp)
  have hs : old.image move ⊆ new.erase (move (a,b)) := by
    intro k hk
    exact mem_erase.mpr ⟨fun h => hmissing (h ▸ hk), hsub hk⟩
  have hc := card_le_card hs
  rw [card_image_of_injective _ hinj] at hc
  have he := card_erase_add_one (s := new) (a := move (a,b)) hpresent
  omega

end CakeCutting.Progress
