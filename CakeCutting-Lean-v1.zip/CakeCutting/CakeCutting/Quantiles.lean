import CakeCutting.Median

/-! Quantiles of finite multisets represented by one entry per candidate.
Values may repeat. Grid points are the observed values at the ceiling ranks
of the paper, characterized by their empirical cumulative counts. -/

namespace CakeCutting.Quantiles

open Finset
variable {A V : Type*} [Fintype A] [Nonempty A] [LinearOrder V]

def below (u : A → V) (v : V) := univ.filter (fun a => u a ≤ v)

omit [Nonempty A] in
private theorem below_mono (u : A → V) {s t : V} (h : s ≤ t) : below u s ⊆ below u t :=
  fun _ ha => mem_filter.mpr ⟨mem_univ _, (mem_filter.mp ha).2.trans h⟩

def eligible (u : A → V) (g h : ℕ) : Finset V :=
  (univ.image u).filter (fun v => h * Fintype.card A ≤ g * (below u v).card)

private theorem eligible_nonempty (u : A → V) {g h : ℕ} (hh : h ≤ g) :
    (eligible u g h).Nonempty := by
  classical
  obtain ⟨a, _, ha⟩ := (univ : Finset A).exists_max_image u univ_nonempty
  have all : below u (u a) = univ :=
    eq_univ_iff_forall.mpr (fun i => mem_filter.mpr ⟨mem_univ _, ha i (mem_univ _)⟩)
  exact ⟨u a, mem_filter.mpr ⟨mem_image_of_mem _ (mem_univ a),
    by simpa [all] using Nat.mul_le_mul_right (Fintype.card A) hh⟩⟩

/-- The least observed value reaching fraction h/g of the pool. -/
def quantile (u : A → V) (g h : ℕ) (hh : h ≤ g) : V :=
  (eligible u g h).min' (eligible_nonempty u hh)

theorem quantile_observed (u : A → V) (g h : ℕ) (hh : h ≤ g) :
    ∃ a, u a = quantile u g h hh := by
  obtain ⟨a, _, ha⟩ := mem_image.mp (mem_filter.mp
    (min'_mem (eligible u g h) (eligible_nonempty u hh))).1
  exact ⟨a, ha⟩

theorem quantile_rank (u : A → V) (g h : ℕ) (hh : h ≤ g) :
    h * Fintype.card A ≤ g * (below u (quantile u g h hh)).card :=
  (mem_filter.mp (min'_mem (eligible u g h) (eligible_nonempty u hh))).2

theorem quantile_le (u : A → V) {g h : ℕ} (hh : h ≤ g) (hg : 0 < h) (t : V)
    (hit : h * Fintype.card A ≤ g * (below u t).card) : quantile u g h hh ≤ t := by
  classical
  have hn : (below u t).Nonempty := by
    apply card_pos.mp
    by_contra! hz
    rw [show (below u t).card = 0 by omega, Nat.mul_zero] at hit
    exact (Nat.mul_pos hg Fintype.card_pos).not_ge hit
  obtain ⟨a, ha, hmax⟩ := (below u t).exists_max_image u hn
  have sub : below u t ⊆ below u (u a) :=
    fun k hk => mem_filter.mpr ⟨mem_univ _, hmax k hk⟩
  apply le_trans _ (mem_filter.mp ha).2
  exact min'_le (eligible u g h) (u a) (mem_filter.mpr ⟨mem_image_of_mem _ (mem_univ _),
    hit.trans (Nat.mul_le_mul_left _ (card_le_card sub))⟩)

def grid (u : A → V) (g : ℕ) := (univ : Finset (Fin g)).image
  (fun k => quantile u g (k.val+1) k.isLt)

theorem grid_card (u : A → V) (g : ℕ) : (grid u g).card ≤ g := by
  simpa [grid] using (card_image_le (s := (univ : Finset (Fin g)))
    (f := fun k => quantile u g (k.val+1) k.isLt))

private theorem upper_nonempty (u : A → V) (g : ℕ) (hg : 0 < g) (a : A) :
    ((grid u g).filter (fun v => u a ≤ v)).Nonempty := by
  classical
  let k : Fin g := ⟨g-1, by omega⟩
  have last : k.val + 1 = g := by dsimp [k]; omega
  let v := quantile u g (k.val+1) k.isLt
  have rank := quantile_rank u g (k.val+1) k.isLt
  change (k.val + 1) * Fintype.card A ≤ g * (below u v).card at rank
  rw [last] at rank
  have full : below u v = univ := by
    apply eq_univ_of_card
    apply le_antisymm (card_le_univ _)
    exact Nat.le_of_mul_le_mul_left rank hg
  have ha : a ∈ below u v := full.symm ▸ mem_univ _
  exact ⟨v, mem_filter.mpr ⟨mem_image_of_mem _ (mem_univ k), (mem_filter.mp ha).2⟩⟩

def roundUp (u : A → V) (g : ℕ) (hg : 0 < g) (a : A) : V :=
  ((grid u g).filter (fun v => u a ≤ v)).min' (upper_nonempty u g hg a)

theorem roundUp_spec (u : A → V) (g : ℕ) (hg : 0 < g) (a : A) :
    roundUp u g hg a ∈ grid u g ∧ u a ≤ roundUp u g hg a :=
  mem_filter.mp (min'_mem _ _)

def crossings (u : A → V) (g : ℕ) (hg : 0 < g) (t : V) : Finset A :=
  (below u t).filter (fun a => t < roundUp u g hg a)

/-- At any threshold fewer than P/g candidates cross it, including ties. -/
theorem crossing_bound (u : A → V) (g : ℕ) (hg : 0 < g) (t : V) :
    g * (crossings u g hg t).card < Fintype.card A := by
  classical
  let P := Fintype.card A
  let d := (below u t).card
  let h := g*d/P
  have hp : 0 < P := Fintype.card_pos
  have hr : h*P ≤ g*d := Nat.div_mul_le_self _ _
  have rem : g*d < (h+1)*P := (Nat.div_lt_iff_lt_mul hp).mp (Nat.lt_succ_self h)
  have hle : h ≤ g := (Nat.le_of_mul_le_mul_right (hr.trans
    (Nat.mul_le_mul_left _ (card_le_univ _))) hp)
  by_cases hz : h = 0
  · have leD : (crossings u g hg t).card ≤ d := card_le_card (filter_subset ..)
    exact (Nat.mul_le_mul_left _ leD).trans_lt (by simpa [hz] using rem)
  · let k : Fin g := ⟨h-1, lt_of_lt_of_le (Nat.sub_lt (Nat.pos_of_ne_zero hz) (by decide)) hle⟩
    let v := quantile u g h hle
    have hv : v ≤ t := quantile_le u hle (Nat.pos_of_ne_zero hz) t hr
    have inGrid : v ∈ grid u g := by
      have e : k.val + 1 = h := by exact Nat.sub_add_cancel (Nat.pos_of_ne_zero hz)
      exact mem_image.mpr ⟨k, mem_univ _, by simp [e, v]⟩
    have disc : crossings u g hg t ⊆ below u t \ below u v := by
      intro a ha
      obtain ⟨ha1, ha2⟩ := mem_filter.mp ha
      exact mem_sdiff.mpr ⟨ha1, fun hav =>
        ha2.not_ge ((min'_le _ _ (mem_filter.mpr ⟨inGrid, (mem_filter.mp hav).2⟩)).trans hv)⟩
    have split := card_sdiff_add_card_eq_card (below_mono u hv)
    have hc := card_le_card disc
    have total : (crossings u g hg t).card + (below u v).card ≤ d := by dsimp [d]; omega
    have scaled := Nat.mul_le_mul_left g total
    rw [Nat.mul_add] at scaled
    have low : h*P ≤ g*(below u v).card := quantile_rank u g h hle
    rw [Nat.add_mul, Nat.one_mul] at rem
    omega

/-- The actual lower median has both properties needed by the matching test
and the subsequent filter. -/
theorem lowerMedian (u : A → V) (t : V)
    (h : Fintype.card A ≤ 2 * (below u t).card) :
    quantile u 2 1 (by decide) ≤ t ∧
      Fintype.card A ≤ 2 * (below u (quantile u 2 1 (by decide))).card := by
  constructor
  · exact quantile_le u (by decide) (by decide) t (by simpa using h)
  · simpa using quantile_rank u 2 1 (by decide)

/-- All grid columns and rows of one round together incur at most P/8
crossings at the resolution in the manuscript. -/
theorem round_error_budget {K : Type*} [Fintype K] (q : ℕ)
    (hK : Fintype.card K = 2*q+1) (u : K → A → V) (t : K → V) :
    8 * (∑ k, (crossings (u k) (8*(2*q+1)) (by omega) (t k)).card) ≤ Fintype.card A := by
  let g := 8*(2*q+1)
  let c := fun k => (crossings (u k) g (by dsimp [g]; omega) (t k)).card
  have hsum : g * (∑ k, c k) ≤ (2*q+1) * Fintype.card A := by
    rw [mul_sum]
    simpa [hK] using (sum_le_sum (s := (univ : Finset K)) (f := fun k => g*c k)
      (g := fun _ => Fintype.card A)
      (fun k _ => (crossing_bound (u k) g (by dsimp [g]; omega) (t k)).le))
  change 8*(∑ k, c k) ≤ Fintype.card A
  have hcancel : (2*q+1)*(8*∑ k, c k) ≤ (2*q+1)*Fintype.card A := by
    simpa only [g, Nat.mul_left_comm, Nat.mul_assoc] using hsum
  exact Nat.le_of_mul_le_mul_left hcancel (by omega)

end CakeCutting.Quantiles
