import CakeCutting.Transcript
import Mathlib.Tactic.FieldSimp

/-! Realizing finitely many consistent forward and inverse answers by strict
continuous curves, with unit slope beyond the whole-piece endpoint. -/
namespace CakeCutting.Transcript
open Finset
open scoped NNReal

private noncomputable def splice (e : ℝ ≃o ℝ) (l a y : ℝ) (x : ℝ) : ℝ :=
  if x ≤ l then e x else if x ≤ a then
    e l + (x-l)*((y-e l)/(a-l)) else y + (x-a)

private theorem splice_iso (e : ℝ ≃o ℝ) (l a y : ℝ) (ha : l < a) (hy : e l < y) :
    ∃ d : ℝ ≃o ℝ, (∀ x ≤ l, d x = e x) ∧ d a = y ∧ ∀ x ≥ a, d x = y + (x-a) := by
  let k := (y-e l)/(a-l)
  have den : a-l ≠ 0 := sub_ne_zero.mpr ha.ne'
  have kp : 0 < k := div_pos (sub_pos.mpr hy) (sub_pos.mpr ha)
  have edge : e l + (a-l)*k = y := by dsimp [k]; field_simp; ring
  let f := splice e l a y
  have h1 (x) (h : x ≤ l) : f x = e x := if_pos h
  have h2 (x) (hl : l ≤ x) (hx : x ≤ a) : f x = e l + (x-l)*k := by
    rcases hl.eq_or_lt with rfl | lt
    · simp [f,splice]
    · simp [f,splice,lt.not_ge,hx,k]
  have h3 (x) (hx : a ≤ x) : f x = y + (x-a) := by
    rcases hx.eq_or_lt with rfl | lt
    · simpa using (h2 _ ha.le le_rfl).trans edge
    · simp [f,splice,lt.not_ge,(ha.trans lt).not_ge]
  have mono : StrictMono f := by
    intro x z lt
    by_cases zl : z ≤ l
    · rw [h1 z zl,h1 x (lt.le.trans zl)]; exact e.strictMono lt
    by_cases xa : a ≤ x
    · rw [h3 x xa,h3 z (xa.trans lt.le)]; linarith
    by_cases xl : x ≤ l
    · rw [h1 x xl]
      have ex := e.monotone xl
      by_cases za : z ≤ a
      · rw [h2 z (le_of_not_ge zl) za]
        have := mul_pos (sub_pos.mpr (lt_of_not_ge zl)) kp
        linarith
      · rw [h3 z (le_of_not_ge za)]; linarith
    · rw [h2 x (le_of_not_ge xl) (le_of_not_ge xa)]
      by_cases za : z ≤ a
      · rw [h2 z (le_of_not_ge zl) za]
        exact add_lt_add_left (mul_lt_mul_of_pos_right (sub_lt_sub_right lt _) kp) _
      · rw [h3 z (le_of_not_ge za)]
        have v := mul_lt_mul_of_pos_right (sub_lt_sub_right (lt_of_not_ge xa) l) kp
        linarith
  have onto : Function.Surjective f := by
    intro t
    by_cases tl : t ≤ e l
    · exact ⟨e.symm t,(h1 _ (e.symm_apply_le.mpr tl)).trans (e.apply_symm_apply _)⟩
    by_cases ty : y ≤ t
    · exact ⟨a+(t-y),by rw [h3 _ (by linarith)]; ring⟩
    let x := l+(t-e l)/k
    have hx : l ≤ x := by dsimp [x]; have := div_nonneg (sub_nonneg.mpr (le_of_not_ge tl)) kp.le; linarith
    have xa : x ≤ a := by
      have hdiv : (t-e l)/k ≤ a-l := (div_le_iff₀ kp).mpr (by linarith)
      dsimp [x]; linarith
    refine ⟨x,?_⟩
    rw [h2 _ hx xa]; dsimp [x]; rw [add_sub_cancel_left,div_mul_cancel₀ _ kp.ne']; ring
  exact ⟨StrictMono.orderIsoOfSurjective f mono onto,h1,(h2 a ha.le le_rfl).trans edge,h3⟩

/-- Extend a finite strict graph on nonnegative real keys. The zero key is
fixed, and the tail from the largest key has prescribed slope one. -/
private theorem extend_real (S : Finset ℝ) (y : ℝ → ℝ) (zero : y 0 = 0)
    (pos : ∀ x ∈ S, 0 < x) (strict : StrictMonoOn y (insert 0 S : Finset ℝ)) :
    ∃ e : ℝ ≃o ℝ, e 0 = 0 ∧ (∀ x ∈ S, e x = y x) ∧
      ∀ x ≥ (insert 0 S).max' (by simp), e x = y ((insert 0 S).max' (by simp)) +
        (x - (insert 0 S).max' (by simp)) := by
  induction S using Finset.induction_on_max with
  | h0 => exact ⟨OrderIso.refl _,rfl,by simp,by simp [zero]⟩
  | step a S greater ih =>
    let L := insert 0 S
    have ne : L.Nonempty := ⟨0,mem_insert_self ..⟩
    let l := L.max' ne
    have hl : l ∈ L := max'_mem .. 
    have subs : L ⊆ insert 0 (insert a S) := by intro x hx; simp only [L,mem_insert] at hx ⊢; tauto
    have ha : l < a := by
      rcases mem_insert.mp hl with h | h
      · rw [h]; exact pos a (mem_insert_self ..)
      · exact greater l h
    obtain ⟨e,origin,old,_⟩ := ih (fun x hx => pos x (mem_insert_of_mem hx)) (strict.mono subs)
    have el : e l = y l := by
      rcases mem_insert.mp hl with h | h
      · rw [h,origin,zero]
      · exact old l h
    have ya := strict (subs hl) (mem_insert_of_mem (mem_insert_self a S)) ha
    obtain ⟨d,stay,new,tail⟩ := splice_iso e l a (y a) ha (el ▸ ya)
    have peak : (insert 0 (insert a S)).max' (by simp) = a := by
      apply le_antisymm
      · apply max'_le
        intro x hx
        rcases mem_insert.mp hx with rfl | hx
        · exact (pos a (mem_insert_self ..)).le
        · rcases mem_insert.mp hx with rfl | hx
          · rfl
          · exact (greater x hx).le
      · exact le_max' _ _ (mem_insert_of_mem (mem_insert_self ..))
    refine ⟨d,(stay _ (le_max' _ _ (mem_insert_self ..))).trans origin,?_,by simpa only [peak] using tail⟩
    intro x hx
    rcases mem_insert.mp hx with rfl | hx
    · exact new
    · exact (stay _ (le_max' _ _ (mem_insert_of_mem hx : x ∈ L))).trans (old _ hx)

/-- A single continuous order automorphism of the nonnegative reals
realizes all registered answers and agrees with the slope-one continuation
after length one. Its inverse therefore realizes the inverse answers too. -/
theorem realize_curve (S : Finset ℝ≥0) (y : ℝ≥0 → ℝ≥0) (origin : y 0 = 0)
    (h0 : 0 ∈ S) (h1 : 1 ∈ S) (bounded : ∀ x ∈ S, x ≤ 1)
    (strict : StrictMonoOn y S) :
    ∃ F : ℝ≥0 ≃o ℝ≥0, Continuous F ∧ (∀ x ∈ S, F x = y x ∧ F.symm (y x) = x) ∧
      ∀ x ≥ 1, (F x : ℝ) = y 1 + ((x:ℝ)-1) := by
  classical
  let T := (S.erase 0).image (fun x : ℝ≥0 => (x:ℝ))
  let Y := fun x : ℝ => (y x.toNNReal : ℝ)
  have yo : Y 0 = 0 := by simp [Y,origin]
  have keys : insert 0 T = S.image (fun x : ℝ≥0 => (x:ℝ)) := by
    rw [← insert_erase h0, image_insert]; simp [T]
  have st : StrictMonoOn Y (insert 0 T : Finset ℝ) := by
    rw [keys]
    intro a ha b hb ab
    change a ∈ S.image (fun x : ℝ≥0 => (x:ℝ)) at ha
    change b ∈ S.image (fun x : ℝ≥0 => (x:ℝ)) at hb
    obtain ⟨aa,haa,rfl⟩ := mem_image.mp ha
    obtain ⟨bb,hbb,rfl⟩ := mem_image.mp hb
    have h := strict haa hbb (show aa < bb from ab)
    change (y (aa : ℝ).toNNReal : ℝ) < (y (bb : ℝ).toNNReal : ℝ)
    simpa using (show (y aa : ℝ) < (y bb : ℝ) from h)
  obtain ⟨e,ez,table,tail⟩ := extend_real T Y yo (by
    intro a ha
    obtain ⟨b,hb,rfl⟩ := mem_image.mp ha
    exact (zero_lt_iff.mpr (mem_erase.mp hb).1 : 0 < b)) st
  have nonneg (x : ℝ≥0) : 0 ≤ e (x:ℝ) := ez ▸ e.monotone x.property
  let f : ℝ≥0 → ℝ≥0 := fun x : ℝ≥0 => (⟨e (x:ℝ), nonneg x⟩ : ℝ≥0)
  have mono : StrictMono f := fun _ _ h => e.strictMono h
  have onto : Function.Surjective f := by
    intro z
    have h : 0 ≤ e.symm (z:ℝ) := e.le_symm_apply.mpr (by rw [ez]; exact z.property)
    exact ⟨⟨_,h⟩,Subtype.ext (e.apply_symm_apply _)⟩
  let F : ℝ≥0 ≃o ℝ≥0 := StrictMono.orderIsoOfSurjective f mono onto
  have matchKey (x : ℝ≥0) (hx : x ∈ S) : F x = y x := by
    apply Subtype.ext
    change e (x:ℝ) = (y x:ℝ)
    by_cases eq : x = 0
    · simp [eq,ez,origin]
    · simpa [Y] using table _ (mem_image.mpr ⟨x,mem_erase.mpr ⟨eq,hx⟩,rfl⟩ : (x:ℝ) ∈ T)
  have peak : (insert 0 T).max' (by simp) = 1 := by
    apply le_antisymm
    · apply max'_le
      intro x hx
      obtain ⟨b,hb,rfl⟩ := mem_image.mp (keys ▸ hx)
      exact bounded b hb
    · apply le_max'
      rw [keys]
      exact mem_image.mpr ⟨1,h1,rfl⟩
  refine ⟨F,F.continuous,fun x hx => ⟨matchKey x hx,(congrArg F.symm (matchKey x hx).symm).trans (F.symm_apply_apply x)⟩,?_⟩
  intro x hx
  simpa [peak,Y] using tail (x:ℝ) (by simpa [peak] using hx)

end CakeCutting.Transcript
