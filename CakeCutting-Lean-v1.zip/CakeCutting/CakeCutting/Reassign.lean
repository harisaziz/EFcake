import CakeCutting.Core
import Mathlib.GroupTheory.Perm.List
import Mathlib.Data.List.Chain

/-! Finite paths, threshold crossing, and cycle rotation in Reassign.
The graph hypothesis expresses the absence of a proper dominated group. -/
namespace CakeCutting.Reassign
open Finset

variable {R : Type*} [Fintype R] [DecidableEq R]

omit [DecidableEq R] in
theorem paths (arc : R → R → Prop)
    (escape : ∀ H : Finset R, H.Nonempty → H ≠ univ → ∃ a ∉ H, ∃ b ∈ H, arc a b)
    (r h : R) : ∃ l : List R, l.head? = some r ∧ l.getLast? = some h ∧ l.Nodup ∧ l.IsChain arc := by
  classical
  let Reach (S : Finset R) (i : R) := ∃ l : List R, l.head? = some r ∧ l.getLast? = some i ∧
    l.Nodup ∧ l.IsChain arc ∧ ∀ j ∈ l, j ∈ S
  let rec grow (S : Finset R) (has : r ∈ S) (ok : ∀ i ∈ S, Reach S i) : Reach univ h := by
    by_cases full : S = univ
    · subst S; exact ok h (mem_univ _)
    · let H := (univ : Finset R) \ S
      have ne : H.Nonempty := by
        by_contra! empty
        apply full
        apply eq_univ_iff_forall.mpr
        intro x
        by_contra hx
        exact empty ⟨x,mem_sdiff.mpr ⟨mem_univ _,hx⟩⟩
      have proper : H ≠ univ := by
        intro eq
        have : r ∈ H := eq ▸ mem_univ r
        exact (mem_sdiff.mp this).2 has
      obtain ⟨a,ha,b,hb,e⟩ := escape H ne proper
      have aIn : a ∈ S := by simpa [H] using ha
      have fresh := (mem_sdiff.mp hb).2
      obtain ⟨l,lr,la,nd,ch,inside⟩ := ok a aIn
      have nonempty : l ≠ [] := by intro eq; simp [eq] at lr
      have bn : b ∉ l := fun hit => fresh (inside b hit)
      have path : Reach (insert b S) b := by
        refine ⟨l ++ [b],?_,by simp,?_,?_,?_⟩
        · rw [List.head?_append_of_ne_nil l nonempty]; exact lr
        · simp [List.nodup_append',nd,bn]
        · apply ch.append (.singleton _)
          simp [la,e]
        · intro j hj
          rcases List.mem_append.mp hj with old | new
          · exact mem_insert_of_mem (inside j old)
          · simpa using (List.mem_singleton.mp new ▸ mem_insert_self b S : j ∈ insert b S)
      exact grow (insert b S) (mem_insert_of_mem has) (by
        intro j hj
        rcases mem_insert.mp hj with rfl | old
        · exact path
        · obtain ⟨p,f,z,n,c,inS⟩ := ok j old
          exact ⟨p,f,z,n,c,fun k hk => mem_insert_of_mem (inS k hk)⟩)
  termination_by Fintype.card R - S.card
  decreasing_by
    classical
    have := card_insert_of_notMem fresh
    have := card_le_univ (insert b S)
    omega
  obtain ⟨p,f,z,nd,ch,_⟩ := grow {r} (by simp) (by
    intro i hi
    have : i = r := mem_singleton.mp hi
    subst i; exact ⟨[r],rfl,rfl,by simp,.singleton _,by simp⟩)
  exact ⟨p,f,z,nd,ch⟩

omit [Fintype R] in
/-- Turn a simple return path into the required rotation. Every move except
the closing one follows an arc, and agents outside the path keep their label. -/
theorem rotate (arc : R → R → Prop) (h b : R) (l : List R)
    (start : l.head? = some h) (stop : l.getLast? = some b) (nd : l.Nodup) (chain : l.IsChain arc) :
    ∃ π : Equiv.Perm R, π b = h ∧ ∀ i, π i = i ∨ arc i (π i) ∨ i = b := by
  classical
  cases l with
  | nil => simp at start
  | cons c cs =>
    have eq : c = h := by simpa using start
    subst c
    let l := h::cs
    have last : l.getLast (by simp [l]) = b := by simpa [l,List.getLast?_eq_getLast_of_ne_nil] using stop
    exact ⟨l.formPerm,last ▸ List.formPerm_apply_getLast h cs,by
      intro i
      by_cases mem : i ∈ l
      · obtain ⟨k,hk,rfl⟩ := List.getElem_of_mem mem
        by_cases next : k+1 < l.length
        · exact Or.inr (Or.inl (by rw [List.formPerm_apply_lt_getElem _ nd _ next]; exact chain.getElem k next))
        · apply Or.inr; apply Or.inr
          have eqk : k = cs.length := by change k < cs.length + 1 at hk; change ¬ k + 1 < cs.length + 1 at next; omega
          subst k; rw [show l[cs.length] = l.getLast (by simp [l]) by exact List.getElem_cons_length rfl]; exact last
      · exact Or.inl (List.formPerm_apply_of_notMem mem)⟩

/-- The first threshold met on the outward path gives a factor of 1/t
between the new advantage at the preceding agent and the allowed loss. -/
theorem crossing (arc : R → R → Prop) (gap : R → ℝ) (t : ℝ) (ht : 0 < t) (ht1 : t < 1)
    (r h : R) (initial : t < gap r) (final : gap h = 0) (l : List R)
    (start : l.head? = some r) (stop : l.getLast? = some h) (nd : l.Nodup) (chain : l.IsChain arc) :
    ∃ a b α, arc a b ∧ t^(Fintype.card R) ≤ α ∧ α ≤ t^2 ∧ gap b ≤ α ∧ α/t ≤ gap a := by
  cases l with
  | nil => simp at start
  | cons c cs =>
    have eq : c = r := by simpa using start
    subst c
    let l := r::cs
    let hit := fun k : ℕ => ∃ hk : k < l.length, gap l[k] ≤ t^(k+1)
    have last : l[cs.length]'(by simp [l]) = h := by
      exact (List.getElem_cons_length rfl).trans (by simpa [l,List.getLast?_eq_getLast_of_ne_nil] using stop)
    have yes : ∃ k, hit k := ⟨cs.length,by
      refine ⟨by simp [l],?_⟩
      rw [last,final]; exact pow_nonneg ht.le _⟩
    let k := Nat.find yes
    obtain ⟨hk,below⟩ := Nat.find_spec yes
    have above (j : ℕ) (lt : j < k) (hj : j < l.length) : t^(j+1) < gap l[j] := by
      by_contra! q
      exact (Nat.find_min yes lt) ⟨hj,q⟩
    have kpos : 0 < k := by
      by_contra! nz
      have e : Nat.find yes = 0 := by change k = 0; omega
      obtain ⟨hh,q⟩ := Nat.find_spec yes
      simp only [e,l,List.getElem_cons_zero,Nat.zero_add,pow_one] at q
      exact initial.not_ge q
    let j := k-1
    have sj : j+1 = k := by dsimp [j]; omega
    have next : j+1 < l.length := sj ▸ hk
    have bound : l.length ≤ Fintype.card R := by
      rw [← List.toFinset_card_of_nodup nd]; exact card_le_univ _
    refine ⟨l[j],l[k],t^(k+1),?_,?_,?_,below,?_⟩
    · simpa only [sj] using chain.getElem j next
    · apply pow_le_pow_of_le_one ht.le ht1.le; omega
    · apply pow_le_pow_of_le_one ht.le ht1.le; omega
    · rw [pow_succ,mul_div_cancel_right₀ _ ht.ne',← sj]
      exact (above j (by omega) (by omega)).le

/-- Both branches of Reassign select an arc, a permutation, and a
tolerance. The parameter t is the reciprocal of the manuscript's K. -/
theorem selection (arc : R → R → Prop)
    (escape : ∀ H : Finset R, H.Nonempty → H ≠ univ → ∃ a ∉ H, ∃ b ∈ H, arc a b)
    (gap : R → R → ℝ) (diag : ∀ i, gap i i = 0)
    (t : ℝ) (ht : 0 < t) (ht1 : t < 1) (hn : 2 ≤ Fintype.card R)
    (r h : R) (cutter : t < gap r h) :
    ∃ (a b : R) (π : Equiv.Perm R) (α : ℝ), arc a b ∧
      t^(Fintype.card R+1) ≤ α ∧ α ≤ t^2 ∧
      (∀ i, gap i (π i) ≤ α) ∧ α/t ≤ gap a (π b) := by
  classical
  let N := Fintype.card R
  by_cases large : ∃ a b, arc a b ∧ t^N ≤ gap a b
  · obtain ⟨a,b,e,ab⟩ := large
    let α := min (t^2) (gap a b*t)
    have floor : t^(N+1) ≤ α := le_min
      (pow_le_pow_of_le_one ht.le ht1.le (by dsimp [N]; omega))
      (by rw [pow_succ]; exact mul_le_mul_of_nonneg_right ab ht.le)
    refine ⟨a,b,Equiv.refl _,α,e,floor,min_le_left ..,?_,?_⟩
    · intro i; change gap i i ≤ α
      rw [diag]; exact (pow_nonneg ht.le _).trans floor
    · exact (div_le_iff₀ ht).mpr (min_le_right ..)
  · obtain ⟨l,start,stop,nd,chain⟩ := paths arc escape r h
    obtain ⟨a,b,α,ab,lower,upper,close,far⟩ :=
      crossing arc (fun i => gap i h) t ht ht1 r h cutter (diag h) l start stop nd chain
    obtain ⟨p,first,last,nd',ch⟩ := paths arc escape h b
    obtain ⟨π,pb,moves⟩ := rotate arc h b p first last nd' ch
    refine ⟨a,b,π,α,ab,(pow_le_pow_of_le_one ht.le ht1.le (Nat.le_succ _)).trans lower,upper,?_,pb ▸ far⟩
    intro i
    rcases moves i with same | graph | fixed
    · rw [same,diag]; exact (pow_nonneg ht.le _).trans lower
    · have small : gap i (π i) < t^N := lt_of_not_ge (fun big => large ⟨i,π i,graph,big⟩)
      exact small.le.trans lower
    · subst i; rwa [pb]

omit [Fintype R] [DecidableEq R] in
/-- Translate the normalized permutation losses into the two value
inequalities required of the bundles passed to Repair. -/
theorem value_bounds (X Y : R → R → ℝ) (res : R → ℝ) (hres : ∀ i, 0 < res i)
    (ex : ∀ i j, X i j ≤ X i i) (ey : ∀ i j, Y i j ≤ Y i i)
    (π : Equiv.Perm R) (a b : R) (α K : ℝ)
    (loss : ∀ i, (Y i i-Y i (π i))/res i ≤ α)
    (gain : K*α ≤ (Y a a-Y a (π b))/res a) :
    (∀ i j, X i j + Y i (π j) ≤ X i i + Y i (π i) + α*res i) ∧
    (K-1)*α*res a ≤ (X a a + Y a (π a)) - (X a b + Y a (π b)) := by
  constructor
  · intro i j
    have := (div_le_iff₀ (hres i)).mp (loss i)
    linarith [ex i j,ey i (π j)]
  · have := (le_div_iff₀ (hres a)).mp gain
    have := (div_le_iff₀ (hres a)).mp (loss a)
    linarith [ex a b]

end CakeCutting.Reassign
