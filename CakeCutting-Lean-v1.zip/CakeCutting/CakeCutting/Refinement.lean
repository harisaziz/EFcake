import CakeCutting.RepairRounds

/-! One sparse refinement round. Only split cells incur a query and each
selected cell adds one new index. The program carries physical interval
records across the round. -/
namespace CakeCutting.Refinement
open Finset Components DecisionTree AdaptiveTrim BoundaryRecords RepairRounds MeasureTheory
noncomputable section
variable {n : ℕ} [NeZero n] {E J : Type} [Fintype E] [DecidableEq E] [Fintype J] [DecidableEq J]

def mixed (p : E → J → ℝ) := univ.filter (fun e => 1 < (univ.filter (fun j => 0 < p e j)).card)
def Thin (v : Fin n → E → ℝ) (p z : E → J → ℝ) :=
  (∀ e j, 0 ≤ z e j) ∧ (∀ e j, 0 < z e j → 0 < p e j) ∧ (∀ e, ∑ j, z e j = 1) ∧
  (∀ a j, ∑ e, z e j*v a e = ∑ e, p e j*v a e) ∧ (mixed z).card ≤ n*Fintype.card J

def sparse (v : Fin n → E → ℝ) (p : E → J → ℝ) : E → J → ℝ := by
  classical
  exact if ex : ∃ z, Thin v p z then Classical.choose ex else p

omit [NeZero n] [DecidableEq E] in
theorem sparse_ok (v : Fin n → E → ℝ) (p : E → J → ℝ) (hp : ∀ e j, 0 ≤ p e j) (row : ∀ e, ∑ j, p e j = 1) :
    Thin v p (sparse v p) := by
  have ex : ∃ z, Thin v p z := by simpa [Thin,mixed] using CommonShares.sparse_cells v p hp row
  simpa only [sparse,dif_pos ex] using Classical.choose_spec ex

omit [DecidableEq E] [DecidableEq J] in
theorem mixed_mono {p z : E → J → ℝ} (sub : ∀ e j, 0 < z e j → 0 < p e j) : mixed z ⊆ mixed p := by
  intro e he
  apply mem_filter.mpr
  refine ⟨mem_univ _, (mem_filter.mp he).2.trans_le (card_le_card ?_)⟩
  intro j hj; exact mem_filter.mpr ⟨mem_univ _,sub _ _ (mem_filter.mp hj).2⟩

structure Cuts (n : ℕ) (E : Type) where
  l : E → Bundle
  r : E → Bundle
  record : Records n

def many (cells : E → Bundle) (rec : Records n) (scale : Fin n → ℝ) :
    List E → Tree n (Cuts n E)
  | [] => .ret ⟨cells,fun _ => [],rec⟩
  | e::es => bind (RepairRounds.split (cells e) rec scale) fun cut =>
      bind (many cells cut.record scale es) fun z =>
        .ret ⟨Function.update z.l e cut.left,Function.update z.r e cut.right,z.record⟩

structure Slice (v : Fin n → Valuation) (s : Bundle) (rec : Records n) (scale : Fin n → ℝ)
    (l r : Bundle) : Prop where
  cover : l.points ∪ r.points = s.points
  disj : Disjoint l.points r.points
  leftSep : Separate l
  rightSep : Separate r
  leftKnown : Known v rec l
  rightKnown : Known v rec r
  sum : ∀ i, total (mass (v i)) l + total (mass (v i)) r = total (mass (v i)) s
  leftMass : aggregate v scale l ≤ 3*aggregate v scale s/4
  rightMass : aggregate v scale r ≤ 3*aggregate v scale s/4

omit [Fintype E] in
theorem many_good (v : Fin n → Valuation) (cells : E → Bundle) (rec : Records n)
    (scale : Fin n → ℝ) (hn : ∀ i, 0 ≤ scale i) (sep : ∀ e, Separate (cells e))
    (ok : ∀ e, Known v rec (cells e)) (l : List E) :
    Good v (fun z => Preserves v rec z.record ∧
      (∀ e ∈ l, Slice v (cells e) z.record scale (z.l e) (z.r e)) ∧
      ∀ e ∉ l, z.l e = cells e ∧ z.r e = []) (l.length*(3*n)) (many cells rec scale l) := by
  induction l generalizing rec with
  | nil => exact (good_ret ..).2 ⟨preserves_refl v rec,by simp,by simp⟩
  | cons e es ih =>
    rw [List.length_cons,Nat.succ_mul,Nat.add_comm]
    apply bind_good v _ _ _ _ _ _ (split_good v _ rec scale hn (sep e) (ok e))
    intro z h
    apply bind_good v _ _ _ _ _ 0 (ih z.record (fun e i a ha => h.keep i a (ok e i a ha)))
    rintro t ⟨keep,inside,outside⟩
    apply (good_ret ..).2
    refine ⟨preserves_trans h.keep keep,?_,?_⟩
    · intro j hj
      by_cases eq : j = e
      · subst j; simp only [Function.update_self]
        exact ⟨h.cover,h.separate,h.leftSep,h.rightSep,fun i a ha => keep i a (h.leftKnown i a ha),
          fun i a ha => keep i a (h.rightKnown i a ha),h.mass,h.leftMass,h.rightMass⟩
      · simp only [Function.update_of_ne eq]
        exact inside _ ((List.mem_cons.mp hj).resolve_left eq)
    · intro j hj
      have ne : j ≠ e := fun eq => hj (List.mem_cons.mpr (Or.inl eq))
      simpa only [Function.update_of_ne ne] using outside j (fun inS => hj (List.mem_cons_of_mem _ inS))

def weight (rec : Records n) (cells : E → Bundle) := fun i e => total (rec i) (cells e)

def children (s : Finset E) (c : Cuts n E) : E ⊕ s → Bundle
  | .inl e => c.l e
  | .inr e => c.r e

def parent (s : Finset E) : E ⊕ s → E
  | .inl e => e
  | .inr e => e.val

/-- Properties propagated to the next round. The fractional slot totals,
the physical partition and all previously accumulated interval records survive. -/
structure Family (v : Fin n → Valuation) (rec : Records n) (U : Bundle)
    (scale : Fin n → ℝ) (target : Fin n → J → ℝ) (cap : ℝ)
    (cells : E → Bundle) (p : E → J → ℝ) : Prop where
  separate : ∀ e, Separate (cells e)
  disjoint : ∀ e b, e ≠ b → Disjoint (cells e).points (cells b).points
  cover : ∀ x, x ∈ U.points ↔ ∃ e, x ∈ (cells e).points
  known : ∀ e, Known v rec (cells e)
  pos : ∀ e j, 0 ≤ p e j
  row : ∀ e, ∑ j, p e j = 1
  exactValue : ∀ i j, ∑ e, p e j * total (mass (v i)) (cells e) = target i j
  shared : ∀ e ∈ mixed p, aggregate v scale (cells e) ≤ cap

theorem round_good (v : Fin n → Valuation) (rec : Records n) (U : Bundle) (cells : E → Bundle)
    (p : E → J → ℝ) (scale : Fin n → ℝ) (hn : ∀ i, 0 ≤ scale i)
    (target : Fin n → J → ℝ) (cap : ℝ) (f : Family v rec U scale target cap cells p) :
    let z := sparse (weight rec cells) p
    let S := mixed z
    Good v (fun cut => Preserves v rec cut.record ∧
      Family v cut.record U scale target (3*cap/4) (children S cut) (fun e => z (parent S e)))
      ((n*Fintype.card J)*(3*n)) (many cells rec scale S.toList) := by
  classical
  let z := sparse (weight rec cells) p
  let S := mixed z
  have th := sparse_ok (weight rec cells) p f.pos f.row
  have wt (i e) : weight rec cells i e = total (mass (v i)) (cells e) := recorded_total _ _ _ (f.known e i)
  have subset : S ⊆ mixed p := mixed_mono th.2.1
  apply mono v _ (show S.toList.length*(3*n) ≤ _ by rw [length_toList]; exact Nat.mul_le_mul_right _ th.2.2.2.2)
  apply OracleTree.strengthen _ _ _ _ _ (many_good v cells rec scale hn f.separate f.known S.toList)
  rintro c ⟨keep,hit,skip⟩
  have old (e) (he : e ∉ S) : c.l e = cells e ∧ c.r e = [] := skip e (by simpa using he)
  have slice (e) (he : e ∈ S) := hit e (mem_toList.mpr he)
  let L := children S c
  have lsub (e) : (c.l e).points ⊆ (cells e).points := by
    by_cases he : e ∈ S
    · exact (slice e he).cover ▸ Set.subset_union_left
    · rw [(old e he).1]
  have rsub (e : S) : (c.r e).points ⊆ (cells e).points := (slice e e.2).cover ▸ Set.subset_union_right
  refine ⟨keep,⟨?_,?_,?_,?_,fun e => th.1 (parent S e),fun e => th.2.2.1 (parent S e),?_,?_⟩⟩
  · rintro (e | e)
    · by_cases he : e ∈ S
      · exact (slice e he).leftSep
      · change Separate (c.l e); rw [(old e he).1]; exact f.separate e
    · exact (slice e e.2).rightSep
  · rintro (a | a) (b | b) ne
    · exact (f.disjoint a b (fun eq => ne (congrArg Sum.inl eq))).mono (lsub _) (lsub _)
    · by_cases eq : a = (b:E)
      · subst a; exact (slice b b.2).disj
      · exact (f.disjoint _ _ eq).mono (lsub _) (rsub _)
    · by_cases eq : (a:E) = b
      · subst b; exact (slice a a.2).disj.symm
      · exact (f.disjoint _ _ eq).mono (rsub _) (lsub _)
    · exact (f.disjoint _ _ (fun eq => ne (congrArg Sum.inr (Subtype.ext eq)))).mono (rsub _) (rsub _)
  · intro x; rw [f.cover x]; constructor
    · rintro ⟨e,he⟩
      by_cases hs : e ∈ S
      · rw [← (slice e hs).cover] at he
        rcases he with l | r
        · exact ⟨.inl e,l⟩
        · exact ⟨.inr ⟨e,hs⟩,r⟩
      · exact ⟨.inl e,by change x ∈ (c.l e).points; rw [(old e hs).1]; exact he⟩
    · rintro ⟨e,he⟩
      cases e with
      | inl e => exact ⟨e,lsub e he⟩
      | inr e => exact ⟨e,rsub e he⟩
  · rintro (e | e)
    · by_cases hs : e ∈ S
      · exact (slice e hs).leftKnown
      · change Known v c.record (c.l e); rw [(old e hs).1]
        exact fun i a ha => keep i a (f.known e i a ha)
    · exact (slice e e.2).rightKnown
  · intro i j
    let m := fun b => total (mass (v i)) b
    have eq (e) : m (c.l e) + m (c.r e) = m (cells e) := by
      by_cases hs : e ∈ S
      · exact (slice e hs).sum i
      · simp [m,(old e hs).1,(old e hs).2,total]
    have sub : (∑ e : S, z e j * m (c.r e)) = ∑ e : E, z e j * m (c.r e) := by
      calc
        _ = ∑ e ∈ S,z e j*m (c.r e) := Finset.sum_attach _ _
        _ = _ := Finset.sum_subset (subset_univ _) (fun e _ he => by simp [m,(old e he).2,total])
    have exact' := th.2.2.2.1 i j
    simp only [wt] at exact'
    rw [Fintype.sum_sum_type]
    change (∑ e,z e j*m (c.l e)) + (∑ e : S,z e j*m (c.r e)) = _
    rw [sub,← sum_add_distrib]
    simp_rw [← mul_add,eq]
    exact exact'.trans (f.exactValue i j)
  · intro e he
    have parentIn : parent S e ∈ mixed z := by
      apply mem_filter.mpr; exact ⟨mem_univ _,(mem_filter.mp he).2⟩
    have small := f.shared _ (subset parentIn)
    cases e with
    | inl a =>
      change aggregate v scale (cells a) ≤ cap at small
      have bound := (slice a parentIn).leftMass
      change aggregate v scale (c.l a) ≤ _; linarith
    | inr a =>
      change aggregate v scale (cells a) ≤ cap at small
      have bound := (slice a a.2).rightMass
      change aggregate v scale (c.r a) ≤ _; linarith

end
end CakeCutting.Refinement
