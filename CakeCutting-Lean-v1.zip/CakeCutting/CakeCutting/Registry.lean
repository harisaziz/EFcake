import CakeCutting.Simulation
import CakeCutting.OrderedPieces

/-! A transcript stores finite graphs with one physical-coordinate map per
piece and one physical-value map per observer. All data used by the updates
are observed, including the bracket for an arbitrary inverse answer. -/
namespace CakeCutting.Registry
noncomputable section
open Finset
open scoped NNReal
abbrev N := ℝ≥0
abbrev Graph := Finset (N × N)

def Ordered (B : Graph) := ∀ p ∈ B, ∀ q ∈ B, (p.1 < q.1 ↔ p.2 < q.2) ∧ (p.1 = q.1 ↔ p.2 = q.2)

theorem ordered_insert {B : Graph} (old : Ordered B) {x y : N}
    (lo : ∀ p ∈ B, p.1 < x → p.2 < y) (hi : ∀ p ∈ B, x < p.1 → y < p.2)
    (new : ∀ p ∈ B, p.1 ≠ x) : Ordered (insert (x,y) B) := by
  have toward (p) (hp : p ∈ B) : (p.1 < x ↔ p.2 < y) ∧ (p.1 = x ↔ p.2 = y) ∧ (x < p.1 ↔ y < p.2) := by
    rcases lt_or_gt_of_ne (new p hp) with lt | gt
    · have := lo p hp lt; simp [lt,this,lt.ne,this.ne,lt.not_gt,this.not_gt]
    · have := hi p hp gt; simp [gt,this,gt.ne',this.ne',gt.not_gt,this.not_gt]
  intro p hp q hq
  rcases mem_insert.mp hp with rfl | hp <;> rcases mem_insert.mp hq with rfl | hq
  · simp
  · exact ⟨(toward _ hq).2.2,by simpa only [eq_comm] using (toward _ hq).2.1⟩
  · exact ⟨(toward _ hp).1,(toward _ hp).2.1⟩
  · exact old _ hp _ hq

structure Board (R C : Type) (P : R → Type) (Q : C → Type) where
  row : ∀ r, N → P r
  col : ∀ c, N → Q c
  graph : R → C → Graph

variable {R C : Type} {P : R → Type} {Q : C → Type}
  [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C]
  [∀ i, LinearOrder (P i)] [∀ j, LinearOrder (Q j)]

def swap (B : Graph) := B.image Prod.swap
@[simp] theorem swap_mem {B : Graph} {p : N × N} : p ∈ swap B ↔ p.swap ∈ B := by
  constructor
  · intro h; obtain ⟨q,hq,rfl⟩ := mem_image.mp h; simpa using hq
  · intro h; exact mem_image.mpr ⟨p.swap,h,Prod.swap_swap _⟩
@[simp] theorem swap_swap (B : Graph) : swap (swap B) = B := by ext p; simp

def flip (s : Board R C P Q) : Board C R Q P :=
  ⟨s.col,s.row,fun c r => swap (s.graph r c)⟩
omit [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C] [(i : R) → LinearOrder (P i)] [(j : C) → LinearOrder (Q j)] in
@[simp] theorem flip_flip (s : Board R C P Q) : flip (flip s) = s := by
  cases s; simp [flip]

structure Valid (s : Board R C P Q) (link : ∀ r c, P r → Q c → Prop) : Prop where
  rowMono : ∀ r, Monotone (s.row r)
  colMono : ∀ c, Monotone (s.col c)
  ordered : ∀ r c, Ordered (s.graph r c)
  linked : ∀ r c p, p ∈ s.graph r c → link r c (s.row r p.1) (s.col c p.2)

def rev (link : ∀ r c, P r → Q c → Prop) := fun c r x y => link r c y x

omit [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C] in
theorem valid_flip {s : Board R C P Q} {L} (h : Valid s L) : Valid (flip s) (rev L) := by
  refine ⟨h.colMono,h.rowMono,?_,?_⟩
  · intro c r p hp q hq
    have v := h.ordered r c _ (swap_mem.mp hp) _ (swap_mem.mp hq)
    exact ⟨v.1.symm,v.2.symm⟩
  · intro c r p hp; exact h.linked r c p.swap (swap_mem.mp hp)

/-- All previously registered physical coordinates and pairs are preserved. -/
structure Extends (s t : Board R C P Q) : Prop where
  keep : ∀ r c, s.graph r c ⊆ t.graph r c
  rows : ∀ r c p, p ∈ s.graph r c → t.row r p.1 = s.row r p.1
  cols : ∀ r c p, p ∈ s.graph r c → t.col c p.2 = s.col c p.2

omit [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C] [(i : R) → LinearOrder (P i)] [(j : C) → LinearOrder (Q j)] in
theorem extends_refl (s : Board R C P Q) : Extends s s := ⟨fun _ _ => Subset.rfl,by simp,by simp⟩

omit [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C] [(i : R) → LinearOrder (P i)] [(j : C) → LinearOrder (Q j)] in
theorem extends_trans {a b c : Board R C P Q} (h : Extends a b) (k : Extends b c) : Extends a c :=
  ⟨fun r j => (h.keep r j).trans (k.keep r j),
   fun r j p hp => (k.rows r j p (h.keep r j hp)).trans (h.rows r j p hp),
   fun r j p hp => (k.cols r j p (h.keep r j hp)).trans (h.cols r j p hp)⟩

omit [Fintype R] [Fintype C] [DecidableEq R] [DecidableEq C] [(i : R) → LinearOrder (P i)] [(j : C) → LinearOrder (Q j)] in
theorem extends_flip {s t : Board R C P Q} (h : Extends s t) : Extends (flip s) (flip t) :=
  ⟨fun c r _ hp => swap_mem.mpr (h.keep r c (swap_mem.mp hp)),
   fun c r p hp => h.cols r c p.swap (swap_mem.mp hp),
   fun c r p hp => h.rows r c p.swap (swap_mem.mp hp)⟩

def oldKeys (s : Board R C P Q) (c : C) :=
  univ.biUnion (fun r => (s.graph r c).image Prod.snd)

omit [Fintype C] [DecidableEq R] [DecidableEq C] [(i : R) → LinearOrder (P i)] [(j : C) → LinearOrder (Q j)] in
private theorem seen {s : Board R C P Q} {c r p} (hp : p ∈ s.graph r c) : p.2 ∈ oldKeys s c :=
  mem_biUnion.mpr ⟨r,mem_univ _,mem_image_of_mem _ hp⟩

noncomputable def add (s : Board R C P Q) (r : R) (c : C) (x y : N) (G : N → Q c) : Board R C P Q :=
  {s with col := Function.update s.col c G,
          graph := fun i j => if i = r ∧ j = c then insert (x,y) (s.graph i j) else s.graph i j}

structure Choice (s : Board R C P Q) (r : R) (c : C) (x : N) (u : Q c) (y : N) (G : N → Q c) : Prop where
  mono : Monotone G
  old : ∀ k ∈ oldKeys s c, G k = s.col c k
  output : G y = u
  below : ∀ p ∈ s.graph r c, p.1 < x → p.2 < y
  above : ∀ p ∈ s.graph r c, x < p.1 → y < p.2

omit [Fintype C] in
theorem add_spec {s : Board R C P Q} {L} (v : Valid s L) {r c x u y G}
    (ch : Choice s r c x u y G) (fresh : ∀ p ∈ s.graph r c, p.1 ≠ x)
    (rel : L r c (s.row r x) u) :
    let t := add s r c x y G
    Extends s t ∧ Valid t L ∧ (x,y) ∈ t.graph r c := by
  have ext : Extends s (add s r c x y G) := by
    refine ⟨?_,by simp [add],?_⟩
    · intro i j; dsimp [add]; split <;> first | exact subset_insert .. | exact Subset.rfl
    · intro i j p hp
      by_cases eq : j = c
      · subst j; simpa [add] using ch.old p.2 (seen hp)
      · simp [add,Function.update_of_ne eq]
  refine ⟨ext,⟨v.rowMono,?_,?_,?_⟩,by simp [add]⟩
  · intro j; by_cases eq : j = c
    · subst j; simpa [add] using ch.mono
    · simpa [add,Function.update_of_ne eq] using v.colMono j
  · intro i j; by_cases hit : i = r ∧ j = c
    · rcases hit with ⟨rfl,rfl⟩; simpa [add] using ordered_insert (v.ordered i j) ch.below ch.above fresh
    · simpa [add,hit] using v.ordered i j
  · intro i j p hp
    by_cases hit : i = r ∧ j = c
    · rcases hit with ⟨rfl,rfl⟩
      have mem : p ∈ insert (x,y) (s.graph i j) := by simpa [add] using hp
      rcases mem_insert.mp mem with rfl | old
      · simpa [add,ch.output] using rel
      · rw [ext.rows i j p old,ext.cols i j p old]; exact v.linked i j p old
    · have old : p ∈ s.graph i j := by simpa [add,hit] using hp
      rw [ext.rows i j p old,ext.cols i j p old]; exact v.linked i j p old

omit [Fintype C] [DecidableEq R] [DecidableEq C] [(i : R) → LinearOrder (P i)] in
/-- A choice is made from the tables and a physical response alone. -/
theorem choice_exists (s : Board R C P Q) (r : R) (c : C) (x : N) (u : Q c)
    (ord : Ordered (s.graph r c)) (mon : Monotone (s.col c))
    (fresh : ∀ p ∈ s.graph r c, p.1 ≠ x)
    (lo : ∃ p ∈ s.graph r c, p.1 < x) (hi : ∃ p ∈ s.graph r c, x < p.1)
    (left : ∀ p ∈ s.graph r c, p.1 < x → s.col c p.2 ≤ u)
    (right : ∀ p ∈ s.graph r c, x < p.1 → u ≤ s.col c p.2) :
    ∃ y G, Choice s r c x u y G := by
  classical
  let B := s.graph r c
  let S := B.image Prod.fst
  let f (z : N) := if h : ∃ b, (z,b) ∈ B then Classical.choose h else 0
  have read (p) (hp : p ∈ B) : f p.1 = p.2 := by
    have ex : ∃ b, (p.1,b) ∈ B := ⟨p.2,hp⟩
    simpa [f,ex] using (ord _ (Classical.choose_spec ex) p hp).2.mp rfl
  have pick (z) (hz : z ∈ S) : (z,f z) ∈ B := by
    obtain ⟨p,hp,rfl⟩ := mem_image.mp hz
    simpa [read _ hp] using hp
  have strict : StrictMonoOn f S := fun a ha b hb lt => (ord _ (pick a ha) _ (pick b hb)).1.mp lt
  obtain ⟨p,hp,px⟩ := lo
  obtain ⟨q,hq,xq⟩ := hi
  obtain ⟨y,_,G,hm,old,out,inc⟩ := Transcript.extend_pair S (oldKeys s c) f strict
    (fun a ha => seen (pick a ha)) _ mon x (fun hx => fresh _ (pick x hx) rfl)
    ⟨p.1,mem_image_of_mem _ hp,px⟩ ⟨q.1,mem_image_of_mem _ hq,xq⟩ u
    (fun a ha lt => left _ (pick a ha) lt) (fun b hb lt => right _ (pick b hb) lt)
  refine ⟨y,G,hm,old,out,?_,?_⟩
  · intro b hb lt
    have neq := fresh b hb
    have v := inc (mem_insert_of_mem (mem_image_of_mem Prod.fst hb)) (mem_insert_self x S) lt
    simpa [Function.update_of_ne neq,read b hb] using v
  · intro b hb lt
    have neq := fresh b hb
    have v := inc (mem_insert_self x S) (mem_insert_of_mem (mem_image_of_mem Prod.fst hb)) lt
    simpa [Function.update_of_ne neq,read b hb] using v

end
end CakeCutting.Registry
