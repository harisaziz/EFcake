import CakeCutting.Quantiles
import Mathlib.Data.Finset.Lattice.Fold

/-! One simultaneous update of the shared-table median protocol. -/

namespace CakeCutting.Relaxation

open Finset CakeCutting.Matching CakeCutting.Quantiles

variable {A R C V W : Type*} [Fintype A] [Nonempty A] [DecidableEq A] [Fintype R] [Fintype C]
  [Nonempty C] [DecidableEq R] [DecidableEq C] [LinearOrder V] [LinearOrder W]

structure Assignment (R C : Type*) (pin : C) where
  col : R → C
  row : C → R
  avoids : ∀ i, col i ≠ pin
  left_inv : ∀ i, row (col i) = i
  right_inv : ∀ j, j ≠ pin → col (row j) = j

variable (f : R → C → V ≃o W) (g : ℕ) (hg : 0 < g)

def rowCost (x : C → V) (i : R) : W :=
  univ.inf' univ_nonempty (fun j => f i j (x j))

def trial (u : A → C → V) (a : A) (i : R) : W :=
  rowCost f (fun j => roundUp (fun b => u b j) g hg a) i

def update (pin : C) (M : A → Assignment R C pin) (u : A → C → V) (a : A) (j : C) : V :=
  if j = pin then u a j else
    let i := (M a).row j
    min (u a j) ((f i j).symm (roundUp (fun b => trial f g hg u b i) g hg a))

def settled (u x : C → V) := univ.filter (fun j => u j ≤ x j)

omit [Fintype R] [DecidableEq R] [DecidableEq C] in
theorem cost_at_tight (x : C → V) (i : R) (j : C)
    (h : j ∈ tight (table (fun i j v => f i j v) x) i) :
    rowCost f x i = f i j (x j) := by
  exact le_antisymm (inf'_le _ (mem_univ _)) (le_inf' _ _ (fun k _ => (mem_tight ..).mp h k))

omit [Fintype R] [DecidableEq R] [DecidableEq A] in
theorem update_le (pin : C) (M : A → Assignment R C pin) (u : A → C → V) (a : A) (j : C) :
    update f g hg pin M u a j ≤ u a j := by
  unfold update
  split <;> simp

omit [Fintype R] [DecidableEq R] [DecidableEq A] in
/-- Rounding both tables up preserves all upper bounds for a supporting candidate. -/
theorem support_preserved (pin : C) (M : A → Assignment R C pin) (u : A → C → V)
    (a : A) (x : C → V) (hu : ∀ j, x j ≤ u a j)
    (hm : ∀ i, (M a).col i ∈ tight (table (fun i j v => f i j v) x) i) :
    ∀ j, x j ≤ update f g hg pin M u a j := by
  intro j
  by_cases hj : j = pin
  · simpa [update, hj] using hu j
  · let i := (M a).row j
    have hit : j ∈ tight (table (fun i j v => f i j v) x) i :=
      (M a).right_inv j hj ▸ hm i
    have hrow : rowCost f x i ≤ trial f g hg u a i := by
      apply Finset.le_inf' univ_nonempty _
      intro k _
      exact (inf'_le _ (mem_univ k)).trans ((f i k).monotone ((hu k).trans
        (roundUp_spec (fun b => u b k) g hg a).2))
    simp only [update, if_neg hj]
    exact Median.supporting_update (f i j) _ _ _ _ (hu j)
      (cost_at_tight f x i j hit).symm
      (hrow.trans (roundUp_spec (fun b => trial f g hg u b i) g hg a).2)

def colErrors (u : A → C → V) (x : C → V) (a : A) := univ.filter (fun j =>
  a ∈ crossings (fun b => u b j) g hg (x j))

def rowErrors (u : A → C → V) (x : C → V) (a : A) := univ.filter (fun i =>
  a ∈ crossings (fun b => trial f g hg u b i) g hg (rowCost f x i))

theorem update_progress (pin : C) (M : A → Assignment R C pin) (u : A → C → V)
    (a : A) (x : C → V) (hd : Fintype.card C = Fintype.card R + 1)
    (hp : u a pin = x pin) (hex : FullyExposable (tight (table (fun i j v => f i j v) x))) :
    (settled (u a) x).card + (if settled (u a) x = univ then 0 else 1) ≤
      (settled (update f g hg pin M u a) x).card +
      (colErrors g hg u x a).card + (rowErrors f g hg u x a).card := by
  classical
  apply Median.rounded_step _ hd hex pin (M a).col
    (Function.LeftInverse.injective (M a).left_inv) (M a).avoids
  · intro j hj
    exact mem_filter.mpr ⟨mem_univ _, (update_le f g hg pin M u a j).trans (mem_filter.mp hj).2⟩
  · simp [settled, update, hp]
  · intro j hj hcol i ht hrow
    have before : u a j ≤ x j := (mem_filter.mp hj).2
    have after : roundUp (fun b => u b j) g hg a ≤ x j := by
      by_contra! h
      exact hcol (mem_filter.mpr ⟨mem_univ _, mem_filter.mpr
        ⟨mem_filter.mpr ⟨mem_univ _, before⟩, h⟩⟩)
    have rc : trial f g hg u a i ≤ rowCost f x i := by
      rw [cost_at_tight f x i j ht]
      exact (inf'_le _ (mem_univ j)).trans ((f i j).monotone after)
    have rr : roundUp (fun b => trial f g hg u b i) g hg a ≤ rowCost f x i := by
      by_contra! h
      exact hrow (mem_filter.mpr ⟨mem_univ _, mem_filter.mpr
        ⟨mem_filter.mpr ⟨mem_univ _, rc⟩, h⟩⟩)
    apply mem_filter.mpr
    refine ⟨mem_univ _, ?_⟩
    simp only [update, if_neg ((M a).avoids i), (M a).left_inv]
    apply le_trans (min_le_right _ _)
    apply (f i ((M a).col i)).symm_apply_le.mpr
    exact rr.trans (inf'_le _ (mem_univ _))

end CakeCutting.Relaxation
