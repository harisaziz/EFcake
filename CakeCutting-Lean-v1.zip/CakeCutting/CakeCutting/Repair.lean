import CakeCutting.PositiveTrim
import Mathlib.Tactic.Linarith

/-! The certification counting test and the protection argument for Repair.
Labels and original owners have the same index type. The holder permutation
records the new owners, which need not be the original owners. -/
namespace CakeCutting.Repair
open Finset

variable {R : Type*} [Fintype R] [DecidableEq R]

/-- For a trimmed set of labels, strictly more agents have a favorite in
the set than there are labels in the set. -/
theorem escape (fav : R → R → Prop) (whole : R → Prop) (holder : R ≃ R)
    (rank : R ≃ Fin (Fintype.card R)) (own : ∀ j, fav (holder j) j)
    (cert : ∀ j, whole j ∨ ∃ i, rank i < rank j ∧ fav (holder i) j)
    (H : Finset R) (ne : H.Nonempty) (trim : ∀ j ∈ H, ¬ whole j) :
    ∃ S : Finset R, H.card < S.card ∧ ∀ a ∈ S, ∃ j ∈ H, fav a j := by
  classical
  obtain ⟨j,hj,minj⟩ := H.exists_min_image rank ne
  obtain ⟨i,lt,edge⟩ := (cert j).resolve_left (trim j hj)
  have hi : i ∉ H := fun h => lt.not_ge (minj i h)
  have fresh : holder i ∉ H.image holder := by simpa using hi
  refine ⟨insert (holder i) (H.image holder),?_,?_⟩
  · rw [card_insert_of_notMem fresh,card_image_of_injective _ holder.injective]
    omega
  · intro a ha
    rcases mem_insert.mp ha with rfl | old
    · exact ⟨j,hj,edge⟩
    · obtain ⟨k,hk,rfl⟩ := mem_image.mp old
      exact ⟨k,hk,own k⟩

/-- Actual retained levels are shifted by one: zero means the trim
entered the protected part, and n means that the entire label survived.
Two levels of separation imply that the original upper owner strictly
prefers her own label. This and certification suffice to protect all labels. -/
theorem protected_survives [Nonempty R] (value : R → R → ℝ) (level : R → Fin (Fintype.card R + 1))
    (holder : R ≃ R) (rank : R ≃ Fin (Fintype.card R))
    (ef : ∀ j k, value (holder j) k ≤ value (holder j) j)
    (cert : ∀ j, (level j).val = Fintype.card R ∨ ∃ i, rank i < rank j ∧
      value (holder i) j = value (holder i) i)
    (apart : ∀ i j, (level j).val + 2 ≤ (level i).val → value i j < value i i) :
    ∀ j, 0 < (level j).val := by
  classical
  have missing : ¬ Function.Surjective level := by
    intro h
    have hh := Fintype.card_le_of_surjective level h
    simp at hh
  obtain ⟨μ,hμ⟩ : ∃ μ, ∀ j, level j ≠ μ := by simpa [Function.Surjective] using missing
  intro b
  by_contra! cut
  have low : (level b).val = 0 := by omega
  have bμ := hμ b
  have pos : 0 < μ.val := by
    by_contra! h
    exact bμ (Fin.ext (by omega))
  let H := univ.filter (fun j => (level j).val < μ.val)
  have hH : H.Nonempty := ⟨b,mem_filter.mpr ⟨mem_univ _,by omega⟩⟩
  let fav := fun a j => ∀ k, value a k ≤ value a j
  have cert' (j) : (level j).val = Fintype.card R ∨ ∃ i, rank i < rank j ∧ fav (holder i) j := by
    rcases cert j with h | ⟨i,h,he⟩
    · exact Or.inl h
    · exact Or.inr ⟨i,h,fun k => he.symm ▸ ef i k⟩
  obtain ⟨S,big,hit⟩ := escape fav _ holder rank ef cert' H hH (by
    intro j hj
    have lt := (mem_filter.mp hj).2
    have := μ.isLt
    omega)
  have sub : S ⊆ H := by
    intro a ha
    obtain ⟨j,hj,favorite⟩ := hit a ha
    apply mem_filter.mpr
    refine ⟨mem_univ _,?_⟩
    by_contra! upper
    have unequal : (level a).val ≠ μ.val := fun h => hμ a (Fin.ext h)
    have lower := (mem_filter.mp hj).2
    exact (apart a j (by omega)).not_ge (favorite a)
  exact big.not_ge (card_le_card sub)

/-- One extra whole buffer beats input envy and the total rounding deficit. -/
theorem comparison (α t dOwn dOther upper lower : ℝ) (k : ℕ)
    (positive : 0 < α) (envy : dOther ≤ dOwn + α)
    (upper_bound : dOwn + t + ((k : ℝ) + 1)*(2*α) - α/2 ≤ upper)
    (lower_bound : lower ≤ dOther + t + (k : ℝ)*(2*α)) :
    lower < upper := by linarith

end CakeCutting.Repair
