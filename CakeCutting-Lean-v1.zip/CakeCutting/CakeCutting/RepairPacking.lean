import CakeCutting.Buffered

/-! Packing n large shares and n(n-1) buffers around the old labels. Prefixes
of the slot row describe exactly the complete tails used in the protection proof. -/
namespace CakeCutting.RepairPacking
open Finset Set Components MeasureTheory PhysicalShares AdaptiveTrim BoundaryRecords Buffered SharesProtocol
noncomputable section
variable {n : ℕ} [NeZero n]
abbrev Agent (n : ℕ) := Fin n
abbrev Slot (n : ℕ) := Fin n × Fin n
def big (α : ℝ) (n : ℕ) := (1-(n:ℝ)*((n:ℝ)-1)*(2*α))/n
def weight (n : ℕ) (α : ℝ) (q : Slot n) := if q.2.val = 0 then big α n else 2*α

theorem target_ok (hn : 2 ≤ n) (α : ℝ) (pos : 0 < α) (small : α ≤ 1/(8*(n:ℝ)^2)) :
    (∀ q, 0 ≤ weight n α q) ∧ ∑ q, weight n α q = 1 := by
  have h : (2:ℝ) ≤ n := by exact_mod_cast hn
  have nr : (0:ℝ) < n := by linarith
  have cap := (le_div_iff₀ (by positivity : 0 < 8*(n:ℝ)^2)).mp small
  have b : 0 ≤ big α n := by
    apply div_nonneg _ nr.le; nlinarith [mul_nonneg nr.le pos.le]
  refine ⟨fun q => by unfold weight; split <;> positivity,?_⟩
  have row (i : Fin n) : ∑ j : Fin n, weight n α (i,j) = big α n + ((n:ℝ)-1)*(2*α) := by
    have part (j : Fin n) : weight n α (i,j) = (if j=0 then big α n - 2*α else 0) + 2*α := by
      by_cases eq : j=0
      · subst j; simp [weight]
      · have v : j.val ≠ 0 := fun z => eq (Fin.ext (by simpa using z))
        simp [weight,v,eq]
    simp_rw [part,sum_add_distrib]
    simp; ring
  rw [Fintype.sum_prod_type]; simp_rw [row]; simp [big]; field_simp; ring

def slots (j : Fin n) (k : ℕ) : Finset (Slot n) :=
  univ.filter (fun q => q.1=j ∧ q.2.val ≤ k)

private theorem slots_zero (j : Fin n) : slots j 0 = {(j,0)} := by
  ext q
  simp only [slots,mem_filter,Finset.mem_univ,true_and,Finset.mem_singleton]
  constructor
  · rintro ⟨a,b⟩
    exact Prod.ext a (Fin.ext (by simpa using b))
  · rintro rfl; simp

omit [NeZero n] in
private theorem slots_succ (j : Fin n) (k : ℕ) (hk : k+1<n) :
    slots j (k+1) = insert (j,⟨k+1,hk⟩) (slots j k) := by
  ext q
  simp only [slots,mem_filter,Finset.mem_univ,true_and,Finset.mem_insert]
  constructor
  · rintro ⟨a,b⟩
    rcases Nat.lt_or_eq_of_le b with lt | eq
    · exact Or.inr ⟨a,by omega⟩
    · exact Or.inl (Prod.ext a (Fin.ext eq))
  · rintro (rfl | ⟨a,b⟩)
    · simp
    · exact ⟨a,by omega⟩

theorem slot_sum (j : Fin n) (α : ℝ) (k : ℕ) (hk : k < n) :
    ∑ q ∈ slots j k, weight n α q = big α n + k*(2*α) := by
  induction k with
  | zero =>
    simp [slots_zero,weight]
  | succ k ih =>
    let a : Slot n := (j,⟨k+1,hk⟩)
    have e := slots_succ j k hk
    have no : a ∉ slots j k := by simp [a,slots]
    rw [e,sum_insert no,ih (by omega)]
    simp [weight,a]; ring

def pack (d : Allocation n) (o : Result n (Slot n)) (j : Fin n) (k : ℕ) : Bundle :=
  tail (d j ++ o.part (some (j,0))) (fun h => if hh : h+1 < n then o.part (some (j,⟨h+1,hh⟩)) else []) k

theorem pack_points (d : Allocation n) (o : Result n (Slot n)) (j : Fin n) (k : ℕ) (hk : k < n) :
    (pack d o j k).points = (d j).points ∪ {x | ∃ q ∈ slots j k, x ∈ (o.part (some q)).points} := by
  induction k with
  | zero =>
    rw [pack,tail,append_points]
    congr 1
    ext x
    constructor
    · intro h; exact ⟨(j,0),by simp [slots],h⟩
    · rintro ⟨⟨a,b⟩,hab,h⟩
      obtain ⟨rfl,zero⟩ := (mem_filter.mp hab).2
      have eq : b = 0 := Fin.ext (by simpa using zero)
      simpa [eq] using h
  | succ k ih =>
    let q : Slot n := (j,⟨k+1,hk⟩)
    change Bundle.points ((if hh : k+1<n then _ else _) ++ pack d o j k) = _
    rw [dif_pos hk,append_points,ih (by omega)]
    ext x
    simp only [Set.mem_union,Set.mem_setOf_eq]
    constructor
    · rintro (h | old | ⟨a,ha,h⟩)
      · exact Or.inr ⟨q,mem_filter.mpr ⟨Finset.mem_univ _,rfl,le_rfl⟩,h⟩
      · exact Or.inl old
      · exact Or.inr ⟨a,mem_filter.mpr ⟨Finset.mem_univ _,(mem_filter.mp ha).2.1, (mem_filter.mp ha).2.2.trans (Nat.le_succ _)⟩,h⟩
    · rintro (old|⟨a,ha,h⟩)
      · exact Or.inr (Or.inl old)
      · obtain ⟨left,right⟩ := (mem_filter.mp ha).2
        by_cases e : a.2.val=k+1
        · have same : a=q := Prod.ext left (Fin.ext e)
          subst a; exact Or.inl h
        · exact Or.inr (Or.inr ⟨a,mem_filter.mpr ⟨Finset.mem_univ _,left,by omega⟩,h⟩)

theorem append_separate (a b : Bundle) (h : Separate a) (g : Separate b)
    (apart : Disjoint a.points b.points) : Separate (a++b) := by
  apply List.pairwise_append.mpr
  exact ⟨h,g,fun e he f hf => Set.disjoint_left.mpr (fun _ h₁ h₂ => Set.disjoint_left.mp apart ⟨e,he,h₁⟩ ⟨f,hf,h₂⟩)⟩

theorem pack_separate (d : Allocation n) (o : Result n (Slot n)) (j : Fin n) (k : ℕ) (hk : k < n)
    (ds : Separate (d j)) (os : ∀ q, Separate (o.part q))
    (apart : ∀ q, Disjoint (d j).points (o.part (some q)).points)
    (dis : ∀ p q, p ≠ q → Disjoint (o.part (some p)).points (o.part (some q)).points) :
    Separate (pack d o j k) := by
  induction k with
  | zero => exact append_separate _ _ ds (os _) (apart _)
  | succ k ih =>
    let q : Slot n := (j,⟨k+1,hk⟩)
    change Separate ((if hh : k+1<n then _ else _) ++ pack d o j k)
    rw [dif_pos hk]
    apply append_separate _ _ (os _) (ih (by omega))
    rw [pack_points _ _ _ _ (by omega)]
    apply Disjoint.union_right (apart q).symm
    apply Set.disjoint_left.mpr
    rintro x hx ⟨a,ha,ax⟩
    have ne : q ≠ a := by intro e; subst a; have := (mem_filter.mp ha).2.2; simp [q] at this
    exact Set.disjoint_left.mp (dis q a ne) hx ax

theorem pack_known (d : Allocation n) (o : Result n (Slot n)) (j : Fin n) (k : ℕ)
    (v : Fin n → Valuation) (old : Known v o.record (d j)) (know : ∀ q, Known v o.record (o.part q)) :
    Known v o.record (pack d o j k) := by
  have app {a b : Bundle} (ha : Known v o.record a) (hb : Known v o.record b) : Known v o.record (a++b) :=
    fun i e h => (List.mem_append.mp h).elim (ha i e) (hb i e)
  induction k with
  | zero => exact app old (know _)
  | succ k ih =>
    change Known v o.record ((if hh : k+1<n then _ else _) ++ pack d o j k)
    apply app _ ih; split
    · exact know _
    · simp [Known]

theorem total_pack (d : Allocation n) (o : Result n (Slot n)) (j : Fin n) (k : ℕ) (hk : k < n)
    (f : Interval → ℝ) :
    total f (pack d o j k) = total f (d j) + ∑ q ∈ slots j k, total f (o.part (some q)) := by
  have app (a b : Bundle) : total f (a++b) = total f a + total f b := by simp [total]
  induction k with
  | zero =>
    rw [pack,tail,app,slots_zero,sum_singleton]
  | succ k ih =>
    let a : Slot n := (j,⟨k+1,hk⟩)
    have e := slots_succ j k hk
    have no : a ∉ slots j k := by simp [a,slots]
    change total f ((if hh : k+1<n then _ else _) ++ pack d o j k) = _
    rw [dif_pos hk,app,ih (by omega),e,sum_insert no]
    ring

end
end CakeCutting.RepairPacking
