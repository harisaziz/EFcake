import CakeCutting.RepairPacking

/-! Physical Repair at the precisions reached by Reassign. The decision tree
uses only its prior component records and actual Robertson–Webb answers. -/
namespace CakeCutting.RepairProtocol
open Finset Set MeasureTheory Components DecisionTree AdaptiveTrim BoundaryRecords
open PhysicalShares RepairPacking SharesProtocol
noncomputable section
variable {n : ℕ} [NeZero n]

def full (d : Allocation n) (o : Result n (Slot n)) : Pieces n :=
  fun j => pack d o j (n-1)

structure Out (n : ℕ) where
  held : Allocation n
  residue : Bundle
  holder : Equiv.Perm (Fin n)
  record : Records n

def assemble (d : Allocation n) (o : Result n (Slot n)) (a : CertifiedTrim.Output (full d o)) (r : Records n) : Out n :=
  ⟨fun i => suffix (a.mark (a.holder.symm i)),o.part none ++ CoreProtocol.join (fun j => trimmings (a.mark j)),a.holder,r⟩

def cost (n : ℕ) := RepairRounds.rounds n*((n*(n*n))*(3*n)) + (CertifiedTrim.budget n + n*(2*n))
def program (d : Allocation n) (U : Bundle) (rec : Records n) (α : ℝ) : Tree n (Out n) :=
  bind (PhysicalShares.program (RepairRounds.rounds n) rec U (weight n α)) fun o =>
    bind (CertifiedTrim.protocol (full d o) o.record) fun a =>
      bind (CoreProtocol.recordAll (full d o) a o.record univ.toList) fun T => .ret (assemble d o a T)

def val (v : Valuation) (s : Bundle) := v.measure.real s.points

structure Spec (v : Fin n → Valuation) (d : Allocation n) (U : Bundle)
    (rec : Records n) (α : ℝ) (o : Out n) : Prop where
  ef : EnvyFree v o.held
  intact : ∀ j, (d j).points ⊆ (o.held (o.holder j)).points
  contained : ∀ j, (o.held (o.holder j)).points ⊆ (d j).points ∪ U.points
  residual_sub : o.residue.points ⊆ U.points
  sep : ∀ i, Separate (o.held i)
  res_sep : Separate o.residue
  dis : ∀ i j, i ≠ j → Disjoint (o.held i).points (o.held j).points
  apart : ∀ i, Disjoint (o.held i).points o.residue.points
  cover : ∀ x, (x ∈ U.points ∨ ∃ j, x ∈ (d j).points) ↔ (x ∈ o.residue.points ∨ ∃ i, x ∈ (o.held i).points)
  keep : Preserves v rec o.record
  known : ∀ i, Known v o.record (o.held i)
  res_known : Known v o.record o.residue
  difference : ∀ i j l, (val (v i) (o.held (o.holder j)) - val (v i) (d j)) -
    (val (v i) (o.held (o.holder l)) - val (v i) (d l)) ≤ 2*n*α*val (v i) U
  small : ∀ i, val (v i) o.residue ≤ 2*(n:ℝ)^2*α*val (v i) U

set_option maxHeartbeats 1600000 in
theorem program_good (hn : 2 ≤ n) (v : Fin n → Valuation) (d : Allocation n) (U : Bundle)
    (rec : Records n) (α : ℝ) (ds : ∀ j, Separate (d j)) (us : Separate U)
    (dd : ∀ i j, i ≠ j → Disjoint (d i).points (d j).points)
    (du : ∀ j, Disjoint (d j).points U.points)
    (dk : ∀ j, Known v rec (d j)) (uk : Known v rec U)
    (posU : ∀ i, 0 < total (rec i) U) (positive : 0 < α) (cap : α ≤ 1/(8*(n:ℝ)^2))
    (floor : 1/(4*(n:ℝ)^2)^(n+1) ≤ α)
    (envy : ∀ i j, val (v i) (d j) ≤ val (v i) (d i) + α*val (v i) U) :
    Good v (Spec v d U rec α) (cost n) (program d U rec α) := by
  classical
  let m := n-1
  have size : m+1=n := by dsimp [m]; omega
  have mn : m < n := by omega
  have nr : (0:ℝ) < n := by exact_mod_cast (by omega : 0 < n)
  have mr : (m:ℝ) = n-1 := by simp [m,Nat.cast_sub (by omega : 1 ≤ n)]
  let M := fun i => val (v i) U
  have massU (i) : total (mass (v i)) U = M i := total_eq_measure _ _ us
  have pos (i) : 0 < M i := (recorded_total _ _ _ (uk i)).trans (massU i) ▸ posU i
  have targets := target_ok hn α positive cap
  apply bind_good v _ _ _ _ _ _ (repair_shares (J:=Slot n) (by simp) hn v rec U us uk posU _ targets.1 targets.2 α floor)
  intro o h
  have inside (q) : (o.part q).points ⊆ U.points := fun x hx => (h.cover x).2 ⟨q,hx⟩
  have alone (i q) := (du i).mono_right (inside q)
  have sp (j k) (hk : k<n) := pack_separate d o j k hk (ds j) h.sep (fun q => alone j (some q))
    (fun a b ne => h.disj _ _ (fun e => ne (Option.some.inj e)))
  have records : correct v (full d o) o.record := fun i j =>
    pack_known d o j m v (fun a e he => h.keep a e (dk j a e he)) h.known i
  have bounds (i j k) (hk : k<n) :
      val (v i) (d j) + (big α n + k*(2*α)-α/2)*M i ≤ val (v i) (pack d o j k) ∧
      val (v i) (pack d o j k) ≤ val (v i) (d j) + (big α n + k*(2*α))*M i := by
    have eq := total_pack d o j k hk (mass (v i))
    rw [total_eq_measure _ _ (sp j k hk),total_eq_measure _ _ (ds j)] at eq
    have b := h.subsets i (slots j k)
    rw [slot_sum j α k hk] at b
    simp only [normalized,massU,← mul_sum] at b
    rw [inv_mul_eq_div] at b
    have l := (le_div_iff₀ (pos i)).mp b.1
    have r := (div_le_iff₀ (pos i)).mp b.2
    unfold val
    rw [eq]
    exact ⟨add_le_add_left l _,add_le_add_left r _⟩
  apply bind_good v _ _ _ _ _ _ (CertifiedTrim.protocol_good (full d o) o.record v records)
  intro a ha
  let S := fun j => suffix (a.mark j)
  let T := fun j => trimmings (a.mark j)
  let P := full d o
  have split (j) := partition (a.mark j) (sp j m mn)
  have ssub (j) : (S j).points ⊆ (P j).points := (split j).1 ▸ Set.subset_union_right
  have tsub (j) : (T j).points ⊆ (P j).points := (split j).1 ▸ Set.subset_union_left
  have V (i j) : val (v i) (S j) = a.value j i :=
    (suffix_value _ _ (sp j m mn)).symm.trans (ha.1 j i).symm
  have ef (j k) : val (v (a.holder j)) (S k) ≤ val (v (a.holder j)) (S j) := by
    rw [V,V]; exact ha.2.1 j k
  have prot := Buffered.protect m size (fun j => d j ++ o.part (some (j,0)))
    (fun j k => if hh : k+1<n then o.part (some (j,⟨k+1,hh⟩)) else []) a.mark
    (fun j => sp j m mn) a.holder a.rank v ef (fun j =>
      (ha.2.2 j).imp id (fun ⟨q,lt,e⟩ => ⟨q,lt,(V _ _).trans (e.trans (V _ _).symm)⟩)) (by
        intro i j k hk
        have lower := (bounds i i (k+1) (by omega)).1
        have upper := (bounds i j k (by omega)).2
        have g := envy i j
        change val (v i) (d j) ≤ val (v i) (d i) + α*M i at g
        change val (v i) (pack d o j k) < val (v i) (pack d o i (k+1))
        push_cast at lower
        nlinarith only [lower,upper,g,mul_pos positive (pos i)])
  have protectedTail (j) : (pack d o j 0).points ⊆ (S j).points := prot j
  have intact (j) : (d j).points ⊆ (S j).points := by
    apply Set.Subset.trans _ (protectedTail j)
    rw [pack,Buffered.tail,Buffered.append_points]; exact Set.subset_union_left
  have slotsIn (j : Fin n) (q : Slot n) : q ∈ slots j m ↔ q.1 = j := by
    simp only [slots,mem_filter,Finset.mem_univ,true_and,and_iff_left_iff_imp]
    intro _; have := q.2.isLt; omega
  have packMem (j x) : x ∈ (P j).points ↔ x ∈ (d j).points ∨ ∃ q : Slot n, q.1=j ∧ x ∈ (o.part (some q)).points := by
    change x ∈ (pack d o j m).points ↔ _
    rw [pack_points _ _ _ _ mn]; simp only [Set.mem_union,Set.mem_setOf_eq,slotsIn]
  have inU (j) : (P j).points ⊆ (d j).points ∪ U.points := by
    intro x hit
    rcases (packMem j x).1 hit with old | ⟨q,_,h⟩
    · exact Or.inl old
    · exact Or.inr (inside _ h)
  have pd (j k) (ne : j ≠ k) : Disjoint (P j).points (P k).points := by
    apply Set.disjoint_left.mpr
    intro x l r
    rcases (packMem j x).1 l with old | ⟨p,pj,hit⟩ <;> rcases (packMem k x).1 r with old' | ⟨q,qk,hit'⟩
    · exact Set.disjoint_left.mp (dd j k ne) old old'
    · exact Set.disjoint_left.mp (alone j _) old hit'
    · exact Set.disjoint_left.mp (alone k _) old' hit
    · exact Set.disjoint_left.mp (h.disj _ _ (fun eq => ne (pj.symm.trans ((congrArg Prod.fst (Option.some.inj eq)).trans qk)))) hit hit'
  have p0 (j) : Disjoint (P j).points (o.part none).points := by
    apply Set.disjoint_left.mpr
    intro x l r
    rcases (packMem j x).1 l with old | ⟨q,_,hit⟩
    · exact Set.disjoint_left.mp (alone j _) old r
    · exact Set.disjoint_left.mp (h.disj _ _ (by simp)) hit r
  let R := o.part none ++ CoreProtocol.join T
  have Rmem (x) : x ∈ R.points ↔ x ∈ (o.part none).points ∨ ∃ j, x ∈ (T j).points := by
    simp only [R,Buffered.append_points,CoreProtocol.join_points,Set.mem_union,mem_iUnion]
  have sdis (j k) (ne : j ≠ k) := (pd j k ne).mono (ssub j) (ssub k)
  have tdis (j k) (ne : j ≠ k) := (pd j k ne).mono (tsub j) (tsub k)
  have sR (j) : Disjoint (S j).points R.points := by
    apply Set.disjoint_left.mpr
    intro x hit rx
    rcases (Rmem x).1 rx with z | ⟨k,tk⟩
    · exact Set.disjoint_left.mp (p0 j) (ssub j hit) z
    · by_cases eq : j=k
      · subst k; exact Set.disjoint_left.mp (split j).2 tk hit
      · exact Set.disjoint_left.mp (pd j k eq) (ssub j hit) (tsub k tk)
  have cov (x) : (x ∈ U.points ∨ ∃ j, x ∈ (d j).points) ↔ (x ∈ R.points ∨ ∃ j, x ∈ (S j).points) := by
    have pieces : (x ∈ U.points ∨ ∃ j, x ∈ (d j).points) ↔ x ∈ (o.part none).points ∨ ∃ j, x ∈ (P j).points := by
      constructor
      · rintro (u | ⟨j,hj⟩)
        · obtain ⟨q,z⟩ := (h.cover x).1 u
          cases q with
          | none => exact Or.inl z
          | some q => exact Or.inr ⟨q.1,(packMem _ _).2 (Or.inr ⟨q,rfl,z⟩)⟩
        · exact Or.inr ⟨j,(packMem _ _).2 (Or.inl hj)⟩
      · rintro (z | ⟨j,pj⟩)
        · exact Or.inl (inside _ z)
        · rcases inU j pj with old | u
          · exact Or.inr ⟨j,old⟩
          · exact Or.inl u
    rw [pieces,Rmem]
    have splitMem (j) : x ∈ (P j).points ↔ x ∈ (T j).points ∨ x ∈ (S j).points := by rw [← (split j).1]; rfl
    constructor
    · rintro (z|⟨j,hit⟩)
      · exact Or.inl (Or.inl z)
      · rcases (splitMem j).1 hit with l|r
        · exact Or.inl (Or.inr ⟨j,l⟩)
        · exact Or.inr ⟨j,r⟩
    · rintro ((z|⟨j,l⟩)|⟨j,r⟩)
      · exact Or.inl z
      · exact Or.inr ⟨j,(splitMem j).2 (Or.inl l)⟩
      · exact Or.inr ⟨j,(splitMem j).2 (Or.inr r)⟩
  have subR : R.points ⊆ U.points := by
    intro x rx
    rcases (cov x).2 (Or.inl rx) with u | ⟨j,dj⟩
    · exact u
    · exact False.elim (Set.disjoint_left.mp (sR j) (intact j dj) rx)
  have adds (i j) :
      (big α n-α/2)*M i ≤ val (v i) (S j) - val (v i) (d j) ∧
      val (v i) (S j) - val (v i) (d j) ≤ (big α n+m*(2*α))*M i := by
    letI := (v i).finite
    have a := (bounds i j 0 (by omega)).1.trans (measureReal_mono (protectedTail j))
    have b := (measureReal_mono (ssub j)).trans (bounds i j m mn).2
    change val (v i) (S j) ≤ _ at b
    change _ ≤ val (v i) (S j) at a
    simp only [Nat.cast_zero,zero_mul,add_zero] at a
    constructor <;> linarith
  have small (i) : val (v i) R ≤ 2*(n:ℝ)^2*α*M i := by
    letI := (v i).finite
    let D := ⋃ j, (d j).points
    let A := ⋃ j, (S j).points
    have sets : U.points ∪ D = R.points ∪ A := by ext x; simpa [D,A] using cov x
    have aaa : Disjoint R.points A := Set.disjoint_iUnion_right.mpr (fun j => (sR j).symm)
    have ddd : Disjoint U.points D := Set.disjoint_iUnion_right.mpr (fun j => (du j).symm)
    have eq := congrArg (v i).measure.real sets
    rw [measureReal_union ddd (MeasurableSet.iUnion (fun _ => measurable_points _)),
        measureReal_union aaa (MeasurableSet.iUnion (fun _ => measurable_points _))] at eq
    simp only [A,D,measureReal_iUnion_fintype (μ:=(v i).measure) (fun _ _ => dd _ _) (fun _ => measurable_points _),
      measureReal_iUnion_fintype (μ:=(v i).measure) (fun _ _ => sdis _ _) (fun _ => measurable_points _)] at eq
    have lower := Finset.sum_le_sum (s:=univ) (fun j _ => (adds i j).1)
    simp only [sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul,sum_sub_distrib] at lower
    change M i + ∑ j, val (v i) (d j) = val (v i) R + ∑ j, val (v i) (S j) at eq
    have const : (n:ℝ)*big α n = 1-(n:ℝ)*((n:ℝ)-1)*(2*α) := by unfold big; field_simp
    have extra := mul_nonneg (mul_nonneg nr.le positive.le) (pos i).le
    nlinarith only [lower,eq,congrArg (· * M i) const,extra]
  apply bind_good v _ _ _ _ (n*(2*n)) 0 (by simpa using CoreProtocol.recordAll_good P v a o.record univ.toList records)
  rintro rr ⟨keep,all⟩
  apply (good_ret ..).2
  have eqHeld (j) : (assemble d o a rr).held ((assemble d o a rr).holder j) = S j := by
    change S (a.holder.symm (a.holder j)) = S j
    rw [Equiv.symm_apply_apply]
  refine ⟨?_,fun j => by rw [eqHeld]; exact intact j,fun j => by rw [eqHeld]; exact (ssub j).trans (inU j),
    subR,fun i => suffix_separate _ (sp _ m mn),?_,?_,fun i => sR (a.holder.symm i),?_,
    preserves_trans h.keep keep,fun i => (all _).1,?_,?_,small⟩
  · intro i j; letI := (v i).finite
    apply (ENNReal.toReal_le_toReal (measure_ne_top _ _) (measure_ne_top _ _)).mp
    change val (v i) (S (a.holder.symm j)) ≤ val (v i) (S (a.holder.symm i))
    simpa only [Equiv.apply_symm_apply] using ef (a.holder.symm i) (a.holder.symm j)
  · apply append_separate _ _ (h.sep none) (CoreProtocol.join_separate T (fun j => trimmings_separate _ (sp j m mn)) tdis)
    rw [CoreProtocol.join_points]; exact Set.disjoint_iUnion_right.mpr (fun j => (p0 j).symm.mono_right (tsub j))
  · intro i j ne; exact sdis _ _ (fun eq => ne (a.holder.symm.injective eq))
  · intro x; rw [cov]
    change _ ↔ x ∈ R.points ∨ ∃ i, x ∈ (S (a.holder.symm i)).points
    constructor
    · rintro (rx|⟨j,hj⟩)
      · exact Or.inl rx
      · exact Or.inr ⟨a.holder j,by simpa using hj⟩
    · rintro (rx|⟨i,hi⟩)
      · exact Or.inl rx
      · exact Or.inr ⟨_,hi⟩
  · intro i e he
    rcases List.mem_append.mp he with old | cut
    · exact keep i e (h.known none i e old)
    · obtain ⟨j,_,hj⟩ := List.mem_flatMap.mp cut; exact (all j).2 i e hj
  · intro i j l
    rw [eqHeld,eqHeld]
    change (val (v i) (S j) - _) - (val (v i) (S l) - _) ≤ 2*n*α*M i
    have b := (adds i j).2
    rw [mr] at b
    nlinarith only [b,(adds i l).1,mul_pos positive (pos i)]

end
end CakeCutting.RepairProtocol
