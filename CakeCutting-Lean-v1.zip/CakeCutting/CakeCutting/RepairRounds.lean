import CakeCutting.CoreProtocol

/-! Weighted physical splits for unequal original valuations, and an explicit
precision schedule for the smallest tolerance Reassign can return. -/
namespace CakeCutting.RepairRounds
open Finset Components DecisionTree AdaptiveTrim BoundaryRecords MeasureTheory
noncomputable section
variable {n : ℕ} [NeZero n]

def aggregate (v : Fin n → Valuation) (scale : Fin n → ℝ) (s : Bundle) :=
  ∑ i, scale i * total (mass (v i)) s

def balancedScaled (s : Bundle) (rec : Records n) (scale : Fin n → ℝ) : Tree n (Mark s) :=
  let W := fun i => max 0 (scale i * total (rec i) s)
  bind (TableProtocol.read (fun i => cut i (rec i) (total (rec i) s/2) s) (emptyMark s) univ.toList) fun marks =>
    .ret (marks (Classical.choose (CommonShares.weighted_median marks W (fun _ => le_max_left ..))))

theorem scaled_good (v : Fin n → Valuation) (s : Bundle) (rec : Records n) (scale : Fin n → ℝ)
    (nonneg : ∀ i, 0 ≤ scale i) (ok : Known v rec s) :
    Good v (fun p => let mass := ∑ i, scale i * retained (v i) p
      mass ≤ 3*aggregate v scale s / 4 ∧ aggregate v scale s - mass ≤ 3*aggregate v scale s / 4)
      n (balancedScaled s rec scale) := by
  classical
  let w := fun i => total (rec i) s
  have recEq (i) : w i = total (mass (v i)) s := recorded_total _ _ _ (ok i)
  have wn (i) : 0 ≤ w i := by
    rw [recEq]
    exact List.sum_nonneg (fun x h => by obtain ⟨a,_,rfl⟩ := List.mem_map.mp h; exact measureReal_nonneg)
  let g := fun i => max 0 (scale i * w i)
  let f := fun i => scale i * w i
  have gf : g = f := funext (fun i => max_eq_right (mul_nonneg (nonneg i) (wn i)))
  apply bind_good v (fun t : Fin n → Mark s => ∀ i, retained (v i) (t i) = w i / 2) _ _ _ n 0
  · have ask (i) := cut_good v i (rec i) (w i/2) (by have := wn i; linarith) s
        (show w i/2 ≤ w i by have := wn i; linarith) (ok i)
    simpa using TableProtocol.collect_good v _ (fun i p => retained (v i) p = w i/2)
      (emptyMark s) univ.toList (fun i _ => ask i)
  · intro t half
    let m := Classical.choose (CommonShares.weighted_median t g (fun _ => le_max_left ..))
    have spec := Classical.choose_spec (CommonShares.weighted_median t g (fun _ => le_max_left ..))
    change (∑ i, g i)/2 ≤ ∑ i ∈ univ.filter (fun i => t i ≤ t m), g i ∧
      (∑ i, g i)/2 ≤ ∑ i ∈ univ.filter (fun i => t m ≤ t i), g i at spec
    rw [gf] at spec
    have bounds := CommonShares.bounds_at t f (fun i p => scale i * retained (v i) p)
      (fun i _ _ le => mul_le_mul_of_nonneg_left (monotone_retained _ _ le) (nonneg i))
      (fun i => by change scale i * retained (v i) (t i) = _; rw [half]; dsimp [f]; ring)
      (fun i p => mul_nonneg (nonneg i) (by
        have h := monotone_retained (v i) s (mark_range s p).1
        rwa [(endpoint_values ..).1] at h))
      (fun i p => mul_le_mul_of_nonneg_left (by
        have h := monotone_retained (v i) s (mark_range s p).2
        rwa [(endpoint_values ..).2,← recEq] at h) (nonneg i)) m spec
    apply (good_ret ..).2
    simpa only [aggregate,f,recEq,sum_sub_distrib] using bounds

structure Split (n : ℕ) where
  left : Bundle
  right : Bundle
  record : Records n

def split (s : Bundle) (rec : Records n) (scale : Fin n → ℝ) : Tree n (Split n) :=
  bind (balancedScaled s rec scale) fun p => bind (refresh rec (boundary p)) fun T =>
    .ret ⟨trimmings p,suffix p,T⟩

structure SplitOK (v : Fin n → Valuation) (s : Bundle) (rec : Records n) (scale : Fin n → ℝ)
    (out : Split n) : Prop where
  cover : out.left.points ∪ out.right.points = s.points
  separate : Disjoint out.left.points out.right.points
  leftSep : Separate out.left
  rightSep : Separate out.right
  keep : Preserves v rec out.record
  leftKnown : Known v out.record out.left
  rightKnown : Known v out.record out.right
  mass : ∀ i, total (Components.mass (v i)) out.left + total (Components.mass (v i)) out.right =
    total (Components.mass (v i)) s
  leftMass : aggregate v scale out.left ≤ 3*aggregate v scale s/4
  rightMass : aggregate v scale out.right ≤ 3*aggregate v scale s/4

theorem split_good (v : Fin n → Valuation) (s : Bundle) (rec : Records n) (scale : Fin n → ℝ)
    (nonneg : ∀ i, 0 ≤ scale i) (sep : Separate s) (ok : Known v rec s) :
    Good v (SplitOK v s rec scale) (3*n) (split s rec scale) := by
  rw [show 3*n = n + 2*n by omega]
  apply bind_good v _ _ _ _ _ _ (scaled_good v s rec scale nonneg ok)
  intro p bounds
  apply bind_good v _ _ _ _ (2*n) 0 (boundary_good v rec p ok)
  rintro T ⟨keep,rk,lk⟩
  apply (good_ret ..).2
  obtain ⟨cov,dis⟩ := partition p sep
  have rv (i) : total (mass (v i)) (suffix p) = retained (v i) p :=
    (total_eq_measure (v i) _ (suffix_separate p sep)).trans (suffix_value _ p sep).symm
  have account (i) := split_mass (v i) p sep
  have left (i) : total (mass (v i)) (trimmings p) = total (mass (v i)) s - retained (v i) p :=
    eq_sub_of_add_eq (account i)
  refine ⟨cov,dis,trimmings_separate p sep,suffix_separate p sep,keep,lk,rk,
    fun i => by simpa only [rv] using account i,?_,?_⟩
  · change aggregate v scale (trimmings p) ≤ _
    simpa only [aggregate,left,mul_sub,sum_sub_distrib] using bounds.2
  · change aggregate v scale (suffix p) ≤ _
    simpa only [aggregate,rv] using bounds.1

/-- A state-independent number of refinement rounds, with logarithmic
dependence on the denominator, specialized to Repair's n-squared slots. -/
def blocks (n : ℕ) := (2*n+8)*((2*n).log2+1)
def rounds (n : ℕ) := 3*blocks n

omit [NeZero n] in
theorem precision (hn : 2 ≤ n) (α : ℝ)
    (floor : 1/(4*(n:ℝ)^2)^(n+1) ≤ α) :
    (n:ℝ)^4 * (3/4 : ℝ)^rounds n ≤ α/2 := by
  let L := (2*n).log2+1
  let d := (2*n+8)*L
  have powN : (2*n:ℕ) ≤ 2^L := (Nat.lt_log2_self (n:=2*n)).le
  have p2 : 2*(n:ℝ) ≤ 2^L := by exact_mod_cast powN
  have p1 : (n:ℝ) ≤ 2^L := by linarith
  let K := 4*(n:ℝ)^2
  have kpos : 0 < K := by
    have np : (0:ℝ) < n := by exact_mod_cast (by omega : 0 < n)
    dsimp [K]; positivity
  have Kb : K ≤ (2^L : ℝ)^2 := by nlinarith [pow_le_pow_left₀ (by positivity : 0 ≤ 2*(n:ℝ)) p2 2]
  have major : 2*(n:ℝ)^4 * K^(n+1) ≤ (2:ℝ)^d := by
    have Lpos : 1 ≤ L := by dsimp [L]; omega
    have e : 4*L+2*L*(n+1)+1 ≤ d := by
      change _ ≤ (2*n+8)*L
      have e1 : 4*L+2*L*(n+1)+1 = 2*n*L+6*L+1 := by ring
      rw [e1,Nat.add_mul]; omega
    calc
      _ ≤ 2*((2:ℝ)^L)^4 * (((2:ℝ)^L)^2)^(n+1) :=
        mul_le_mul (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) p1 4) (by norm_num))
          (pow_le_pow_left₀ kpos.le Kb _) (by positivity) (by positivity)
      _ = (2:ℝ)^(4*L+2*L*(n+1)+1) := by
        rw [← pow_mul,← pow_mul,← pow_mul]
        rw [pow_succ,pow_add]; ring_nf
      _ ≤ _ := pow_le_pow_right₀ (by norm_num) e
  have contraction : (3/4:ℝ)^rounds n ≤ (1/2:ℝ)^d := by
    rw [rounds,pow_mul]; exact pow_le_pow_left₀ (by norm_num) (by norm_num) _
  have bound : (n:ℝ)^4 / (2:ℝ)^d ≤ 1 / K^(n+1) / 2 := by
    apply (div_le_iff₀ (by positivity)).mpr
    field_simp [ne_of_gt (pow_pos kpos (n+1))]
    nlinarith only [major]
  calc
    _ ≤ (n:ℝ)^4 * (1/2:ℝ)^d := mul_le_mul_of_nonneg_left contraction (by positivity)
    _ = _ / (2:ℝ)^d := by rw [div_pow,one_pow,← mul_div_assoc,mul_one]
    _ ≤ 1 / K^(n+1) / 2 := bound
    _ ≤ _ := by linarith

end
end CakeCutting.RepairRounds
