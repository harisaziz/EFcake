import CakeCutting.Phase
import Mathlib.Data.Finset.Sigma
import Mathlib.Data.Finset.Prod

/-! Explicit query addresses for the two shared tables of a round. -/

namespace CakeCutting.SharedTables

open Finset CakeCutting.Quantiles CakeCutting.Relaxation

variable {A K I V : Type*} [Fintype A] [Nonempty A] [Fintype K]
  [Fintype I] [LinearOrder V]

/-- Each block k contains a row for each observer and a column for each
distinct selected value. A candidate's identity never appears in an address. -/
def addresses (u : K → A → V) (g : ℕ) : Finset (Sigma (fun _ : K => I × V)) :=
  univ.sigma (fun k => (univ : Finset I).product (grid (u k) g))

theorem address_count (u : K → A → V) (g : ℕ) :
    (addresses (I := I) u g).card ≤ Fintype.card K * (Fintype.card I * g) := by
  classical
  simp only [addresses, card_sigma]
  simpa using sum_le_sum (s := (univ : Finset K)) (fun k _ =>
    Nat.mul_le_mul_left (Fintype.card I) (grid_card (u k) g))

theorem requested_address (u : K → A → V) (g : ℕ) (hg : 0 < g) (a : A) (k : K) (i : I) :
    Sigma.mk k (i, roundUp (u k) g hg a) ∈ addresses u g := by
  classical
  exact mem_sigma.mpr ⟨mem_univ _, mem_product.mpr ⟨mem_univ _, (roundUp_spec (u k) g hg a).1⟩⟩

/-- Budget for four q passes and the final trial table. The inverse table
can include the pin for this upper bound. Known endpoint values can also
be counted in the budget. -/
theorem phase_budget {R C W : Type*} [Fintype R] [Fintype C] [LinearOrder W]
    (q : ℕ) (hq : 0 < q) (hr : Fintype.card R = q) (hc : Fintype.card C = q+1)
    (col : ℕ → C → A → V) (row : ℕ → R → A → W) :
    let g := 8*(2*q+1)
    (∑ t ∈ range (4*q), ((addresses (I := R) (col t) g).card +
      (addresses (I := C) (row t) g).card)) + q*(q+1) ≤ 386*q^4 := by
  let g := 8*(2*q+1)
  have each (t : ℕ) : (addresses (I := R) (col t) g).card +
      (addresses (I := C) (row t) g).card ≤ 2*(q*(q+1)*g) := by
    have h := Nat.add_le_add (address_count (I := R) (col t) g)
      (address_count (I := C) (row t) g)
    rw [hr,hc] at h
    convert h using 1
    ring
  have s := sum_le_sum (s := range (4*q)) (fun t _ => each t)
  simp only [sum_const, card_range, Nat.nsmul_eq_mul] at s
  apply (Nat.add_le_add_right s _).trans
  have h1 : q+1 ≤ 2*q := by omega
  have h2 : 8*(2*q+1) ≤ 24*q := by omega
  have hh := Nat.mul_le_mul (Nat.mul_le_mul_left q h1) h2
  have ht := Nat.mul_le_mul_left (4*q) (Nat.mul_le_mul_left 2 hh)
  have last : q*(q+1) ≤ 2*q^4 := by
    have h := Nat.mul_le_mul_left q h1
    have hpow : q^2 ≤ q^4 := Nat.pow_le_pow_right hq (by decide)
    nlinarith only [h,hpow]
  exact (Nat.add_le_add ht last).trans (by ring_nf; omega)

end CakeCutting.SharedTables
