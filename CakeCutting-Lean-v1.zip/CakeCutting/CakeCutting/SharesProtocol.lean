import CakeCutting.Refinement

/-! Repeated sparse refinement and the physical assignment of integral
cells. All mixed cells are discarded into one explicitly recorded residue. -/
namespace CakeCutting.SharesProtocol
open Finset Set MeasureTheory Components BoundaryRecords AdaptiveTrim DecisionTree RepairRounds Refinement
noncomputable section
variable {n : ℕ} [NeZero n] {E J : Type} [Fintype E] [DecidableEq E] [Fintype J] [DecidableEq J] [Nonempty J]

def support (z : E → J → ℝ) (e : E) := univ.filter (fun j => 0 < z e j)
def slot (z : E → J → ℝ) (e : E) : Option J := by
  classical
  exact if mixedCell : e ∈ mixed z then none else if pos : (support z e).Nonempty then
    some (Classical.choose pos) else none

omit [DecidableEq J] [Nonempty J] in
theorem slot_spec (z : E → J → ℝ) (pos : ∀ e j, 0 ≤ z e j) (rows : ∀ e, ∑ j, z e j = 1) (e : E) :
    (slot z e = none ↔ e ∈ mixed z) ∧
      ∀ j, slot z e = some j → z e j = 1 := by
  classical
  let S := support z e
  have ne : S.Nonempty := by
    by_contra! no
    have all (j) : z e j = 0 := le_antisymm (le_of_not_gt (fun h => no ⟨j,mem_filter.mpr ⟨Finset.mem_univ _,h⟩⟩)) (pos e j)
    have bad := rows e; simp [all] at bad
  by_cases m : e ∈ mixed z
  · simp [slot,m]
  · have size : S.card ≤ 1 := le_of_not_gt (fun gt => m (mem_filter.mpr ⟨Finset.mem_univ _,gt⟩))
    have pick := Classical.choose_spec ne
    have ne' : (support z e).Nonempty := ne
    simp only [slot,dif_neg m,dif_pos ne',Option.some_ne_none,Option.some.injEq,false_iff]
    refine ⟨m,?_⟩
    intro j eq; subst j
    have unique {j} (hj : j ∈ S) : j = Classical.choose ne :=
      Finset.card_le_one.mp size j hj _ pick
    have other (j) (hj : j ≠ Classical.choose ne) : z e j = 0 :=
      le_antisymm (le_of_not_gt (fun h => hj (unique (mem_filter.mpr ⟨Finset.mem_univ _,h⟩)))) (pos e j)
    have sum := Finset.sum_eq_single (Classical.choose ne) (s:=univ) (f:=z e)
      (fun j _ hn => other j hn) (by simp)
    exact sum.symm.trans (rows e)

def region (cells : E → Bundle) (z : E → J → ℝ) (j : Option J) : Bundle :=
  CoreProtocol.join (fun e => if slot z e = j then cells e else [])

structure Result (n : ℕ) (J : Type) where
  part : Option J → Bundle
  record : Records n

structure Spec (v : Fin n → Valuation) (input : Records n) (U : Bundle)
    (scale : Fin n → ℝ) (target : Fin n → J → ℝ) (error : ℝ) (out : Result n J) : Prop where
  sep : ∀ j, Separate (out.part j)
  disj : ∀ j k, j ≠ k → Disjoint (out.part j).points (out.part k).points
  cover : ∀ x, x ∈ U.points ↔ ∃ j, x ∈ (out.part j).points
  keep : Preserves v input out.record
  know : ∀ j, Known v out.record (out.part j)
  upper : ∀ i j, total (mass (v i)) (out.part (some j)) ≤ target i j
  residue : aggregate v scale (out.part none) ≤ error

omit [NeZero n] [Nonempty J] in
private theorem finalize (v : Fin n → Valuation) (rec : Records n) (U : Bundle) (cells : E → Bundle)
    (p : E → J → ℝ) (scale : Fin n → ℝ) 
    (target : Fin n → J → ℝ) (cap : ℝ) (hc : 0 ≤ cap) (f : Family v rec U scale target cap cells p) :
    let z := sparse (weight rec cells) p
    Spec v rec U scale target ((n*Fintype.card J : ℕ)*cap) ⟨region cells z,rec⟩ := by
  classical
  let z := sparse (weight rec cells) p
  have thin := sparse_ok (weight rec cells) p f.pos f.row
  have sel := slot_spec z thin.1 thin.2.2.1
  let pick (j : Option J) (e : E) : Bundle := if slot z e = j then cells e else []
  have sub (j e) : (pick j e).points ⊆ (cells e).points := by
    dsimp [pick]; split
    · exact Subset.rfl
    · rw [empty_points]; exact empty_subset _
  have dis (j a b) (ne : a ≠ b) : Disjoint (pick j a).points (pick j b).points :=
    (f.disjoint _ _ ne).mono (sub _ _) (sub _ _)
  have sp (j) : Separate (region cells z j) := CoreProtocol.join_separate (pick j)
    (fun e => by dsimp [pick]; split <;> first | exact f.separate e | exact List.Pairwise.nil) (dis j)
  have region_mem (x j) : x ∈ (region cells z j).points ↔ ∃ e, slot z e = j ∧ x ∈ (cells e).points := by
    rw [region,CoreProtocol.join_points,mem_iUnion]
    constructor
    · rintro ⟨e,hit⟩
      by_cases eq : slot z e = j
      · exact ⟨e,eq,by simpa only [if_pos eq] using hit⟩
      · simp [eq,empty_points] at hit
    · rintro ⟨e,eq,hit⟩; exact ⟨e,by simpa [eq] using hit⟩
  have massEq (i j) : total (mass (v i)) (region cells z j) =
      ∑ e ∈ univ.filter (fun e => slot z e = j), total (mass (v i)) (cells e) := by
    letI := (v i).finite
    rw [total_eq_measure _ _ (sp j),region,CoreProtocol.join_points,
      measureReal_iUnion_fintype (fun _ _ => dis j _ _) (fun _ => measurable_points _),sum_filter]
    apply sum_congr rfl
    intro e _
    by_cases eq : slot z e = j
    · simpa [pick,eq] using (total_eq_measure (v i) _ (f.separate e)).symm
    · simp [pick,eq,empty_points]
  refine ⟨sp,?_,?_,preserves_refl _ _,?_,?_,?_⟩
  · intro j k ne
    apply Set.disjoint_left.mpr
    intro x jx kx
    obtain ⟨e,ej,ex⟩ := (region_mem x j).1 jx
    obtain ⟨a,ak,ax⟩ := (region_mem x k).1 kx
    by_cases eq : e = a
    · subst a; exact ne (ej.symm.trans ak)
    · exact Set.disjoint_left.mp (f.disjoint _ _ eq) ex ax
  · intro x; rw [f.cover x]; constructor
    · rintro ⟨e,ex⟩; exact ⟨slot z e,(region_mem ..).2 ⟨e,rfl,ex⟩⟩
    · rintro ⟨j,hit⟩; obtain ⟨e,_,ex⟩ := (region_mem x j).1 hit; exact ⟨e,ex⟩
  · intro j i a ha
    obtain ⟨e,_,hit⟩ := List.mem_flatMap.mp ha
    change a ∈ (if slot z e = j then cells e else []) at hit
    by_cases eq : slot z e = j
    · exact f.known e i a (by simpa [eq] using hit)
    · simp [eq] at hit
  · intro i j
    change total _ (region cells z _) ≤ _
    rw [massEq,sum_filter]
    have wt (a e) : weight rec cells a e = total (mass (v a)) (cells e) := recorded_total _ _ _ (f.known e a)
    have exact' := thin.2.2.2.1 i j
    simp only [wt] at exact'
    rw [← f.exactValue i j,← exact']
    apply sum_le_sum
    intro e _
    change (if slot z e = some j then _ else _) ≤ z e j * _
    by_cases eq : slot z e = some j
    · simp [eq,(sel e).2 j eq]
    · simp only [if_neg eq]
      exact mul_nonneg (thin.1 e j) (by rw [total_eq_measure _ _ (f.separate e)]; exact measureReal_nonneg)
  · let H := mixed z
    have res : univ.filter (fun e => slot z e = none) = H := by ext e; simp [H,(sel e).1]
    change (∑ i, scale i * total _ (region cells z none)) ≤ _
    simp_rw [massEq,res,mul_sum]
    rw [sum_comm]
    have sub := mixed_mono thin.2.1
    calc
      _ ≤ ∑ _e ∈ H, cap := sum_le_sum (fun e he => f.shared e (sub he))
      _ = (H.card:ℝ)*cap := by simp
      _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast thin.2.2.2.2) hc

def iterate (k : ℕ) {E J : Type} [Fintype E] [DecidableEq E] [Fintype J] [DecidableEq J]
    (cells : E → Bundle) (p : E → J → ℝ) (rec : Records n) (scale : Fin n → ℝ) :
    Tree n (Result n J) := by
  classical
  let z := sparse (weight rec cells) p
  let S := mixed z
  match k with
  | 0 => exact .ret ⟨region cells z,rec⟩
  | k+1 => exact bind (many cells rec scale S.toList) fun cut =>
      iterate k (children S cut) (fun e => z (parent S e)) cut.record scale

omit [Nonempty J] in
theorem iterate_good (k : ℕ) : ∀ {E : Type} [Fintype E] [DecidableEq E]
    (v : Fin n → Valuation) (rec : Records n) (U : Bundle) (cells : E → Bundle)
    (p : E → J → ℝ) (scale : Fin n → ℝ) (_hn : ∀ i, 0 ≤ scale i)
    (target : Fin n → J → ℝ) (cap : ℝ) (_hc : 0 ≤ cap) (_f : Family v rec U scale target cap cells p),
    Good v (Spec v rec U scale target ((n*Fintype.card J : ℕ)*((3/4:ℝ)^k*cap)))
      (k*((n*Fintype.card J)*(3*n))) (iterate k cells p rec scale) := by
  induction k with
  | zero =>
    intro E _ _ v rec U cells p scale hn target cap hc f
    apply (good_ret ..).2
    simpa [iterate] using finalize v rec U cells p scale target cap hc f
  | succ k ih =>
    intro E _ _ v rec U cells p scale hn target cap hc f
    let z := sparse (weight rec cells) p
    let S := mixed z
    rw [Nat.succ_mul,Nat.add_comm (k * _)]; rw [iterate]
    apply bind_good v _ _ _ _ _ _ (round_good v rec U cells p scale hn target cap f)
    rintro cut ⟨keep,inv⟩
    have next := ih v cut.record U (children S cut) (fun e => z (parent S e)) scale hn target
      (3*cap/4) (by positivity) inv
    apply OracleTree.strengthen _ _ _ _ _ next
    intro out done
    have e : (3/4:ℝ)^k * (3*cap/4) = (3/4:ℝ)^(k+1)*cap := by rw [pow_succ]; ring
    rw [e] at done
    exact {done with keep := preserves_trans keep done.keep}

end
end CakeCutting.SharesProtocol
