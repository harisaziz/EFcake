import CakeCutting.Realization

/-! Bidirectional incremental extension of registered pairs. A forward request
fixes its input key globally and inserts a fresh output key. The same
ordered-pair lemma applied to the reversed graph handles inverse requests. -/
namespace CakeCutting.Transcript
open Finset
open scoped NNReal
variable {K V P : Type*} [LinearOrder K] [LinearOrder V] [DenselyOrdered V] [LinearOrder P]

/-- Extending a partial monotone map to the whole line by repeating the image
of the last registered key to the left, or the first image below all keys. -/
theorem complete_map (S : Finset K) (hS : S.Nonempty) (g : K → P) (hg : MonotoneOn g S) :
    ∃ G : K → P, Monotone G ∧ ∀ x ∈ S, G x = g x := by
  classical
  let lower (x : K) := S.filter (· ≤ x)
  let a := S.min' hS
  let key (x : K) := if h : (lower x).Nonempty then (lower x).max' h else a
  have inside (x : K) : key x ∈ S := by
    dsimp [key]; split
    · exact (mem_filter.mp (max'_mem ..)).1
    · exact min'_mem .. 
  have mono : Monotone key := by
    intro x y xy
    by_cases hx : (lower x).Nonempty
    · obtain ⟨z,hz⟩ := hx.exists_mem
      have sub : lower x ⊆ lower y := fun b hb =>
        mem_filter.mpr ⟨(mem_filter.mp hb).1,(mem_filter.mp hb).2.trans xy⟩
      have hy : (lower y).Nonempty := ⟨z,sub hz⟩
      simp only [key,dif_pos hx,dif_pos hy]
      exact le_max' _ _ (sub (max'_mem ..))
    · simp only [key,dif_neg hx]
      exact min'_le _ _ (inside y)
  refine ⟨fun x => g (key x),fun _ _ h => hg (inside _) (inside _) (mono h),?_⟩
  intro x hx
  have yes : x ∈ lower x := mem_filter.mpr ⟨hx,le_rfl⟩
  have ne : (lower x).Nonempty := ⟨x,yes⟩
  have h : key x = x := by
    simp only [key,dif_pos ne]
    exact le_antisymm (mem_filter.mp (max'_mem (lower x) ne)).2 (le_max' _ _ yes)
  exact congrArg g h

/-- For a fresh queried first coordinate strictly between stored endpoints,
register any prescribed physical image bracketed by its two local neighbors.
The returned second key is fresh in the *global* second-key table. The new
total monotone map agrees on every old global key, including other pairs'.
The updated pair graph stays strictly ordered. -/
theorem extend_pair (S : Finset K) (T : Finset V) (y : K → V)
    (strict : StrictMonoOn y S) (registered : ∀ x ∈ S, y x ∈ T)
    (H : V → P) (mon : Monotone H) (x : K) (_fresh : x ∉ S)
    (lo : ∃ a ∈ S, a < x) (hi : ∃ b ∈ S, x < b)
    (u : P) (left : ∀ a ∈ S, a < x → H (y a) ≤ u)
    (right : ∀ b ∈ S, x < b → u ≤ H (y b)) :
    ∃ k ∉ T, ∃ G : V → P, Monotone G ∧ (∀ t ∈ T, G t = H t) ∧ G k = u ∧
      StrictMonoOn (Function.update y x k) (insert x S : Finset K) := by
  classical
  let L := S.filter (· < x)
  let U := S.filter (x < ·)
  obtain ⟨a,ha,al⟩ := lo
  obtain ⟨b,hb,xb⟩ := hi
  let l := L.max' (⟨a,mem_filter.mpr ⟨ha,al⟩⟩ : L.Nonempty)
  let r := U.min' (⟨b,mem_filter.mpr ⟨hb,xb⟩⟩ : U.Nonempty)
  have hl : l ∈ L := max'_mem .. 
  have hr : r ∈ U := min'_mem .. 
  obtain ⟨hlS,hlx⟩ := mem_filter.mp hl
  obtain ⟨hrS,hxr⟩ := mem_filter.mp hr
  obtain ⟨k,hk,hlk,hkr,valid⟩ := insert_key T H (mon.monotoneOn _) (y l) (y r)
    (registered l hlS) (registered r hrS) (strict hlS hrS (hlx.trans hxr)) u
    (left l hlS hlx) (right r hrS hxr)
  obtain ⟨G,hG,hagree⟩ := complete_map (insert k T) (insert_nonempty ..) _ valid
  refine ⟨k,hk,G,hG,fun t ht => ?_,?_,?_⟩
  · have ne : t ≠ k := fun eq => hk (eq ▸ ht)
    simpa [Function.update_of_ne ne] using hagree t (mem_insert_of_mem ht)
  · simpa using hagree k (mem_insert_self ..)
  · intro s hs t ht st
    by_cases sx : s = x
    · subst s
      have tx := st.ne'
      have htS := (mem_insert.mp ht).resolve_left tx
      have le : r ≤ t := min'_le _ _ (mem_filter.mpr ⟨htS,st⟩ : t ∈ U)
      simpa [Function.update_of_ne tx] using hkr.trans_le (strict.monotoneOn hrS htS le)
    · by_cases tx : t = x
      · subst t
        have hsS := (mem_insert.mp hs).resolve_left sx
        have le : s ≤ l := le_max' _ _ (mem_filter.mpr ⟨hsS,st⟩ : s ∈ L)
        simpa [Function.update_of_ne sx] using (strict.monotoneOn hsS hlS le).trans_lt hlk
      · simpa [Function.update_of_ne sx,Function.update_of_ne tx] using
          strict ((mem_insert.mp hs).resolve_left sx) ((mem_insert.mp ht).resolve_left tx) st

/-- Forward simulation uses the physical image at the shared length, so it
needs only the value of that suffix. The same coordinate remains valid in
every agent's row. -/
theorem forward_entry {Q : Type*} [LinearOrder Q] (S T : Finset ℝ≥0) (y : ℝ≥0 → ℝ≥0)
    (strict : StrictMonoOn y S) (registered : ∀ z ∈ S, y z ∈ T)
    (φ : ℝ≥0 → Q) (ψ : ℝ≥0 → P) (F : Q → P)
    (hφ : Monotone φ) (hψ : Monotone ψ) (hF : Monotone F)
    (record : ∀ z ∈ S, F (φ z) = ψ (y z)) (x : ℝ≥0) (fresh : x ∉ S)
    (lo : ∃ a ∈ S, a < x) (hi : ∃ b ∈ S, x < b) :
    ∃ k ∉ T, ∃ G : ℝ≥0 → P, Monotone G ∧ (∀ t ∈ T, G t = ψ t) ∧ G k = F (φ x) ∧
      StrictMonoOn (Function.update y x k) (insert x S : Finset ℝ≥0) := by
  apply extend_pair S T y strict registered ψ hψ x fresh lo hi
  · intro a ha lt; rw [← record a ha]; exact hF (hφ lt.le)
  · intro b hb lt; rw [← record b hb]; exact hF (hφ lt.le)

/-- An inverse request takes a physical cut answer and clamps it between
the nearest locally registered positions. All older global physical
positions are preserved, and the clamped cut has the requested amount. -/
theorem inverse_entry {Q : Type*} [LinearOrder Q] (S T : Finset ℝ≥0) (x : ℝ≥0 → ℝ≥0)
    (strict : StrictMonoOn x S) (registered : ∀ z ∈ S, x z ∈ T)
    (ψ : ℝ≥0 → P) (φ : ℝ≥0 → Q) (F : Q → P)
    (hψ : Monotone ψ) (hφ : Monotone φ) (hF : Monotone F)
    (record : ∀ z ∈ S, F (φ (x z)) = ψ z) (t : ℝ≥0) (fresh : t ∉ S)
    (lo : ∃ a ∈ S, a < t) (hi : ∃ b ∈ S, t < b) (p : Q) (cut : F p = ψ t) :
    ∃ k ∉ T, ∃ G : ℝ≥0 → Q, Monotone G ∧ (∀ z ∈ T, G z = φ z) ∧ F (G k) = ψ t ∧
      StrictMonoOn (Function.update x t k) (insert t S : Finset ℝ≥0) := by
  classical
  let L := S.filter (· < t)
  let U := S.filter (t < ·)
  obtain ⟨a,ha,al⟩ := lo
  obtain ⟨b,hb,tb⟩ := hi
  let l := L.max' (⟨a,mem_filter.mpr ⟨ha,al⟩⟩ : L.Nonempty)
  let r := U.min' (⟨b,mem_filter.mpr ⟨hb,tb⟩⟩ : U.Nonempty)
  have hl : l ∈ L := max'_mem .. 
  have hr : r ∈ U := min'_mem .. 
  obtain ⟨hlS,hlt⟩ := mem_filter.mp hl
  obtain ⟨hrS,htr⟩ := mem_filter.mp hr
  let u := max (φ (x l)) (min p (φ (x r)))
  have val : F u = ψ t := clamp F hF (by rw [record l hlS]; exact hψ hlt.le)
    (by rw [record r hrS]; exact hψ htr.le) cut
  have br : φ (x l) ≤ φ (x r) := hφ (strict.monotoneOn hlS hrS (hlt.trans htr).le)
  obtain ⟨k,hk,G,hm,old,new,order⟩ := extend_pair S T x strict registered φ hφ t fresh
    ⟨a,ha,al⟩ ⟨b,hb,tb⟩ u (by
      intro z hz hzt
      exact (hφ (strict.monotoneOn hz hlS (le_max' _ _ (mem_filter.mpr ⟨hz,hzt⟩ : z ∈ L)))).trans
        (le_max_left ..)) (by
      intro z hz htz
      exact (max_le br (min_le_right ..)).trans
        (hφ (strict.monotoneOn hrS hz (min'_le _ _ (mem_filter.mpr ⟨hz,htz⟩ : z ∈ U)))))
  exact ⟨k,hk,G,hm,old,new ▸ val,order⟩

end CakeCutting.Transcript
