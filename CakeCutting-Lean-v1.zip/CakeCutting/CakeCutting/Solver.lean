import CakeCutting.Phase
import CakeCutting.SharedTables
import Mathlib.Data.Fintype.Perm

/-! Iteration on shrinking sets of assignments. No hidden vector is an
argument of the solver. The count is for phases. SharedTables bounds the
number of table entries in each phase. -/
namespace CakeCutting.Solver
open Finset CakeCutting.Matching CakeCutting.Relaxation CakeCutting.Quantiles

variable {A R C V W : Type*} [DecidableEq A] [Fintype R] [Fintype C]
  [Nonempty C] [DecidableEq C] [DecidableEq R]
  [LinearOrder V] [OrderTop V] [LinearOrder W]

inductive Outcome (A C V R : Type*) where
  | done (y : C → V) (m : R → C)
  | again (pool : Finset A)

noncomputable def phase (f : R → C → V ≃o W) (pin : C) (p : V)
    (M : A → Assignment R C pin) (s : Finset A) (hs : s.Nonempty) :
    Outcome A C V R := by
  classical
  letI : Nonempty s := hs.to_subtype
  let q := Fintype.card R
  let g := 8*(2*q+1)
  let u := Phase.estimates f g (by dsimp [g]; omega) pin p (fun a : s => M a) (4*q)
  let y := fun j => quantile (fun a => u a j) 2 1 (by decide)
  match test (tight (table (fun i j v => f i j v) y)) pin (tight_nonempty _) with
  | .matching m => exact .done y m
  | .short k => exact .again ((univ.filter (fun a : s => y k < u a k)).image Subtype.val)

def Supports (f : R → C → V ≃o W) (pin : C) (M : A → Assignment R C pin) (x : C → V) (a : A) :=
  ∀ i, (M a).col i ∈ tight (table (fun i j v => f i j v) x) i

theorem phase_spec (f : R → C → V ≃o W) (pin : C) (p : V)
    (M : A → Assignment R C pin) (x : C → V) (s : Finset A) (hs : s.Nonempty)
    (hp : x pin = p) (hq : 0 < Fintype.card R) (hd : Fintype.card C = Fintype.card R + 1)
    (hex : FullyExposable (tight (table (fun i j v => f i j v) x))) :
    match phase f pin p M s hs with
    | .done y m => y = x ∧ Function.Injective m ∧
      ∀ i, m i ∈ (tight (table (fun i j v => f i j v) x) i).erase pin
    | .again t => 2*t.card ≤ s.card ∧ ∀ a ∈ s, Supports f pin M x a → a ∈ t := by
  classical
  letI : Nonempty s := hs.to_subtype
  have h := Phase.test_and_filter f pin p (fun a : s => M a) x hp hq hd hex
  dsimp only at h
  let q := Fintype.card R
  let g := 8*(2*q+1)
  let u := Phase.estimates f g (by dsimp [g]; omega) pin p (fun a : s => M a) (4*q)
  let y := fun j => quantile (fun a => u a j) 2 1 (by decide)
  cases eqn : test (tight (table (fun i j v => f i j v) y)) pin (tight_nonempty _) <;>
    (unfold phase; dsimp only; rw [eqn]) <;> rw [eqn] at h
  · exact h
  · refine ⟨?_, fun a ha ht => ?_⟩
    · rw [card_image_of_injective _ Subtype.val_injective]
      simpa using h.2.2.2
    · exact mem_image.mpr ⟨⟨a,ha⟩,mem_filter.mpr ⟨mem_univ _, h.2.2.1 ⟨a,ha⟩ ht⟩,rfl⟩

noncomputable def run (f : R → C → V ≃o W) (pin : C) (p : V) (M : A → Assignment R C pin) :
    ℕ → Finset A → Option ((C → V) × (R → C))
  | 0, _ => none
  | k+1, s => if hs : s.Nonempty then
      match phase f pin p M s hs with
      | .done y m => some (y,m)
      | .again t => run f pin p M k t
    else none

/-- The actual sequence of phases terminates with the true vector within
one plus the binary logarithm of the initial pool size. -/
theorem correct (f : R → C → V ≃o W) (pin : C) (p : V)
    (M : A → Assignment R C pin) (x : C → V) (hp : x pin = p)
    (hq : 0 < Fintype.card R) (hd : Fintype.card C = Fintype.card R + 1)
    (hex : FullyExposable (tight (table (fun i j v => f i j v) x)))
    (s : Finset A) (has : ∃ a ∈ s, Supports f pin M x a) :
    ∃ m, run f pin p M (s.card.log2+1) s = some (x,m) ∧ Function.Injective m ∧
      ∀ i, m i ∈ (tight (table (fun i j v => f i j v) x) i).erase pin := by
  suffices aux : ∀ k (s : Finset A), (∃ a ∈ s, Supports f pin M x a) → s.card < 2^k →
      ∃ m, run f pin p M k s = some (x,m) ∧ Function.Injective m ∧
        ∀ i, m i ∈ (tight (table (fun i j v => f i j v) x) i).erase pin from
    aux _ s has Nat.lt_log2_self
  intro k
  induction k with
  | zero =>
    rintro s ⟨a, ha, _⟩ small
    have := card_pos.mpr (show s.Nonempty from ⟨a,ha⟩)
    rw [pow_zero] at small
    omega
  | succ k ih =>
    rintro s ⟨a,ha,hsup⟩ small
    have hs : s.Nonempty := ⟨a,ha⟩
    have spec := phase_spec f pin p M x s hs hp hq hd hex
    simp only [run, dif_pos hs]
    cases e : phase f pin p M s hs with
    | done y m =>
      rw [e] at spec
      exact ⟨m, by rw [spec.1], spec.2⟩
    | again t =>
      rw [e] at spec
      have ac := spec.1
      rw [pow_succ] at small
      exact ih t ⟨a,spec.2 a ha hsup,hsup⟩ (by omega)

/-- Turn each bijection to ordinary columns into a candidate. The row
attached to the pin is never queried by the update. -/
noncomputable def candidate [Nonempty R] (pin : C) (e : R ≃ {j : C // j ≠ pin}) :
    Assignment R C pin where
  col i := (e i).val
  row j := if h : j ≠ pin then e.symm ⟨j,h⟩ else Classical.choice inferInstance
  avoids i := (e i).property
  left_inv i := by simp [(e i).property]
  right_inv j h := by simp [h]

/-- Initially every bijection is present. Full exposability alone supplies
a supporting candidate, so the caller need not know its identity. -/
theorem all_assignments [Nonempty R] (f : R → C → V ≃o W) (pin : C) (p : V)
    (x : C → V) (hp : x pin = p) (hd : Fintype.card C = Fintype.card R + 1)
    (hex : FullyExposable (tight (table (fun i j v => f i j v) x))) :
    ∃ m, run f pin p (candidate (R := R) pin) ((Fintype.card R).factorial.log2+1) univ =
      some (x,m) ∧ Function.Injective m ∧
      ∀ i, m i ∈ (tight (table (fun i j v => f i j v) x) i).erase pin := by
  classical
  obtain ⟨m, hm, ht⟩ := hex pin
  let m' : R → {j : C // j ≠ pin} := fun i => ⟨m i,(mem_erase.mp (ht i)).1⟩
  have hc : Fintype.card R = Fintype.card {j : C // j ≠ pin} := by
    rw [Fintype.card_subtype_compl (· = pin), hd]
    simp
  have bij : Function.Bijective m' := (Fintype.bijective_iff_injective_and_card _).2
    ⟨fun _ _ h => hm (congrArg Subtype.val h),hc⟩
  let e := Equiv.ofBijective m' bij
  have result := correct f pin p (candidate (R := R) pin) x hp Fintype.card_pos hd hex univ
    ⟨e, mem_univ _, fun i => (mem_erase.mp (ht i)).2⟩
  simpa [Fintype.card_equiv e] using result

/-- Converting the factorial pool size into the explicit polynomial-log query
budget. Each phase's shared-table entries are counted by phase_budget. -/
theorem total_table_budget (q : ℕ) (hq : 0 < q) :
    (q.factorial.log2+1)*(386*q^4) ≤ 772*q^5*((2*q).log2+1) := by
  have hqpow : q ≤ 2^((2*q).log2+1) := by
    have := Nat.lt_log2_self (n := 2*q)
    omega
  have hpow := (Nat.factorial_le_pow q).trans (Nat.pow_le_pow_left hqpow q)
  rw [← Nat.pow_mul] at hpow
  have hlog := (Nat.le_log2 (Nat.factorial_pos q).ne').1 (le_refl q.factorial.log2)
  have bound : q.factorial.log2 ≤ ((2*q).log2+1)*q := by
    exact (Nat.pow_le_pow_iff_right (by decide : 1 < 2)).mp (hlog.trans hpow)
  have extra : 1 ≤ ((2*q).log2+1)*q :=
    Nat.mul_pos (Nat.succ_pos _) hq
  calc
    _ ≤ (2*(((2*q).log2+1)*q))*(386*q^4) := Nat.mul_le_mul_right _ (by omega)
    _ = _ := by ring

end CakeCutting.Solver
