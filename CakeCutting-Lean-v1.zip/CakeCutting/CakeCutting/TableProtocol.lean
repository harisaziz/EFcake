import CakeCutting.OracleTables
import CakeCutting.DecisionTree

/-! Specialization of the shared-table solver to physical decision trees. -/
namespace CakeCutting.TableProtocol
open Finset DecisionTree Relaxation
variable {n : ℕ} {I B : Type} [DecidableEq I]

noncomputable abbrev read (ask : I → Tree n B) (default : B) : List I → Tree n (I → B) :=
  OracleTables.read ask default

theorem collect_good (v : Fin n → Valuation) (ask : I → Tree n B) (pred : I → B → Prop)
    (default : B) (entries : List I) (ok : ∀ i ∈ entries, Good v (pred i) 1 (ask i)) :
    Good v (fun t => ∀ i ∈ entries, pred i (t i)) entries.length (read ask default entries) :=
  OracleTables.collect_good (Valid v) ask pred default entries ok

theorem read_good (v : Fin n → Valuation) (ask : I → Tree n B) (truth : I → B)
    (default : B) (entries : List I) (ok : ∀ i ∈ entries, Good v (· = truth i) 1 (ask i)) :
    Good v (fun t => ∀ i ∈ entries, t i = truth i) entries.length (read ask default entries) :=
  OracleTables.read_good (Valid v) ask truth default entries ok

abbrev Access (n : ℕ) (R C V W : Type) := OracleTables.Access (@Query.Answer n) R C V W

variable {A R C V W : Type} [Fintype A] [Nonempty A] [DecidableEq A]
  [Fintype R] [Fintype C] [Nonempty C] [DecidableEq R] [DecidableEq C]
  [LinearOrder V] [OrderTop V] [LinearOrder W] [OrderTop W]

abbrev Answers (v : Fin n → Valuation) (port : Access n R C V W) (f : R → C → V ≃o W) :=
  OracleTables.Answers (Valid v) port f

noncomputable abbrev oneRound (port : Access n R C V W) (g : ℕ) (hg : 0 < g)
    (pin : C) (M : A → Assignment R C pin) (u : A → C → V) : Tree n (A → C → V) :=
  OracleTables.oneRound port g hg pin M u

abbrev roundCost := OracleTables.roundCost

omit [DecidableEq A] in
theorem oneRound_good (v : Fin n → Valuation) (port : Access n R C V W)
    (f : R → C → V ≃o W) (answers : Answers v port f) (g : ℕ) (hg : 0 < g)
    (pin : C) (M : A → Assignment R C pin) (u : A → C → V) :
    Good v (· = update f g hg pin M u) (roundCost (Fintype.card R) (Fintype.card C) g)
      (oneRound port g hg pin M u) :=
  OracleTables.oneRound_good (Valid v) port f answers g hg pin M u

noncomputable abbrev rounds (port : Access n R C V W) (g : ℕ) (hg : 0 < g) (pin : C)
    (p : V) (M : A → Assignment R C pin) : ℕ → Tree n (A → C → V) :=
  OracleTables.rounds port g hg pin p M

omit [DecidableEq A] in
theorem rounds_good (v : Fin n → Valuation) (port : Access n R C V W) (f : R → C → V ≃o W)
    (answers : Answers v port f) (g : ℕ) (hg : 0 < g) (pin : C) (p : V)
    (M : A → Assignment R C pin) (k : ℕ) :
    Good v (· = Phase.estimates f g hg pin p M k)
      (k*roundCost (Fintype.card R) (Fintype.card C) g) (rounds port g hg pin p M k) :=
  OracleTables.rounds_good (Valid v) port f answers g hg pin p M k

noncomputable abbrev phaseTree (port : Access n R C V W) (pin : C) (p : V)
    (M : A → Assignment R C pin) (s : Finset A) (hs : s.Nonempty) :
    Tree n (Solver.Outcome A C V R) :=
  OracleTables.phaseTree port pin p M s hs

omit [Fintype A] [Nonempty A] in
theorem phaseTree_good (v : Fin n → Valuation) (port : Access n R C V W) (f : R → C → V ≃o W)
    (answers : Answers v port f) (pin : C) (p : V) (M : A → Assignment R C pin)
    (s : Finset A) (hs : s.Nonempty) (hq : 0 < Fintype.card R)
    (dim : Fintype.card C = Fintype.card R + 1) :
    Good v (· = Solver.phase f pin p M s hs) (386*(Fintype.card R)^4)
      (phaseTree port pin p M s hs) :=
  OracleTables.phaseTree_good (Valid v) port f answers pin p M s hs hq dim

noncomputable abbrev runTree (port : Access n R C V W) (pin : C) (p : V)
    (M : A → Assignment R C pin) : ℕ → Finset A → Tree n (Option ((C → V) × (R → C))) :=
  OracleTables.runTree port pin p M

omit [Fintype A] [Nonempty A] in
theorem runTree_good (v : Fin n → Valuation) (port : Access n R C V W) (f : R → C → V ≃o W)
    (answers : Answers v port f) (pin : C) (p : V) (M : A → Assignment R C pin)
    (hq : 0 < Fintype.card R) (dim : Fintype.card C = Fintype.card R + 1) (k : ℕ) (s : Finset A) :
    Good v (· = Solver.run f pin p M k s) (k*(386*(Fintype.card R)^4))
      (runTree port pin p M k s) :=
  OracleTables.runTree_good (Valid v) port f answers pin p M hq dim k s

end CakeCutting.TableProtocol
