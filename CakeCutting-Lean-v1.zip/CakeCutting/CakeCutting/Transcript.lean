import CakeCutting.PositiveTrim

/-! Finite ordered maps and projection in the zero-value transcript lemma. -/

namespace CakeCutting.Transcript
open Finset
open scoped NNReal

/-- Inserting a fresh virtual key with a prescribed physical image between
two existing keys. The map may identify any number of old keys. -/
theorem insert_key {K P : Type*} [LinearOrder K] [DenselyOrdered K] [LinearOrder P]
    (S : Finset K) (H : K → P) (hH : MonotoneOn H S)
    (a b : K) (ha : a ∈ S) (hb : b ∈ S) (hab : a < b) (u : P)
    (hlo : H a ≤ u) (hhi : u ≤ H b) :
    ∃ k ∉ S, a < k ∧ k < b ∧
      MonotoneOn (Function.update H k u) (insert k S : Finset K) := by
  classical
  let L := S.filter (fun x => x < b ∧ H x ≤ u)
  let l := L.max' (⟨a,mem_filter.mpr ⟨ha,hab,hlo⟩⟩ : L.Nonempty)
  have hl : l ∈ L := max'_mem _ _
  have hlow := (mem_filter.mp hl).2
  let U := S.filter (fun x => l < x)
  let r := U.min' (⟨b,mem_filter.mpr ⟨hb,hlow.1⟩⟩ : U.Nonempty)
  have hr : r ∈ U := min'_mem _ _
  have hlr := (mem_filter.mp hr).2
  have hal : a ≤ l := le_max' _ _ (mem_filter.mpr ⟨ha,hab,hlo⟩ : a ∈ L)
  have hrb : r ≤ b := min'_le _ _ (mem_filter.mpr ⟨hb,hlow.1⟩ : b ∈ U)
  have upper : u ≤ H r := by
    by_cases rb : r = b
    · simpa [rb] using hhi
    · by_contra! h
      have : r ≤ l := le_max' _ _ (mem_filter.mpr
        ⟨(mem_filter.mp hr).1,lt_of_le_of_ne hrb rb,h.le⟩ : r ∈ L)
      exact hlr.not_ge this
  obtain ⟨k,hlk,hkr⟩ := exists_between hlr
  have gap (x) (hx : x ∈ S) : x ≤ l ∨ r ≤ x := by
    by_cases hh : x ≤ l
    · exact Or.inl hh
    · exact Or.inr (min'_le _ _ (mem_filter.mpr ⟨hx,lt_of_not_ge hh⟩ : x ∈ U))
  have hk : k ∉ S := by
    intro h; rcases gap k h with h | h
    · exact hlk.not_ge h
    · exact hkr.not_ge h
  refine ⟨k,hk,hal.trans_lt hlk,hkr.trans_le hrb,?_⟩
  intro s hs t ht hst
  by_cases sk : s = k <;> by_cases tk : t = k
  · exact le_of_eq (congrArg (Function.update H k u) (sk.trans tk.symm))
  · subst s
    have htS := (mem_insert.mp ht).resolve_left tk
    have hrt := (gap t htS).resolve_left (fun h => hlk.not_ge (hst.trans h))
    simpa [Function.update_of_ne tk] using upper.trans (hH (mem_filter.mp hr).1 htS hrt)
  · subst t
    have hsS := (mem_insert.mp hs).resolve_left sk
    have hsl := (gap s hsS).resolve_right (fun h => hkr.not_ge (h.trans hst))
    simpa [Function.update_of_ne sk] using (hH hsS (mem_filter.mp hl).1 hsl).trans hlow.2
  · simpa [Function.update_of_ne sk,Function.update_of_ne tk] using
      hH ((mem_insert.mp hs).resolve_left sk) ((mem_insert.mp ht).resolve_left tk) hst

/-- Even an adversarial cut on a flat region can be clamped to the physical
bracket without changing the reported mass. -/
theorem clamp {P X : Type*} [LinearOrder P] [LinearOrder X] (F : P → X) (mono : Monotone F)
    {l r p : P} {u : X} (hl : F l ≤ u) (hr : u ≤ F r) (hp : F p = u) :
    F (max l (min p r)) = u := by rw [mono.map_max,mono.map_min,hp,min_eq_left hr,max_eq_right hl]

/-- Transfer of the complete envy and certification inequalities through
the shared physical coordinates and agent-specific monotone value maps.
An empty piece is allowed: its map can be constant. -/
theorem project {R : Type*} [Fintype R] {P : R → Type*}
    (F : PositiveTrim.Values R) (x : R → ℝ≥0) (holder : R ≃ R)
    (rank : R ≃ Fin (Fintype.card R)) (p : ∀ j, P j) (whole : ∀ j, P j)
    (v : (j : R) → R → P j → ℝ≥0) (ψ : R → ℝ≥0 → ℝ≥0)
    (mon : ∀ a, Monotone (ψ a))
    (record : ∀ j a, v j a (p j) = ψ a (F j a (x j)))
    (hw : ∀ j, x j = 1 → p j = whole j)
    (ef : ∀ j k, F k (holder j) (x k) ≤ F j (holder j) (x j))
    (cert : ∀ j, x j = 1 ∨ ∃ i, rank i < rank j ∧
      F j (holder i) (x j) = F i (holder i) (x i)) :
    (∀ j k, v k (holder j) (p k) ≤ v j (holder j) (p j)) ∧
    ∀ j, p j = whole j ∨ ∃ i, rank i < rank j ∧
      v j (holder i) (p j) = v i (holder i) (p i) := by
  refine ⟨fun j k => ?_,fun j => ?_⟩
  · simpa only [record] using mon (holder j) (ef j k)
  · rcases cert j with h | ⟨i,lt,eqn⟩
    · exact Or.inl (hw j h)
    · exact Or.inr ⟨i,lt,by rw [record,record,eqn]⟩

end CakeCutting.Transcript
