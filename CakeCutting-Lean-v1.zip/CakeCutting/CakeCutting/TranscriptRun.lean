import CakeCutting.AdaptiveTrim
import CakeCutting.OracleTables

/-! Adaptive simulation for every finite virtual query program. Validity of
an entire physical run is established against a single profile of curves. -/
namespace CakeCutting.TranscriptRun
open Finset Registry AdaptiveTrim DecisionTree
open scoped NNReal
noncomputable section
variable {n : ℕ}
abbrev Profile (n : ℕ) := PositiveTrim.Values (Fin n)
structure Fits (s : Pieces n) (rec : Records n) (B : State s) (F : Profile n) : Prop where
  table : ∀ j i p, p ∈ B.graph j i → F j i p.1 = p.2
  tail : ∀ j i x, 1 ≤ x → F j i x = topKey s rec j i + (x-1)

theorem fits_old {s : Pieces n} {rec B T F} (ext : Extends B T) (f : Fits s rec T F) :
    Fits s rec B F := ⟨fun j i _ hp => f.table _ _ _ (ext.keep j i hp),f.tail⟩

theorem realizable (s : Pieces n) (rec : Records n) (v : Fin n → Valuation) (B : State s)
    (sound : Sound s rec v B) : ∃ F, Fits s rec B F := by
  classical
  have each (j i) : ∃ f : N ≃o N,
      (∀ p ∈ B.graph j i, f p.1 = p.2) ∧ ∀ x ≥ 1, f x = topKey s rec j i + (x-1) := by
    let S := (B.graph j i).image Prod.fst
    let y (x : N) := if h : ∃ t, (x,t) ∈ B.graph j i then Classical.choose h else 0
    obtain ⟨base,last⟩ := anchors sound j i
    have read (p) (hp : p ∈ B.graph j i) : y p.1 = p.2 := by
      have ex : ∃ t, (p.1,t) ∈ B.graph j i := ⟨p.2,hp⟩
      simpa [y,ex] using (sound.valid.ordered _ _ _ (Classical.choose_spec ex) _ hp).2.mp rfl
    have pair (x) (hx : x ∈ S) : (x,y x) ∈ B.graph j i := by
      obtain ⟨p,hp,rfl⟩ := mem_image.mp hx; simpa [read _ hp] using hp
    obtain ⟨f,_,known,tail⟩ := Transcript.realize_curve S y (read _ base)
      (mem_image_of_mem _ base) (mem_image_of_mem _ last)
      (fun x hx => (sound.bounded _ _ _ (pair x hx)).1)
      (fun x hx z hz xz => (sound.valid.ordered _ _ _ (pair x hx) _ (pair z hz)).1.mp xz)
    refine ⟨f,fun p hp => ((known _ (mem_image_of_mem _ hp)).1).trans (read _ hp),?_⟩
    intro x hx
    apply NNReal.eq
    have h := tail x hx
    rw [show y 1 = topKey s rec j i from read _ last] at h
    simpa [NNReal.coe_sub hx] using h
  choose f hh using each
  exact ⟨f,fun j i => (hh j i).1,fun j i => (hh j i).2⟩

inductive Request (n : ℕ) where
  | eval (j i : Fin n) (x : N)
  | cut (j i : Fin n) (y : N)

abbrev Virtual (n : ℕ) (α : Type) := OracleTree.Tree (fun _ : Request n => N) α

def answer (F : Profile n) : Request n → N
  | .eval j i x => F j i x
  | .cut j i y => (F j i).symm y

def agrees (F : Profile n) (q : Request n) (a : N) := a = answer F q

def serve (s : Pieces n) (rec : Records n) (B : State s) : Request n → Tree n (N × State s)
  | .eval j i x => if x ≤ 1 then queryF s rec B j i x else .ret (topKey s rec j i + (x-1),B)
  | .cut j i y => if y ≤ topKey s rec j i then queryI s rec B j i y else .ret (1+(y-topKey s rec j i),B)

def Reply (s : Pieces n) (rec : Records n) (v : Fin n → Valuation) (B : State s) (q : Request n)
    (a : N × State s) := Extends B a.2 ∧ Sound s rec v a.2 ∧ ∀ F, Fits s rec a.2 F → agrees F q a.1

theorem serve_good (s : Pieces n) (rec : Records n) (v : Fin n → Valuation) (ok : correct v s rec)
    (B : State s) (sound : Sound s rec v B) (q : Request n) :
    Good v (Reply s rec v B q) 1 (serve s rec B q) := by
  cases q with
  | eval j i x =>
    simp only [serve]
    split
    next h =>
      apply OracleTree.strengthen _ _ _ _ _ (forward_good s rec v ok B sound j i x h)
      intro a ha
      exact ⟨ha.extends_old,ha.sound,fun F hf => (hf.table j i _ ha.entry).symm⟩
    next h =>
      exact (good_ret ..).2 ⟨extends_refl _,sound,fun F hf => (hf.tail j i x (le_of_not_ge h)).symm⟩
  | cut j i y =>
    simp only [serve]
    split
    next h =>
      apply OracleTree.strengthen _ _ _ _ _ (inverse_good s rec v ok B sound j i y h)
      intro a ha
      exact ⟨ha.extends_old,ha.sound,fun F hf => ((F j i).apply_eq_iff_eq_symm_apply _ _).mp (hf.table j i _ ha.entry)⟩
    next h =>
      apply (good_ret ..).2
      refine ⟨extends_refl _,sound,fun F hf => ((F j i).apply_eq_iff_eq_symm_apply _ _).mp ?_⟩
      rw [hf.tail _ _ _ (le_add_of_nonneg_right (zero_le _)),add_tsub_cancel_left,
        add_tsub_cancel_of_le (le_of_not_ge h)]

def interpret {α : Type} (s : Pieces n) (rec : Records n) :
    Virtual n α → State s → Tree n (α × State s)
  | .ret a,B => .ret (a,B)
  | .ask q g,B => bind (serve s rec B q) (fun z => interpret s rec (g z.1) z.2)

/-- Every physical run respects the virtual query bound. Every profile
realizing its final registry yields the same output and postcondition. -/
theorem interpret_good {α : Type} (s : Pieces n) (rec : Records n) (v : Fin n → Valuation)
    (ok : correct v s rec) (t : Virtual n α) (B : State s) (sound : Sound s rec v B)
    (post : Profile n → α → Prop) (k : ℕ)
    (valid : ∀ F, Fits s rec B F → OracleTree.Good (agrees F) (post F) k t) :
    Good v (fun z => Extends B z.2 ∧ Sound s rec v z.2 ∧ ∀ F, Fits s rec z.2 F → post F z.1)
      k (interpret s rec t B) := by
  induction t generalizing B k with
  | ret a =>
    exact (good_ret ..).2 ⟨extends_refl _,sound,fun F fit => (OracleTree.good_ret ..).1 (valid F fit)⟩
  | ask q next ih =>
    cases k with
    | zero =>
      obtain ⟨F,fit⟩ := realizable s rec v B sound
      exact False.elim (valid F fit)
    | succ k =>
      rw [Nat.add_comm k 1]
      apply bind_good v _ _ _ _ 1 k (serve_good s rec v ok B sound q)
      rintro ⟨a,B'⟩ ⟨ext,sound',answerOK⟩
      have step := ih a B' sound' k (fun F fit => (valid F (fits_old ext fit)).2 a (answerOK F fit))
      apply OracleTree.strengthen _ _ _ _ _ step
      rintro ⟨out,T⟩ ⟨more,ss,done⟩
      exact ⟨extends_trans ext more,ss,done⟩

end
end CakeCutting.TranscriptRun
