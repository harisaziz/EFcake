import CakeCutting.PhysicalCuts
import CakeCutting.DecisionTree
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith

/-! Complete four-query Robertson–Webb base case, allowing every legal
plateau answer and including the right endpoint in the actual allocation. -/
namespace CakeCutting.TwoAgents
open MeasureTheory Set CakeCutting.DecisionTree

private def lo : Point := ⟨0,by simp⟩
private def hi : Point := ⟨1,by simp⟩
private theorem lo_le (p : Point) : lo ≤ p := p.property.1
private theorem le_hi (p : Point) : p ≤ hi := p.property.2

private def left (p : Point) : Bundle := [⟨lo,p,lo_le _⟩]
private noncomputable def right (p : Point) : Bundle := if p = hi then [] else [⟨p,hi,le_hi _⟩]

private theorem left_set (p : Point) :
    (left p).points = if p = hi then univ else Iio p := by
  ext t
  by_cases h : p = hi
  · subst p
    simp [left,Bundle.points,Interval.points,lo_le,hi]
    exact le_iff_lt_or_eq.mp (le_hi t)
  · have hp : (p : ℝ) ≠ 1 := fun eq => h (Subtype.ext eq)
    rw [if_neg h]
    change (∃ a : Interval, a ∈ [⟨lo,p,lo_le _⟩] ∧ t ∈ a.points) ↔ t < p
    simp only [List.mem_singleton,exists_eq_left,Interval.points,mem_setOf_eq]
    simp [lo_le,hp]

private theorem right_set (p : Point) :
    (right p).points = if p = hi then ∅ else Ici p := by
  ext t
  by_cases h : p = hi
  · simp [h,right,Bundle.points]
  · have ht : t < hi ∨ t = hi := (le_hi t).lt_or_eq
    rw [if_neg h]
    simp only [right,if_neg h,Bundle.points,mem_setOf_eq,List.mem_singleton,exists_eq_left,
      Interval.points,mem_Ici]
    change (p ≤ t ∧ (t < hi ∨ t = hi ∧ (1:ℝ) = 1)) ↔ p ≤ t
    simp [ht]

private theorem disj (p : Point) : Disjoint (left p).points (right p).points := by
  rw [left_set,right_set]; split <;> simp [Set.disjoint_left]

private theorem covers (p t : Point) : t ∈ (left p).points ∨ t ∈ (right p).points := by
  rw [left_set,right_set]; by_cases h : p = hi <;> simp [h,lt_or_ge t p]

private theorem left_mass (v : Valuation) (p : Point) :
    v.measure (left p).points = v.measure (Icc lo p) := by
  letI := v.atomless
  rw [left_set]
  have hset : Icc lo p = Iic p := by ext t; simp [lo_le]
  rw [hset]
  by_cases hp : p = hi
  · subst p; simp [show Iic hi = univ by ext x; simp [le_hi]]
  · simp only [if_neg hp]
    exact measure_congr Iio_ae_eq_Iic

private theorem right_mass (v : Valuation) (p : Point) :
    v.measure (right p).points = v.measure (Icc p hi) := by
  letI := v.atomless
  rw [right_set]
  by_cases hp : p = hi
  · subst p; simp
  · have e : Icc p hi = Ici p := by ext t; simp [le_hi]
    simp [hp,e]

private theorem mass_add (v : Valuation) (p : Point) :
    v.measure.real (Icc lo p) + v.measure.real (Icc p hi) = v.measure.real (Icc lo hi) := by
  letI := v.finite
  have whole : (left p).points ∪ (right p).points = Icc lo hi := by
    ext t; simp only [mem_union,mem_Icc]; exact iff_of_true (covers p t) ⟨lo_le _,le_hi _⟩
  have ms : MeasurableSet (right p).points := by
    rw [right_set]; split <;> simp [measurableSet_Ici]
  unfold Measure.real
  rw [← left_mass v p, ← right_mass v p, ← whole, measure_union (disj p) ms,
    ENNReal.toReal_add (measure_ne_top _ _) (measure_ne_top _ _)]

private noncomputable def allocation (p : Point) (takesLeft : Bool) : Allocation 2 :=
  fun i => if i = 1 then
    (if takesLeft then left p else right p)
  else (if takesLeft then right p else left p)

private theorem decide_result (v : Fin 2 → Valuation) (p : Point)
    (equal : (v 0).measure.real (Icc lo p) = (v 0).measure.real (Icc p hi)) :
    let b := decide ((v 1).measure.real (Icc lo p) ≥ (v 1).measure.real (Icc p hi))
    Complete (allocation p b) ∧ EnvyFree v (allocation p b) := by
  have pref (a : Fin 2) : (v a).measure (left p).points ≤ (v a).measure (right p).points ↔
      (v a).measure.real (Icc lo p) ≤ (v a).measure.real (Icc p hi) := by
    letI := (v a).finite
    rw [left_mass,right_mass]
    exact (ENNReal.toReal_le_toReal (measure_ne_top _ _) (measure_ne_top _ _)).symm
  have eq0 : (v 0).measure (left p).points = (v 0).measure (right p).points := by
    letI := (v 0).finite
    rw [left_mass,right_mass]
    exact (ENNReal.toReal_eq_toReal (measure_ne_top _ _) (measure_ne_top _ _)).mp equal
  have pref' : (v 1).measure (right p).points ≤ (v 1).measure (left p).points ↔
      (v 1).measure.real (Icc p hi) ≤ (v 1).measure.real (Icc lo p) := by
    letI := (v 1).finite
    rw [left_mass,right_mass]
    exact (ENNReal.toReal_le_toReal (measure_ne_top _ _) (measure_ne_top _ _)).symm
  by_cases choose : (v 1).measure.real (Icc lo p) ≥ (v 1).measure.real (Icc p hi)
  · have chooser := pref'.2 choose
    simp only [choose,decide_true]
    refine ⟨⟨?_,?_⟩,?_⟩
    · intro i j h; fin_cases i <;> fin_cases j <;> simp_all [allocation,disj,Disjoint.symm (disj p)]
    · intro t; rcases covers p t with ht | ht
      · exact ⟨1,by simpa [allocation] using ht⟩
      · exact ⟨0,by simpa [allocation] using ht⟩
    · intro i j; fin_cases i <;> fin_cases j <;> simp_all [allocation]
  · have chooser := (pref 1).2 (le_of_not_ge choose)
    simp only [choose,decide_false]
    refine ⟨⟨?_,?_⟩,?_⟩
    · intro i j h; fin_cases i <;> fin_cases j <;> simp_all [allocation,disj,Disjoint.symm (disj p)]
    · intro t; rcases covers p t with ht | ht
      · exact ⟨0,by simpa [allocation] using ht⟩
      · exact ⟨1,by simpa [allocation] using ht⟩
    · intro i j; fin_cases i <;> fin_cases j <;> simp_all [allocation]

noncomputable def tree : Tree 2 (Allocation 2) :=
  .ask (.eval 0 lo hi) fun (total : ℝ) =>
    .ask (.cut 0 lo (total/2)) fun (p : Point) =>
      .ask (.eval 1 lo p) fun (l : ℝ) =>
        .ask (.eval 1 p hi) fun (r : ℝ) => .ret (allocation p (decide (l ≥ r)))

theorem protocol : ∃ P : Protocol 2, ∀ v, DeliversWithin P v 4 [] := by
  refine ⟨compile tree,fun v => start _ _ _ ?_⟩
  refine ⟨⟨_,lo_le _,rfl⟩,?_⟩
  rintro total ⟨_,rfl⟩
  let T := (v 0).measure.real (Icc lo hi)
  have nonneg : 0 ≤ T := measureReal_nonneg
  obtain ⟨c,hlo,_,hmark⟩ := PhysicalCuts.cut_exists (v 0) lo hi (lo_le _) (T/2)
    (by linarith) (by linarith)
  refine ⟨⟨c,hlo,hmark⟩,?_⟩
  rintro p ⟨_,hp⟩
  refine ⟨⟨_,lo_le _,rfl⟩,?_⟩
  rintro l ⟨_,rfl⟩
  refine ⟨⟨_,le_hi _,rfl⟩,?_⟩
  rintro r ⟨_,rfl⟩
  exact decide_result v p (by have h := mass_add (v 0) p; dsimp [T] at *; linarith)

end CakeCutting.TwoAgents
