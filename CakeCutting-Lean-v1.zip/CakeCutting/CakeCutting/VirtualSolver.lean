import CakeCutting.TranscriptRun

/-! The shared-table algorithm as a virtual query program. Recover each
actual suffix length by inverting the matched observer's value, and retain
the holder bijection. The program never takes the valuation curves as input. -/
namespace CakeCutting.VirtualSolver
open Registry TranscriptRun OracleTree Finset
open scoped NNReal
noncomputable section
variable {n : ℕ} [NeZero n]
abbrev I (n : ℕ) := Fin n
abbrev Level := WithTop N
abbrev Raw (n : ℕ) := Option ((Option (I n) → Level) × (I n → Option (I n)))
abbrev Result (n : ℕ) := (I n → N) × Equiv.Perm (I n)

def askOne (q : Request n) : Virtual n N := .ask q .ret

omit [NeZero n] in
theorem ask_good (F : Profile n) (q : Request n) :
    Good (agrees F) (· = answer F q) 1 (askOne q) :=
  ⟨⟨_,rfl⟩,fun _ h => (good_ret ..).2 h⟩

def liftQuery (q : N → Request n) (x : Level) : Virtual n Level :=
  x.recTopCoe (.ret ⊤) (fun t => bind (askOne (q t)) (fun y => .ret (↑y)))

def port : OracleTables.Access (fun _ : Request n => N) (I n) (Option (I n)) Level Level :=
  ⟨fun j i x => match i with
   | none => .ret x
   | some a => liftQuery (.cut j a) x,
   fun j i x => match i with
   | none => .ret x
   | some a => liftQuery (.eval j a) x⟩

def curves (F : Profile n) := CappedSquare.curves (fun j i => (F j i).symm)
  (fun _ => 1) (fun _ => zero_lt_one)

omit [NeZero n] in
theorem port_correct (F : Profile n) : OracleTables.Answers (agrees F) port (curves F) := by
  constructor
  · intro j i x
    cases i with
    | none =>
      apply (good_ret ..).2
      induction x using WithTop.recTopCoe with
      | top => rfl
      | coe z => change (z : Level) = ↑((1:N)*z); rw [one_mul]
    | some a =>
      induction x using WithTop.recTopCoe with
      | top => exact (good_ret ..).2 rfl
      | coe z =>
        apply bind_good _ _ _ _ _ 1 0 (ask_good F (.cut j a z))
        rintro _ rfl; exact (good_ret ..).2 rfl
  · intro j i x
    cases i with
    | none =>
      apply (good_ret ..).2
      apply ((curves F j none).apply_eq_iff_eq_symm_apply _ _).mp
      induction x using WithTop.recTopCoe with
      | top => rfl
      | coe z => change (↑((1:N)*z) : Level) = ↑z; rw [one_mul]
    | some a =>
      induction x using WithTop.recTopCoe with
      | top => exact (good_ret ..).2 rfl
      | coe z =>
        apply bind_good _ _ _ _ _ 1 0 (ask_good F (.eval j a z))
        rintro _ rfl; exact (good_ret ..).2 rfl

def recover (out : Raw n) : Virtual n (Result n) := by
  classical
  match out with
  | none => exact .ret (fun _ => 0,Equiv.refl _)
  | some (u,m) =>
    if ex : ∃ h : Equiv.Perm (I n), m = fun j => some (h j) then
      let h := Classical.choose ex
      exact bind (OracleTables.read (fun j => askOne (.cut j (h j) ((u (some (h j))).untopD 0)))
        0 univ.toList) fun x => .ret (x,h)
    else exact .ret (fun _ => 0,Equiv.refl _)

def fuel (n : ℕ) := n.factorial.log2 + 1
def budget (n : ℕ) := fuel n*(386*n^4) + n

def program : Virtual n (Result n) :=
  bind (OracleTables.runTree port none (↑(1:N)) (Solver.candidate (R := I n) none) (fuel n) univ) recover

def Certified (F : Profile n) (out : Result n) :=
  (∀ j, out.1 j ≤ 1) ∧
  (∀ j k, F k (out.2 j) (out.1 k) ≤ F j (out.2 j) (out.1 j)) ∧
  ∃ rank : I n ≃ Fin n, ∀ j, out.1 j = 1 ∨ ∃ a, rank a < rank j ∧
    F j (out.2 a) (out.1 j) = F a (out.2 a) (out.1 a)

theorem certified (F : Profile n) : Good (agrees F) (Certified F) (budget n) program := by
  classical
  obtain ⟨u,h,r,sol,bound,own,ef,cert⟩ := PositiveTrim.certified F
  let m := fun j => some (h j)
  have exact_out : Solver.run (curves F) none (↑(1:N)) (Solver.candidate (R := I n) none)
      (fuel n) univ = some (CappedSquare.levels u,m) := by simpa [fuel,I,curves,m] using sol
  have run := OracleTables.runTree_good (agrees F) port (curves F) (port_correct F) none (↑(1:N))
    (Solver.candidate (R := I n) none) Fintype.card_pos (by simp) (fuel n) univ
  rw [exact_out] at run
  unfold program budget
  apply bind_good _ _ _ _ _ _ n (by simpa [I] using run)
  rintro _ rfl
  have ex : ∃ w : Equiv.Perm (I n), m = fun j => some (w j) := ⟨h,rfl⟩
  have eqh : Classical.choose ex = h := by
    apply Equiv.ext
    intro j
    exact Option.some.inj (congrFun (Classical.choose_spec ex) j).symm
  simp only [recover,dif_pos ex,eqh,CappedSquare.levels,WithTop.untopD_coe]
  apply bind_good _ (fun z => ∀ j ∈ (univ : Finset (I n)).toList, z j = (F j (h j)).symm (u (h j))) _ _ _ n 0
  · simpa [I] using OracleTables.read_good (agrees F)
      (fun j => askOne (.cut j (h j) (u (h j)))) (fun j => (F j (h j)).symm (u (h j))) 0 univ.toList
      (fun j _ => ask_good F (.cut j (h j) (u (h j))))
  · intro z hz
    have eqz : z = PositiveTrim.lengths F u := funext (fun j => (hz j (by simp)).trans
      (((F j (h j)).apply_eq_iff_eq_symm_apply _ _).mp (own j)).symm)
    subst z
    apply (good_ret ..).2
    refine ⟨bound,fun j k => (ef k (h j)).trans_eq (own j).symm,?_⟩
    have rn : Fintype.card (I n) = n := by simp [I]
    exact ⟨r.trans (finCongr rn),fun j => by
      rcases cert j with full | ⟨a,lt,tie⟩
      · exact Or.inl full
      · exact Or.inr ⟨a,lt,tie⟩⟩

end
end CakeCutting.VirtualSolver
