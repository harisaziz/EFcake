# A deterministic polynomial-query protocol for envy-free cake cutting

Lean 4.24.0 formalization of the deterministic polynomial-query theorem.
The Lake manifest pins mathlib to `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`
and records its transitive dependencies.

**Lean proves the full main claim.** The theorem `CakeCutting.mainClaim_proof : CakeCutting.MainClaim` in
`CakeCutting/Divide.lean` gives a single absolute constant $C=3401$. For every $n\ge2$, its deterministic
Robertson–Webb protocol returns a complete envy-free division for every finite atomless valuation profile
and every valid sequence of oracle replies. Its query budget is
$3401 n^8(1+\lfloor\log_2(2n)\rfloor)$. The proposition in `Model.lean` is unchanged from the verified project.

## Reproduce the checks

From this directory, with the Lean toolchain manager installed, run

```sh
lake exe cache get $(sed -n 's/^import \(Mathlib\.[^ ]*\)$/\1/p' CakeCutting/*.lean | sort -u)
lake build
lake env lean CakeCutting/Audit.lean
```

The first command obtains precompiled mathlib dependencies for the imports in
this project. The last command checks the proof against the original proposition and prints its transitive axioms,
followed by the supporting results. The main proof uses `propext`, `Classical.choice`, and `Quot.sound`. The output from this revision is in
`verification/axioms.txt`. 

## The main statement

`CakeCutting.MainClaim` in `CakeCutting/Model.lean` states that one absolute
constant works for every population size. For each $n$ of at least two there
is one deterministic protocol for every valuation profile and every sequence
of valid replies. The protocol reads only its query-and-answer history. It
must ask feasible questions and return pairwise disjoint finite unions of
intervals that cover every point and satisfy all pairwise envy inequalities.
Valuations are finite measures on the Borel unit interval with zero mass at
every point. Query responses use exact reals and may choose any valid cut.
The explicit natural-number budget is `C * n^8 * (Nat.log2 (2*n) + 1)`.
Here `C` is independent of the population, the valuations and the replies.

## Manuscript correspondence

All declaration names below have the prefix `CakeCutting.`. The labels in
the first column are the LaTeX labels, so the correspondence survives changes
to printed numbering.

| Paper label | Lean declaration | Scope checked in this version |
|---|---|---|
| `thm:main` | `mainClaim_proof` | A compiled history-only strategy satisfies `MainClaim` with $C=3401$. |
| `pr:pinned`, `eq:strict-hall` | `Matching.fullyExposable_iff_strictHall`, `Equilibrium.greatest`, `Equilibrium.unique` | The tight matching condition is equivalent to strict Hall for nonempty rows. Any fully exposable vector is greatest among capped equilibria at the same pin level and is unique. `Exposure.exists_fullyExposable` proves existence for a square of order isomorphisms of the nonnegative reals with finite nonnegative caps. |
| `le:which` | `Matching.matchingTest` | A deterministic table-only test returns a supporting matching at the exact vector or a specific short ordinary column. The proof works for arbitrary linearly ordered level and cost types. |
| `le:median` | `Phase.median_phase`, `Quantiles.crossing_bound` | Starting from the pin and top ordinary estimates, after $4q$ actual rounded rounds at least five eighths of the candidates are below the truth on every coordinate, the lower median is below the truth, and supporting candidates retain upper bounds. As in the lemma, full exposability at the truth is assumed. |
| `alg:median`, `th:pinned` | `Phase.test_and_filter`, `SharedTables.requested_address`, `SharedTables.phase_budget`, `Bounds.failed_phases_le_log2` | A phase returns an exact matching or removes at least half the candidates while retaining every supporter. Every rounded request has an address in the shared tables. A phase including the trial table uses at most $386q^4$ entries, counting known endpoints and allowing the pin in both tables. The logarithmic bound on consecutive failures is proved separately. |
| `th:pinned`, `alg:median` | `Solver.all_assignments`, `CappedSquare.solve`, `Solver.total_table_budget`, `TableProtocol.runTree_good` | The solver starts with all bijections, finds the greatest capped equilibrium and a supporting matching for positive caps, and takes at most $1+\lfloor\log_2(q!)\rfloor$ phases. The shared-table decision tree has budget at most $772q^5(1+\lfloor\log_2(2q)\rfloor)$ if every accessor returns the corresponding curve value within one query. |
| `lem:trim`, positive case | `PositiveTrim.certified` | For strictly increasing extended suffix curves, recover actual retained lengths at most one, and a bijection and certifying order. All envy inequalities and witness ties are checked. |
| `le:transcript` | `AdaptiveTrim.forward_good`, `AdaptiveTrim.inverse_good`, `TranscriptRun.interpret_good` | Each adaptive query preserves the shared maps. Every final transcript admits a single realizing curve profile consistent with all earlier observations. |
| `lem:trim` | `VirtualSolver.certified`, `CertifiedTrim.protocol_good`, `CertifiedTrim.query_bound` | Physical trimming returns suffixes, a holder permutation, the full observed value table and a certifying order. The budget including the terminal reads is at most $774 n^5(1+\lfloor\log_2(2n)\rfloor)$. |
| Ordered component records | `Components.partition`, `BoundaryRecords.boundary_good`, `EqualPieces.divide_good` | A physical trim partitions every point, including endpoint 1. Records for newly created subintervals and all previously known component values are available for the next call. |
| `lem:core` | `CoreProtocol.protocol_good` | On an arbitrary recorded residue, Core returns an envy-free partition with a recorded remainder. The cutter gets exactly one $n$th of her input value and has an advantage of at least the remaining value divided by $n-1$ over some other holder. |
| `lem:reassign` | `Reassign.selection`, `Reassign.value_bounds`, `Division.core_move` | If no dominated group exists, the records determine a reassignment with the required envy, advantage and tolerance bounds. The witnessing pair was absent before the round. |
| `lem:shares`, `le:weighted` | `PhysicalShares.program_good`, `PhysicalShares.repair_shares` | Sparse weighted refinement builds disjoint physical shares. The total deficit equals the residual value, and every union of slots meets its target within the same error. The precision schedule is explicit for every tolerance required by the main theorem. |
| `lem:test`, `lem:repair` | `Buffered.protect`, `RepairProtocol.program_good` | Physical Repair preserves every input bundle, restores envy-freeness, and returns a holder permutation and complete records. Added values differ by at most $2n\alpha v_i(U)$ and the residue is worth at most $2n^2\alpha v_i(U)$ for each observer. |
| `lem:follow`, `lem:progress` | `Division.preserve_dom`, `Division.round_good`, `Division.loop_good` | Each nonreturning physical round strictly increases the number of dominated ordered pairs. Within $n^2+1$ rounds the protocol returns a nonempty proper dominated group. |
| `thm:main`, recursion | `Division.rename_good`, `Division.group_finish`, `Division.divide_good` | Recursive queries address only actual members of the group. Allocating their residue preserves exact coverage, disjointness, and every envy comparison inside and outside the group. |
| `thm:main`, query budget | `Division.round_bound`, `Division.level_bound`, `Division.start_good` | At most $1700m^5(1+\lfloor\log_2(2m)\rfloor)$ queries per round at size $m$. At most $n$ recursion levels and $n$ initial reads give the stated absolute constant. |
| Two-agent shortcut | `TwoAgents.protocol` | A separate four-query cut-and-choose strategy handles arbitrary valid replies on the unit cake. |

## What the checked matching test assumes

The test takes only the finite sets of tight columns computed from the trial
table, the identity of the pin, and the fact that every row has a minimum.
Its correctness theorem quantifies over a true vector and its curves.
It assumes one more column than rows, strictly increasing row-column curves,
a trial vector coordinatewise below the true vector, equality at the pin,
and full exposability at the true vector. The capped-square model supplies
the dimensions, pin and monotonicity. The spare-column proposition supplies
existence of the fully exposable vector. The checked median-phase lemma supplies the
coordinatewise lower bound. Finite row minima and the transfer of tight edges
at exact columns are proved in Lean.

### A query-equivalent implementation

The manuscript uses two alternating-path searches. This version enumerates
finite row sets and chooses a smallest nonempty set $S$ with at most
$|S|$ trial neighbors. If such a set exists, every neighbor of $S$ is
strictly short. The theorem `Matching.obstruction_disjoint` proves this
stronger certificate. To see the argument, suppose some neighbors were exact.
Write $T$ for those exact neighbors and $I$ for rows in $S$ touching
them. Strict Hall at the true vector gives $|I|<|T|$. The remaining rows
can only use the remaining neighbors, of which there are fewer than the
remaining rows. They form a smaller obstruction, a contradiction. If every
nonempty set has strictly more neighbors than rows, a counting argument
forces all coordinates to be exact. Finite Hall then gives a supporting
matching avoiding the pin.

The formal protocol uses deterministic choices on the observed records for matching,
reassignment, and selection of a sparse fractional assignment. Some searches enumerate
finite sets. The theorem bounds Robertson–Webb queries. The running time of these
internal operations and the manuscript's separate market applications are outside
its scope.

## Implementation choices

The main proof uses the same round for every population of size at least two,
then allocates the entire active residue at size one. This lets the recursion
use a single invariant for arbitrary lists of intervals. The separate four-query
base case remains available for two agents on the whole cake.

The simulator gives an entire piece the virtual value one plus its observed
mass and uses a shared monotone map for each observer. This also covers empty
pieces, zero valuations, and arbitrary valid replies on zero-value plateaus.
The program reads the values of both boundary intervals after a split. Those
reads are included in the constant above.
